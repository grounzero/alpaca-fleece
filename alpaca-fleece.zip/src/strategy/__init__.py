"""Trading strategies."""
