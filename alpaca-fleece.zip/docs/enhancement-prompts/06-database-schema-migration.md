# Database Schema Migration Specification

## Overview

**Problem:** Currently, database schema changes require manual intervention (ALTER TABLE statements, migration scripts). When new columns are added to the codebase, existing databases break with "no such column" errors.

**Solution:** Implement an automatic schema verification and migration system that runs on bot startup, ensuring the database always matches the expected schema without manual intervention.

## Goals

1. **Self-healing database** - Automatically add missing columns on startup
2. **Zero manual migrations** - No more ALTER TABLE scripts to run
3. **Backward compatible** - Existing data never lost or modified
4. **Clean code** - Single source of truth for schema, no messy migration history
5. **Safe** - Only additive changes (columns added, never dropped)

## Architecture

### 1. Schema Definition (`src/database_schema.py`)

Central schema definition as Python dictionary:

```python
"""Database schema definitions.

This is the single source of truth for the database schema.
The bot will automatically ensure the database matches this schema on startup.
"""

from typing import Dict, Any

# Schema version for tracking major changes
SCHEMA_VERSION = "1.0.0"

# Table schemas with column definitions
SCHEMA: Dict[str, Dict[str, str]] = {
    "order_intents": {
        "client_order_id": "TEXT PRIMARY KEY",
        "symbol": "TEXT NOT NULL",
        "side": "TEXT NOT NULL", 
        "qty": "NUMERIC(10, 4) NOT NULL",
        "atr": "NUMERIC(10, 4)",
        "status": "TEXT NOT NULL",
        "filled_qty": "NUMERIC(10, 4) DEFAULT 0",
        "filled_avg_price": "NUMERIC(10, 4)",  # Nullable until filled
        "alpaca_order_id": "TEXT",
        "created_at_utc": "TEXT NOT NULL",
        "updated_at_utc": "TEXT NOT NULL",
    },
    
    "trades": {
        "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
        "timestamp_utc": "TEXT NOT NULL",
        "symbol": "TEXT NOT NULL",
        "side": "TEXT NOT NULL",
        "qty": "NUMERIC(10, 4) NOT NULL",
        "price": "NUMERIC(10, 4) NOT NULL",
        "order_id": "TEXT NOT NULL",
        "client_order_id": "TEXT NOT NULL",
    },
    
    "positions_snapshot": {
        "timestamp_utc": "TEXT NOT NULL",
        "symbol": "TEXT NOT NULL",
        "qty": "NUMERIC(10, 4) NOT NULL",
        "avg_entry_price": "NUMERIC(10, 4) NOT NULL",
        "PRIMARY KEY": "(timestamp_utc, symbol)",
    },
    
    "position_tracking": {
        "symbol": "TEXT PRIMARY KEY",
        "side": "TEXT NOT NULL",
        "qty": "NUMERIC(10, 4) NOT NULL",
        "entry_price": "NUMERIC(10, 4) NOT NULL",
        "atr": "NUMERIC(10, 4)",
        "entry_time": "TEXT NOT NULL",
        "extreme_price": "NUMERIC(10, 4)",
        "trailing_stop_price": "NUMERIC(10, 4)",
        "trailing_stop_activated": "INTEGER DEFAULT 0",
        "pending_exit": "INTEGER DEFAULT 0",
        "updated_at": "TEXT NOT NULL",
    },
    
    "bars": {
        "symbol": "TEXT NOT NULL",
        "timestamp": "TEXT NOT NULL",
        "open": "REAL NOT NULL",
        "high": "REAL NOT NULL",
        "low": "REAL NOT NULL",
        "close": "REAL NOT NULL",
        "volume": "INTEGER NOT NULL",
        "vwap": "REAL",
        "trade_count": "INTEGER",
        "PRIMARY KEY": "(symbol, timestamp)",
    },
    
    "bot_state": {
        "id": "INTEGER PRIMARY KEY CHECK (id = 1)",  # Single row table
        "equity": "NUMERIC(15, 4) NOT NULL",
        "cash": "NUMERIC(15, 4) NOT NULL",
        "buying_power": "NUMERIC(15, 4) NOT NULL",
        "is_running": "INTEGER NOT NULL",
        "last_price_update": "TEXT",
        "updated_at": "TEXT NOT NULL",
    },
    
    "equity_curve": {
        "timestamp": "TEXT PRIMARY KEY",
        "equity": "NUMERIC(15, 4) NOT NULL",
        "cash": "NUMERIC(15, 4) NOT NULL",
        "buying_power": "NUMERIC(15, 4) NOT NULL",
    },
}

# Indexes to create
INDEXES: Dict[str, list] = {
    "order_intents": [
        "CREATE INDEX IF NOT EXISTS idx_order_intents_symbol ON order_intents(symbol)",
        "CREATE INDEX IF NOT EXISTS idx_order_intents_status ON order_intents(status)",
        "CREATE INDEX IF NOT EXISTS idx_order_intents_alpaca_id ON order_intents(alpaca_order_id)",
    ],
    "trades": [
        "CREATE INDEX IF NOT EXISTS idx_trades_symbol ON trades(symbol)",
        "CREATE INDEX IF NOT EXISTS idx_trades_timestamp ON trades(timestamp_utc)",
    ],
    "bars": [
        "CREATE INDEX IF NOT EXISTS idx_bars_symbol ON bars(symbol)",
    ],
}
```

### 2. Schema Manager (`src/schema_manager.py`)

```python
"""Database schema manager.

Ensures database schema matches expected structure on startup.
Automatically adds missing columns and tables.
"""

import logging
import sqlite3
from typing import Dict, Set, Tuple
from src.database_schema import SCHEMA, INDEXES

logger = logging.getLogger(__name__)


class SchemaManager:
    """Manages database schema verification and migration."""
    
    def __init__(self, db_path: str):
        self.db_path = db_path
    
    def ensure_schema(self) -> None:
        """Verify and update database schema to match expected structure.
        
        This method is idempotent - safe to call multiple times.
        Only additive changes are made (new columns/tables, never deletions).
        """
        logger.info("Verifying database schema...")
        
        with sqlite3.connect(self.db_path) as conn:
            changes_made = False
            
            # Ensure all tables exist with correct columns
            for table_name, columns in SCHEMA.items():
                if self._table_exists(conn, table_name):
                    changes_made |= self._ensure_table_columns(conn, table_name, columns)
                else:
                    self._create_table(conn, table_name, columns)
                    changes_made = True
            
            # Ensure all indexes exist
            for table_name, indexes in INDEXES.items():
                for index_sql in indexes:
                    try:
                        conn.execute(index_sql)
                        changes_made = True
                        logger.debug(f"Created index: {index_sql}")
                    except sqlite3.OperationalError as e:
                        if "already exists" in str(e):
                            pass  # Expected, ignore
                        else:
                            raise
            
            if changes_made:
                logger.info("Database schema updated successfully")
            else:
                logger.info("Database schema is up to date")
    
    def _table_exists(self, conn: sqlite3.Connection, table_name: str) -> bool:
        """Check if a table exists in the database."""
        cursor = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
            (table_name,)
        )
        return cursor.fetchone() is not None
    
    def _get_existing_columns(self, conn: sqlite3.Connection, table_name: str) -> Set[str]:
        """Get set of existing column names for a table."""
        cursor = conn.execute(f"PRAGMA table_info({table_name})")
        return {row[1] for row in cursor.fetchall()}
    
    def _ensure_table_columns(
        self, 
        conn: sqlite3.Connection, 
        table_name: str, 
        expected_columns: Dict[str, str]
    ) -> bool:
        """Ensure table has all expected columns. Add any that are missing.
        
        Returns:
            True if changes were made, False otherwise.
        """
        existing_columns = self._get_existing_columns(conn, table_name)
        expected_column_names = set(expected_columns.keys())
        
        # Find columns to add
        columns_to_add = expected_column_names - existing_columns
        
        # Find unexpected columns (log warning but don't remove)
        unexpected_columns = existing_columns - expected_column_names
        if unexpected_columns:
            logger.warning(
                f"Table {table_name} has unexpected columns: {unexpected_columns}. "
                "These will be preserved."
            )
        
        if not columns_to_add:
            return False
        
        # Add missing columns
        for column_name in columns_to_add:
            column_def = expected_columns[column_name]
            self._add_column(conn, table_name, column_name, column_def)
        
        return True
    
    def _add_column(
        self, 
        conn: sqlite3.Connection, 
        table_name: str, 
        column_name: str, 
        column_def: str
    ) -> None:
        """Add a column to an existing table."""
        # Remove PRIMARY KEY and CHECK constraints from column def
        # These can't be added via ALTER TABLE
        clean_def = self._clean_column_def_for_alter(column_def)
        
        sql = f"ALTER TABLE {table_name} ADD COLUMN {column_name} {clean_def}"
        conn.execute(sql)
        logger.info(f"Added column {column_name} to {table_name}")
    
    def _clean_column_def_for_alter(self, column_def: str) -> str:
        """Clean column definition for ALTER TABLE.
        
        SQLite ALTER TABLE ADD COLUMN doesn't support:
        - PRIMARY KEY
        - CHECK constraints  
        - Unique constraints
        """
        # Remove PRIMARY KEY
        clean = column_def.replace("PRIMARY KEY", "")
        # Remove CHECK constraints (simple removal, may need refinement)
        if "CHECK" in clean:
            clean = clean.split("CHECK")[0].strip()
        return clean.strip()
    
    def _create_table(
        self, 
        conn: sqlite3.Connection, 
        table_name: str, 
        columns: Dict[str, str]
    ) -> None:
        """Create a new table with the specified columns."""
        column_defs = [f"{name} {def_}" for name, def_ in columns.items()]
        columns_sql = ", ".join(column_defs)
        
        sql = f"CREATE TABLE {table_name} ({columns_sql})"
        conn.execute(sql)
        logger.info(f"Created table {table_name}")


def ensure_database_schema(db_path: str) -> None:
    """Convenience function to ensure schema."""
    manager = SchemaManager(db_path)
    manager.ensure_schema()
```

### 3. Integration with Bot Startup

**In `orchestrator.py` or main entry point:**

```python
from src.schema_manager import ensure_database_schema
from src.config import DB_PATH

class AlpacaBot:
    def __init__(self):
        # Ensure database schema before anything else
        ensure_database_schema(DB_PATH)
        
        # Now safe to initialize other components
        self.state_store = StateStore(DB_PATH)
        # ... rest of initialization
```

### 4. Adding New Columns (Developer Workflow)

When a developer needs to add a new column:

1. **Update `src/database_schema.py`:**
```python
SCHEMA = {
    "order_intents": {
        # ... existing columns
        "filled_avg_price": "NUMERIC(10, 4)",  # NEW COLUMN
        # ... rest of columns
    },
}
```

2. **Update code to use new column** (normal development)

3. **Deploy** - SchemaManager automatically adds the column on first startup

4. **No migration scripts needed!**

## Safety Guarantees

### 1. Only Additive Changes
- Columns are only ADDED, never removed
- Tables are only CREATED, never dropped
- Existing data is never modified

### 2. Idempotent Operations
- Safe to run multiple times
- No errors if schema already matches
- No duplicate columns created

### 3. Constraint Handling
- PRIMARY KEY constraints: Only applied on table creation
- CHECK constraints: Only applied on table creation  
- DEFAULT values: Applied when adding columns
- NOT NULL: Applied when adding columns (existing rows get NULL)

### 4. Backup Recommendation
While the system is safe, we recommend:
- Automatic backup before schema changes
- Configurable via `config.yaml`:
```yaml
database:
  auto_backup_before_schema_changes: true
  backup_retention_days: 7
```

## Testing

### Unit Tests (`tests/test_schema_manager.py`)

```python
import sqlite3
import pytest
from src.schema_manager import SchemaManager
from src.database_schema import SCHEMA


class TestSchemaManager:
    """Test database schema management."""
    
    def test_creates_missing_table(self, tmp_path):
        """Should create table if it doesn't exist."""
        db_path = tmp_path / "test.db"
        manager = SchemaManager(str(db_path))
        manager.ensure_schema()
        
        # Verify table exists
        with sqlite3.connect(str(db_path)) as conn:
            cursor = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='order_intents'"
            )
            assert cursor.fetchone() is not None
    
    def test_adds_missing_column(self, tmp_path):
        """Should add missing column to existing table."""
        db_path = tmp_path / "test.db"
        
        # Create table with partial schema
        with sqlite3.connect(str(db_path)) as conn:
            conn.execute("""
                CREATE TABLE order_intents (
                    client_order_id TEXT PRIMARY KEY,
                    symbol TEXT
                )
            """)
        
        # Run schema manager
        manager = SchemaManager(str(db_path))
        manager.ensure_schema()
        
        # Verify new column was added
        with sqlite3.connect(str(db_path)) as conn:
            cursor = conn.execute("PRAGMA table_info(order_intents)")
            columns = {row[1] for row in cursor.fetchall()}
            assert "filled_avg_price" in columns
    
    def test_idempotent(self, tmp_path):
        """Should be safe to run multiple times."""
        db_path = tmp_path / "test.db"
        manager = SchemaManager(str(db_path))
        
        # Run twice
        manager.ensure_schema()
        manager.ensure_schema()
        
        # Should not raise errors
        assert True
    
    def test_preserves_existing_data(self, tmp_path):
        """Should not modify existing data."""
        db_path = tmp_path / "test.db"
        
        # Create table and add data
        with sqlite3.connect(str(db_path)) as conn:
            conn.execute("""
                CREATE TABLE order_intents (
                    client_order_id TEXT PRIMARY KEY,
                    symbol TEXT
                )
            """)
            conn.execute("INSERT INTO order_intents VALUES ('test-123', 'AAPL')")
            conn.commit()
        
        # Run schema manager
        manager = SchemaManager(str(db_path))
        manager.ensure_schema()
        
        # Verify data preserved
        with sqlite3.connect(str(db_path)) as conn:
            cursor = conn.execute("SELECT client_order_id, symbol FROM order_intents")
            row = cursor.fetchone()
            assert row == ('test-123', 'AAPL')
```

## Rollback Strategy

If a schema change causes issues:

1. **Automatic backups** created before changes
2. **Restore from backup:**
```bash
cp data/trades.db.backup.TIMESTAMP data/trades.db
```
3. **Revert code** to previous version
4. **Restart bot**

## Future Enhancements

### 1. Schema Version Tracking
Track schema versions for major changes:
```python
# In database
CREATE TABLE schema_version (
    version TEXT PRIMARY KEY,
    applied_at TEXT NOT NULL
)
```

### 2. Migration Hooks
Allow custom migration logic for complex changes:
```python
SCHEMA = {
    "order_intents": {
        "new_column": "TEXT",
        "__migration__": "backfill_new_column",  # Custom function
    }
}
```

### 3. Validation Mode
Dry-run mode to preview changes:
```bash
python -m src.schema_manager --dry-run
```

## Implementation Checklist

- [ ] Create `src/database_schema.py` with SCHEMA definition
- [ ] Create `src/schema_manager.py` with SchemaManager class
- [ ] Update `orchestrator.py` to call `ensure_database_schema()` on startup
- [ ] Write unit tests in `tests/test_schema_manager.py`
- [ ] Add backup logic before schema changes
- [ ] Update documentation
- [ ] Test on staging environment
- [ ] Deploy to production

## Acceptance Criteria

1. Bot starts successfully with fresh database
2. Bot starts successfully with existing database (no changes)
3. Bot automatically adds missing columns when schema updated
4. No manual migration scripts required
5. Existing data is preserved
6. All tests pass

---

**Status:** Specification ready for review  
**Next Step:** Review and approve, then schedule implementation
