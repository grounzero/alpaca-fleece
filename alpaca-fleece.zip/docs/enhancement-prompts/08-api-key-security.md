# API Key Security Enhancement

## Overview
Implement comprehensive API key security including key rotation schedules, external secrets management, pre-commit hooks to prevent accidental commits, and separate keys per environment. Critical for protecting trading accounts.

## Current State
- Keys stored in plaintext `.env` file
- File permissions are 600 (owner-only read)
- `.env` is in `.gitignore`
- Same keys used for all sessions

## Required Implementation

### 1. Secrets Management Integration (`src/security/secrets.py`)

```python
from abc import ABC, abstractmethod
from typing import Optional
import os

class SecretsProvider(ABC):
    """Abstract base for secrets providers."""
    
    @abstractmethod
    def get_secret(self, key: str) -> str:
        ...
    
    @abstractmethod
    def rotate_secret(self, key: str) -> str:
        """Rotate secret and return new value."""
        ...

class EnvironmentSecrets(SecretsProvider):
    """Fallback to environment variables (current method)."""
    def get_secret(self, key: str) -> str:
        value = os.getenv(key)
        if not value:
            raise SecretNotFoundError(f"{key} not in environment")
        return value

class AWSSecretsManager(SecretsProvider):
    """AWS Secrets Manager integration."""
    def __init__(self, region: str = "us-east-1"):
        import boto3
        self.client = boto3.client('secretsmanager', region_name=region)
    
    def get_secret(self, key: str) -> str:
        response = self.client.get_secret_value(SecretId=key)
        return response['SecretString']
    
    def rotate_secret(self, key: str) -> str:
        self.client.rotate_secret(SecretId=key)
        return self.get_secret(key)

class AzureKeyVault(SecretsProvider):
    """Azure Key Vault integration."""
    def __init__(self, vault_url: str):
        from azure.identity import DefaultAzureCredential
        from azure.keyvault.secrets import SecretClient
        credential = DefaultAzureCredential()
        self.client = SecretClient(vault_url=vault_url, credential=credential)
    
    def get_secret(self, key: str) -> str:
        return self.client.get_secret(key).value

class HashiCorpVault(SecretsProvider):
    """HashiCorp Vault integration."""
    def __init__(self, url: str, token: str):
        import hvac
        self.client = hvac.Client(url=url, token=token)
    
    def get_secret(self, key: str) -> str:
        response = self.client.secrets.kv.v2.read_secret_version(path=key)
        return response['data']['data']['value']

class SecureCredentialManager:
    """Main interface for credential management."""
    
    def __init__(self, provider: Optional[SecretsProvider] = None):
        self.provider = provider or EnvironmentSecrets()
        self._cache: Dict[str, str] = {}
        self._cache_ttl = 300  # 5 minutes
    
    def get_alpaca_credentials(self, environment: str = "paper") -> AlpacaCredentials:
        """Get Alpaca API credentials."""
        prefix = f"ALPACA_{environment.upper()}_"
        
        return AlpacaCredentials(
            api_key=self._get_secret(f"{prefix}API_KEY"),
            secret_key=self._get_secret(f"{prefix}SECRET_KEY"),
            base_url=self._get_secret(f"{prefix}BASE_URL")
        )
    
    def _get_secret(self, key: str) -> str:
        """Get secret with caching."""
        if key in self._cache:
            return self._cache[key]
        
        value = self.provider.get_secret(key)
        self._cache[key] = value
        return value
```

### 2. Key Rotation System (`src/security/rotation.py`)

```python
class KeyRotationScheduler:
    """Schedule and execute API key rotation."""
    
    ROTATION_INTERVAL_DAYS = 90
    
    def __init__(self, secrets_manager: SecureCredentialManager):
        self.secrets = secrets_manager
        self.db = Database()
    
    async def check_rotation_needed(self) -> List[RotationAlert]:
        """Check which keys need rotation."""
        alerts = []
        
        for env in ["paper", "live"]:
            last_rotation = await self.get_last_rotation(env)
            days_since = (datetime.now() - last_rotation).days
            
            if days_since > self.ROTATION_INTERVAL_DAYS:
                alerts.append(RotationAlert(
                    environment=env,
                    days_overdue=days_since - self.ROTATION_INTERVAL_DAYS,
                    urgency="high" if days_since > 100 else "medium"
                ))
            elif days_since > self.ROTATION_INTERVAL_DAYS - 7:
                alerts.append(RotationAlert(
                    environment=env,
                    days_until_rotation=self.ROTATION_INTERVAL_DAYS - days_since,
                    urgency="low"
                ))
        
        return alerts
    
    async def rotate_keys(self, environment: str, dry_run: bool = False) -> RotationResult:
        """
        Rotate Alpaca API keys.
        
        Process:
        1. Generate new keys in Alpaca dashboard
        2. Update secrets manager with new keys
        3. Update bot configuration
        4. Verify new keys work
        5. Delete old keys (or keep as backup for 24h)
        """
        if not dry_run:
            # Verify bot is not trading
            if await self.is_bot_trading():
                raise RotationError("Cannot rotate keys while bot is actively trading")
        
        # Get current keys
        old_creds = self.secrets.get_alpaca_credentials(environment)
        
        # Generate new keys via Alpaca API
        new_creds = await self._generate_new_keys(environment)
        
        if dry_run:
            return RotationResult(
                success=True,
                message="Dry run - new keys would be generated",
                old_key_preview=old_creds.api_key[:8] + "...",
                new_key_preview=new_creds.api_key[:8] + "..."
            )
        
        # Update secrets manager
        await self._update_secrets(environment, new_creds)
        
        # Verify new keys work
        if not await self._verify_keys(new_creds):
            # Rollback to old keys
            await self._update_secrets(environment, old_creds)
            raise RotationError("New keys failed verification, rolled back")
        
        # Record rotation
        await self._record_rotation(environment, old_creds.api_key, new_creds.api_key)
        
        # Schedule old key deletion (24h grace period)
        await self._schedule_old_key_deletion(environment, old_creds.api_key, delay_hours=24)
        
        return RotationResult(
            success=True,
            message=f"Successfully rotated {environment} keys",
            rotation_date=datetime.now()
        )
```

### 3. Pre-Commit Hook for Secret Detection

`.pre-commit-config.yaml` additions:

```yaml
repos:
  # Secret detection
  - repo: https://github.com/Yelp/detect-secrets
    rev: v1.4.0
    hooks:
      - id: detect-secrets
        args: ['--baseline', '.secrets.baseline']
        exclude: .*/tests/.*
  
  # Alternative: GitGuardian
  - repo: https://github.com/gitguardian/ggshield
    rev: v1.20.0
    hooks:
      - id: ggshield
        language: system
        pass_filenames: false
        stages: [commit]
  
  # Custom hook for Alpaca keys
  - repo: local
    hooks:
      - id: check-alpaca-keys
        name: Check for Alpaca API keys
        entry: python scripts/check_for_keys.py
        language: python
        files: .*
```

`scripts/check_for_keys.py`:

```python
#!/usr/bin/env python3
"""Pre-commit hook to detect Alpaca API keys."""

import re
import sys

ALPACA_KEY_PATTERNS = [
    r'PK[A-Z0-9]{20}',  # Alpaca paper key format
    r'AK[A-Z0-9]{20}',  # Alpaca live key format
]

FORBIDDEN_FILES = [
    '.env',
    '.env.local',
    '.env.production',
    'secrets.json',
    'credentials.json',
]

def main():
    files = sys.argv[1:] if len(sys.argv) > 1 else []
    errors = []
    
    for filepath in files:
        # Check if file is in allowed list
        if any(forbidden in filepath for forbidden in FORBIDDEN_FILES):
            errors.append(f"Attempting to commit forbidden file: {filepath}")
            continue
        
        try:
            with open(filepath, 'r') as f:
                content = f.read()
        except:
            continue
        
        for pattern in ALPACA_KEY_PATTERNS:
            matches = re.findall(pattern, content)
            if matches:
                errors.append(
                    f"Potential Alpaca API key found in {filepath}: {matches[0][:8]}..."
                )
    
    if errors:
        print("SECRET DETECTION FAILED:")
        for error in errors:
            print(f"  ❌ {error}")
        print("\nIf these are test/example keys, add them to .secrets.baseline")
        sys.exit(1)
    
    print("✅ No secrets detected")
    sys.exit(0)

if __name__ == "__main__":
    main()
```

### 4. Environment Separation

```
config/
├── environments/
│   ├── paper.yaml        # Paper trading config
│   ├── live.yaml         # Live trading config
│   └── backtest.yaml     # Backtesting config
└── credentials/
    ├── paper.env         # Paper API keys (committed encrypted or in secrets manager)
    └── live.env          # Live API keys (NEVER committed)
```

`docker-compose.yml` update:

```yaml
services:
  alpaca-bot-paper:
    env_file:
      - .env.paper
    environment:
      - TRADING_MODE=paper
      - ALLOW_LIVE_TRADING=false
    
  alpaca-bot-live:
    env_file:
      - .env.live
    environment:
      - TRADING_MODE=live
      - ALLOW_LIVE_TRADING=true
    profiles:
      - live  # Only start with: docker-compose --profile live up
```

### 5. Encrypted Environment Files

```python
# Use Mozilla SOPS or similar for encrypted .env files
class EncryptedEnv:
    """Handle encrypted environment files."""
    
    def __init__(self, key_file: str = "~/.config/sops/age/keys.txt"):
        self.key_file = key_file
    
    def decrypt(self, encrypted_file: str) -> Dict[str, str]:
        """Decrypt .env file using SOPS."""
        import subprocess
        result = subprocess.run(
            ["sops", "-d", encrypted_file],
            capture_output=True,
            text=True
        )
        
        env_vars = {}
        for line in result.stdout.split('\n'):
            if '=' in line and not line.startswith('#'):
                key, value = line.split('=', 1)
                env_vars[key] = value
        
        return env_vars
    
    def encrypt(self, plaintext_file: str, output_file: str) -> None:
        """Encrypt .env file."""
        subprocess.run([
            "sops", "--encrypt",
            "--age", self.get_public_key(),
            plaintext_file
        ], check=True)
```

### 6. Audit Logging

```python
class SecurityAuditLogger:
    """Log all credential access and rotation events."""
    
    async def log_credential_access(
        self,
        key_name: str,
        accessed_by: str,
        purpose: str,
        success: bool
    ) -> None:
        await self.db.execute("""
            INSERT INTO credential_audit_log 
            (timestamp, key_name, accessed_by, purpose, success, ip_address)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (datetime.utcnow(), key_name, accessed_by, purpose, success, get_client_ip()))
    
    async def get_access_history(self, key_name: str) -> List[AccessRecord]:
        """Get audit trail for a specific key."""
        ...
```

### 7. CLI Commands

```bash
# Check security status
python -m src.security.cli check

# Rotate keys
python -m src.security.cli rotate --environment paper --dry-run
python -m src.security.cli rotate --environment live

# View audit log
python -m src.security.cli audit --limit 100

# Encrypt .env file
python -m src.security.cli encrypt --input .env.plain --output .env.enc

# Decrypt .env file (for local development)
python -m src.security.cli decrypt --input .env.enc --output .env.local

# Setup pre-commit hooks
python -m src.security.cli setup-hooks
```

## Acceptance Criteria

- [ ] Support for AWS Secrets Manager, Azure Key Vault, HashiCorp Vault
- [ ] Automatic key rotation every 90 days with notifications
- [ ] Pre-commit hooks detect and block API key commits
- [ ] Separate environments (paper/live) with isolated credentials
- [ ] Encrypted .env files using SOPS or similar
- [ ] Audit logging of all credential access
- [ ] Key verification after rotation (rollback on failure)
- [ ] CLI for all security operations

## Priority
HIGH - Critical security infrastructure

## Estimated Effort
3-4 days
