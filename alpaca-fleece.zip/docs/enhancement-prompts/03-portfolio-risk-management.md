# Portfolio-Level Risk Management

## Overview
Implement correlation-aware position sizing that considers portfolio-level exposure rather than treating each trade in isolation. Prevents over-concentration in correlated assets (e.g., buying AAPL and MSFT simultaneously is effectively one tech bet).

## Current State
- Position sizing in `src/position_sizer.py` is per-trade only
- No correlation matrix between symbols
- No sector/industry tracking
- Max position is 10% of equity per trade, but 10 correlated positions = 100% in one theme

## Required Implementation

### 1. Correlation Matrix Service (`src/risk/correlation.py`)

Calculate historical correlations between all symbols in universe:

```python
class CorrelationMatrix:
    def __init__(self, lookback_days: int = 90):
        self.lookback_days = lookback_days
        self.correlation_matrix: pd.DataFrame = None
        self.last_updated: Optional[datetime] = None
    
    async def update(self, price_data: Dict[str, pd.DataFrame]):
        """Calculate correlation matrix from price history."""
        returns = {}
        for symbol, df in price_data.items():
            returns[symbol] = df['close'].pct_change().dropna()
        
        returns_df = pd.DataFrame(returns)
        self.correlation_matrix = returns_df.corr()
        self.last_updated = datetime.now(timezone.utc)
    
    def get_correlation(self, symbol1: str, symbol2: str) -> float:
        """Get correlation coefficient between two symbols (-1 to 1)."""
        return self.correlation_matrix.loc[symbol1, symbol2]
    
    def get_correlated_symbols(self, symbol: str, threshold: float = 0.7) -> List[str]:
        """Find all symbols correlated above threshold."""
        correlations = self.correlation_matrix[symbol]
        return correlations[correlations.abs() > threshold].index.tolist()
```

### 2. Portfolio Risk Analyzer (`src/risk/portfolio_risk.py`)

Track and limit portfolio-level exposures:

```python
@dataclass
class PortfolioExposure:
    total_exposure_pct: float  # Sum of all position values / equity
    net_exposure_pct: float    # Long - Short exposure
    sector_exposures: Dict[str, float]
    factor_exposures: Dict[str, float]  # Beta, momentum, etc.
    concentration_risk: float  # Herfindahl index of positions
    correlation_adjusted_risk: float  # Portfolio volatility estimate

class PortfolioRiskAnalyzer:
    def __init__(self, correlation_matrix: CorrelationMatrix):
        self.correlation = correlation_matrix
        
    def calculate_exposure(self, positions: List[Position], 
                          equity: float) -> PortfolioExposure:
        """Calculate current portfolio exposures."""
        ...
    
    def calculate_portfolio_volatility(self, positions: List[Position]) -> float:
        """Estimate portfolio volatility using correlations."""
        # σ_p = sqrt(w' Σ w)
        # where w = weight vector, Σ = covariance matrix
        ...
        
    def check_concentration_limit(self, new_trade: SignalEvent,
                                  current_positions: List[Position]) -> RiskCheck:
        """Check if adding new trade violates concentration limits."""
        # Calculate correlation-adjusted exposure
        correlated_positions = self.find_correlated_positions(new_trade.symbol)
        total_correlated_exposure = sum(
            p.value for p in correlated_positions
        ) / equity
        
        new_exposure = new_trade.notional_value / equity
        combined_exposure = total_correlated_exposure + new_exposure
        
        if combined_exposure > MAX_CORRELATED_EXPOSURE_PCT:
            return RiskCheck(
                passed=False,
                reason=f"Correlated exposure would be {combined_exposure:.1%} "
                       f"(limit: {MAX_CORRELATED_EXPOSURE_PCT:.1%})"
            )
```

### 3. Enhanced Position Sizing

Update `calculate_position_size` to consider portfolio context:

```python
def calculate_position_size_with_portfolio_context(
    symbol: str,
    account_equity: float,
    current_price: float,
    portfolio_analyzer: PortfolioRiskAnalyzer,
    correlation_matrix: CorrelationMatrix,
    max_position_pct: float = 0.10,
    max_correlated_exposure_pct: float = 0.15,  # NEW
) -> PositionSizeResult:
    """Calculate position size considering existing correlated positions."""
    
    # 1. Calculate base size (existing logic)
    base_size = calculate_position_size(
        symbol, "buy", account_equity, current_price, 
        max_position_pct
    )
    
    # 2. Find correlated positions
    correlated = portfolio_analyzer.get_correlated_positions(symbol)
    correlated_exposure = sum(p.market_value for p in correlated)
    
    # 3. Calculate available room in correlation bucket
    available_exposure = max_correlated_exposure_pct * account_equity - correlated_exposure
    
    # 4. Size to fit available room
    max_shares_by_correlation = int(available_exposure / current_price)
    
    # 5. Take most conservative
    final_qty = min(base_size, max_shares_by_correlation, 1)
    
    return PositionSizeResult(
        quantity=final_qty,
        base_size=base_size,
        correlation_limited_by=max_shares_by_correlation,
        correlated_symbols=[p.symbol for p in correlated],
        correlation_adjusted_exposure=(correlated_exposure + final_qty * current_price) / account_equity
    )
```

### 4. Sector/Industry Classification

Add symbol metadata for sector tracking:

```python
# config/symbols.yaml or database table
SYMBOL_METADATA = {
    "AAPL": {"sector": "Technology", "industry": "Consumer Electronics", "beta": 1.2},
    "MSFT": {"sector": "Technology", "industry": "Software", "beta": 1.1},
    "GOOGL": {"sector": "Technology", "industry": "Internet", "beta": 1.15},
    "JPM": {"sector": "Financials", "industry": "Banks", "beta": 1.0},
    # ... all symbols
}

class SectorExposureTracker:
    def get_sector_exposures(self, positions: List[Position]) -> Dict[str, float]:
        """Calculate exposure by sector."""
        exposures = defaultdict(float)
        for pos in positions:
            sector = SYMBOL_METADATA[pos.symbol]["sector"]
            exposures[sector] += pos.market_value
        return {s: v / total_equity for s, v in exposures.items()}
```

### 5. Risk Limits Configuration

Add to `trading.yaml`:

```yaml
portfolio_risk:
  # Correlation limits
  max_correlated_exposure_pct: 0.20  # Max 20% in correlated symbols
  correlation_threshold: 0.70  # Consider correlated if |r| > 0.7
  correlation_lookback_days: 90
  
  # Sector limits
  max_sector_exposure_pct: 0.30  # Max 30% in any single sector
  
  # Portfolio volatility limit
  max_portfolio_volatility_annual: 0.25  # Target max 25% annualized vol
  
  # Concentration limits
  max_position_concentration_herfindahl: 0.15  # Lower = more diversified
  
  # Factor exposures
  max_portfolio_beta: 1.3  # Max market beta
  min_portfolio_beta: 0.7
```

### 6. Pre-Trade Risk Check Integration

Update `RiskManager.check_signal()` to include portfolio-level checks:

```python
async def check_signal(self, signal: SignalEvent) -> bool:
    # Existing checks (kill switch, daily limits, etc.)
    
    # NEW: Portfolio-level checks
    portfolio_exposure = self.portfolio_analyzer.calculate_exposure(
        self.position_tracker.get_all_positions(),
        self.account_equity
    )
    
    # Check correlation-adjusted exposure
    correlated_exposure = self.get_correlated_exposure(signal.symbol)
    if correlated_exposure + signal.notional_value > self.max_correlated_exposure:
        logger.warning(f"Rejecting {signal.symbol}: would exceed correlated exposure limit")
        return False
    
    # Check sector exposure
    sector = SYMBOL_METADATA[signal.symbol]["sector"]
    current_sector_exposure = portfolio_exposure.sector_exposures.get(sector, 0)
    if current_sector_exposure > self.max_sector_exposure_pct:
        logger.warning(f"Rejecting {signal.symbol}: sector {sector} at {current_sector_exposure:.1%}")
        return False
    
    # Check portfolio volatility forecast
    forecast_vol = self.portfolio_analyzer.forecast_volatility_with_new_trade(signal)
    if forecast_vol > self.max_portfolio_volatility:
        logger.warning(f"Rejecting {signal.symbol}: would increase portfolio vol to {forecast_vol:.1%}")
        return False
    
    return True
```

### 7. Correlation Matrix Updates

- Recalculate correlation matrix daily after market close
- Store historical correlations to detect regime changes
- Alert if correlations spike (market stress indicator)

### 8. Reporting

Add to daily report:
```
Portfolio Risk Summary
======================
Total Exposure:        65% long, 0% short
Net Exposure:          65%
Largest Sector:        Technology (42%)
Portfolio Beta:        1.15
Est. Annual Vol:       22%
Correlation-Adj Risk:  Medium

Top Correlated Groups:
- Tech Mega-caps (AAPL, MSFT, GOOGL, NVDA): 38% exposure
- Defense (RTX, LMT, NOC): 12% exposure
```

### 9. Testing

```python
def test_correlation_limits():
    # Setup: Already have AAPL position (10%)
    portfolio.add_position("AAPL", qty=100, price=150)  # $15k = 15%
    
    # Try to add MSFT (highly correlated)
    msft_signal = create_signal("MSFT", qty=100, price=300)  # Would be 30%
    
    result = risk_manager.check_signal(msft_signal)
    assert result.passed is False  # Would exceed correlated exposure limit
    
    # Try smaller MSFT position
    msft_signal_small = create_signal("MSFT", qty=20, price=300)  # 6%
    result = risk_manager.check_signal(msft_signal_small)
    assert result.passed is True  # AAPL(15%) + MSFT(6%) = 21%, under 30% limit
```

## Acceptance Criteria

- [ ] Correlation matrix calculated daily from 90-day price history
- [ ] Position sizing reduced when correlated positions exist
- [ ] Sector exposure tracked and limited
- [ ] Pre-trade checks reject signals that would exceed limits
- [ ] Portfolio volatility forecasted and capped
- [ ] Correlation-adjusted exposure reported daily
- [ ] Historical correlation data stored for analysis
- [ ] Unit tests for all risk scenarios

## Priority
HIGH - Important for risk management at scale

## Estimated Effort
5-7 days
