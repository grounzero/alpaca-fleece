# Network Security Hardening

## Overview
Implement network-level security controls including firewall rules, outbound connection whitelisting, VPN-only access for admin functions, and traffic encryption verification. Ensures the bot cannot be remotely exploited and administrative access is restricted.

## Current State
- Bot runs in Docker container
- No explicit firewall rules configured
- Outbound connections unrestricted
- No VPN requirement for access
- Standard HTTPS to Alpaca API

## Required Implementation

### 1. Firewall Configuration (`infra/firewall/`)

```python
# src/security/network/firewall.py
class FirewallConfigurator:
    """
    Configure host-level firewall rules for the trading bot.
    Implements default-deny policy with explicit whitelisting.
    """
    
    # Allowed outbound destinations
    ALLOWED_HOSTS = {
        # Alpaca trading API
        "paper-api.alpaca.markets": {
            "ports": [443],
            "protocols": ["tcp"],
            "description": "Alpaca Paper Trading API"
        },
        "api.alpaca.markets": {
            "ports": [443],
            "protocols": ["tcp"],
            "description": "Alpaca Live Trading API"
        },
        # Alpaca market data
        "data.alpaca.markets": {
            "ports": [443],
            "protocols": ["tcp"],
            "description": "Alpaca Market Data"
        },
        # Alpaca WebSocket streams
        "stream.data.alpaca.markets": {
            "ports": [443],
            "protocols": ["tcp"],
            "description": "Alpaca WebSocket Stream"
        },
        # Time sync (required for API auth)
        "pool.ntp.org": {
            "ports": [123],
            "protocols": ["udp"],
            "description": "NTP Time Sync"
        },
    }
    
    # DNS servers
    ALLOWED_DNS = ["8.8.8.8", "1.1.1.1"]
    
    def __init__(self, enforce: bool = True):
        self.enforce = enforce
        self.iptables_path = self._find_iptables()
    
    def apply_rules(self) -> None:
        """
        Apply restrictive firewall rules.
        
        Rules applied:
        1. Default deny all outbound
        2. Allow loopback
        3. Allow established connections
        4. Allow DNS
        5. Allow whitelisted hosts
        6. Log and drop everything else
        """
        if not self.enforce:
            logger.warning("Firewall enforcement disabled - no rules applied")
            return
        
        commands = [
            # Flush existing rules
            "iptables -F",
            "iptables -X",
            
            # Default policies
            "iptables -P INPUT DROP",
            "iptables -P FORWARD DROP",
            "iptables -P OUTPUT DROP",
            
            # Allow loopback
            "iptables -A INPUT -i lo -j ACCEPT",
            "iptables -A OUTPUT -o lo -j ACCEPT",
            
            # Allow established connections
            "iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT",
            "iptables -A OUTPUT -m state --state ESTABLISHED,RELATED -j ACCEPT",
            
            # Allow DNS
            *[f"iptables -A OUTPUT -p udp --dport 53 -d {dns} -j ACCEPT" 
              for dns in self.ALLOWED_DNS],
            
            # Allow NTP
            "iptables -A OUTPUT -p udp --dport 123 -j ACCEPT",
        ]
        
        # Allow whitelisted hosts
        for host, config in self.ALLOWED_HOSTS.items():
            ips = self._resolve_host(host)
            for ip in ips:
                for port in config["ports"]:
                    for protocol in config["protocols"]:
                        commands.append(
                            f"iptables -A OUTPUT -p {protocol} -d {ip} --dport {port} -j ACCEPT"
                        )
        
        # Log dropped packets
        commands.extend([
            "iptables -A OUTPUT -j LOG --log-prefix 'FIREWALL-DROP: ' --log-level 4",
            "iptables -A OUTPUT -j DROP",
        ])
        
        # Execute commands
        for cmd in commands:
            subprocess.run(cmd.split(), check=True)
        
        logger.info("Firewall rules applied successfully")
    
    def verify_connectivity(self) -> Dict[str, bool]:
        """Verify bot can reach required services."""
        results = {}
        for host in self.ALLOWED_HOSTS:
            try:
                socket.getaddrinfo(host, None)
                results[host] = True
            except:
                results[host] = False
        return results
```

### 2. Docker Network Isolation

```yaml
# docker-compose.yml network configuration
services:
  alpaca-bot:
    build: .
    container_name: alpaca-trading-bot
    networks:
      - trading-network
    # No published ports - only outbound connections
    expose: []  
    security_opt:
      - no-new-privileges:true
    cap_drop:
      - ALL  # Drop all capabilities
    cap_add:
      - NET_BIND_SERVICE  # Only if needed
    read_only: true  # Read-only filesystem
    tmpfs:
      - /tmp:noexec,nosuid,size=100m
    volumes:
      - ./data:/app/data:rw
      - ./logs:/app/logs:rw
      - ./config:/app/config:ro
    environment:
      - PYTHONUNBUFFERED=1
    restart: unless-stopped
    
  # Admin panel (VPN only)
  admin-panel:
    build: ./admin
    networks:
      - trading-network
      - admin-network
    expose:
      - "8080"
    # Only accessible via VPN
    profiles:
      - admin

networks:
  trading-network:
    internal: true  # No external access
    driver: bridge
    ipam:
      config:
        - subnet: 172.28.0.0/16
  
  admin-network:
    # Connected to VPN interface only
    driver: bridge
    internal: false
```

### 3. VPN-Only Admin Access

```python
# src/security/network/vpn_gatekeeper.py
class VPNGatekeeper:
    """
    Ensure admin panel is only accessible via VPN.
    """
    
    ALLOWED_VPN_SUBNETS = [
        "10.8.0.0/24",    # WireGuard default
        "10.200.0.0/24",  # Custom WireGuard
        "192.168.100.0/24", # OpenVPN
    ]
    
    def __init__(self):
        self.trusted_proxies = ["127.0.0.1"]  # If behind reverse proxy
    
    def is_vpn_client(self, request_ip: str, forwarded_for: Optional[str] = None) -> bool:
        """
        Determine if request is coming from VPN.
        
        Checks:
        1. Direct connection from VPN subnet
        2. X-Forwarded-For from VPN via trusted proxy
        """
        client_ip = ipaddress.ip_address(request_ip)
        
        # Check direct connection
        for subnet in self.ALLOWED_VPN_SUBNETS:
            if client_ip in ipaddress.ip_network(subnet):
                return True
        
        # Check forwarded header from trusted proxy
        if forwarded_for and request_ip in self.trusted_proxies:
            original_ip = ipaddress.ip_address(forwarded_for.split(',')[0].strip())
            for subnet in self.ALLOWED_VPN_SUBNETS:
                if original_ip in ipaddress.ip_network(subnet):
                    return True
        
        return False
    
    def require_vpn(self, handler_func):
        """Decorator to require VPN for endpoint."""
        @wraps(handler_func)
        async def wrapper(request, *args, **kwargs):
            client_ip = request.remote_addr
            forwarded = request.headers.get('X-Forwarded-For')
            
            if not self.is_vpn_client(client_ip, forwarded):
                logger.warning(f"Non-VPN access attempt from {client_ip}")
                await self._alert_admin(f"Blocked admin access from non-VPN IP: {client_ip}")
                return Response("Access denied. VPN required.", status=403)
            
            return await handler_func(request, *args, **kwargs)
        return wrapper
```

### 4. TLS/SSL Verification

```python
# src/security/network/tls_verifier.py
class TLSVerifier:
    """
    Verify TLS connections to prevent MITM attacks.
    """
    
    ALPACA_CERT_PIN = "sha256/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="  # Example
    
    def create_secure_session(self) -> aiohttp.ClientSession:
        """Create HTTP session with strict TLS verification."""
        
        ssl_context = ssl.create_default_context(
            purpose=ssl.Purpose.SERVER_AUTH,
            cafile=certifi.where()  # Use certifi's CA bundle
        )
        
        # Certificate pinning for Alpaca
        ssl_context.load_verify_locations(cafile="certs/alpaca_root.pem")
        
        # Disable weak ciphers
        ssl_context.set_ciphers('ECDHE+AESGCM:ECDHE+CHACHA20:DHE+AESGCM:DHE+CHACHA20:!aNULL:!MD5:!DSS')
        
        # Minimum TLS 1.2
        ssl_context.minimum_version = ssl.TLSVersion.TLSv1_2
        
        connector = aiohttp.TCPConnector(
            ssl=ssl_context,
            enable_cleanup_closed=True,
            force_close=True,  # Don't reuse connections
        )
        
        return aiohttp.ClientSession(connector=connector)
    
    async def verify_certificate(self, host: str, port: int = 443) -> CertVerificationResult:
        """Verify server certificate."""
        context = ssl.create_default_context()
        
        with socket.create_connection((host, port), timeout=10) as sock:
            with context.wrap_socket(sock, server_hostname=host) as ssock:
                cert = ssock.getpeercert()
                cipher = ssock.cipher()
                version = ssock.version()
                
                return CertVerificationResult(
                    valid=bool(cert),
                    subject=cert.get('subject'),
                    issuer=cert.get('issuer'),
                    not_after=cert.get('notAfter'),
                    cipher=cipher[0],
                    tls_version=version
                )
```

### 5. Network Monitoring

```python
class NetworkMonitor:
    """
    Monitor network traffic for anomalies.
    """
    
    def __init__(self):
        self.connection_log = []
        self.suspicious_patterns = [
            re.compile(r".*malicious-host\.com.*"),
            re.compile(r".*\.onion$"),
        ]
    
    async def log_connection(self, dest_host: str, dest_port: int, 
                            bytes_sent: int, bytes_recv: int) -> None:
        """Log all outbound connections."""
        
        entry = ConnectionLogEntry(
            timestamp=datetime.utcnow(),
            dest_host=dest_host,
            dest_port=dest_port,
            bytes_sent=bytes_sent,
            bytes_recv=bytes_recv,
            process_name="alpaca-bot"
        )
        
        self.connection_log.append(entry)
        
        # Check for suspicious destinations
        for pattern in self.suspicious_patterns:
            if pattern.match(dest_host):
                await self._alert_security_team(
                    f"Suspicious connection detected: {dest_host}:{dest_port}"
                )
        
        # Alert on unexpected destinations
        if dest_host not in FirewallConfigurator.ALLOWED_HOSTS:
            await self._alert_security_team(
                f"Unexpected outbound connection: {dest_host}:{dest_port}"
            )
```

### 6. CLI Commands

```bash
# Apply firewall rules
python -m src.security.network apply-firewall

# Verify network connectivity
python -m src.security.network verify

# Check VPN status
python -m src.security.network vpn-status

# View connection logs
python -m src.security.network connections --last-hour

# Test TLS to Alpaca
python -m src.security.network test-tls --host api.alpaca.markets

# Reset firewall (emergency)
python -m src.security.network reset
```

## Acceptance Criteria

- [ ] Outbound connections restricted to Alpaca APIs only
- [ ] Docker container runs with no-new-privileges and read-only filesystem
- [ ] Admin panel only accessible via VPN subnets
- [ ] TLS 1.2+ required with strong cipher suites
- [ ] Certificate pinning for Alpaca endpoints
- [ ] All outbound connections logged
- [ ] Alert on unexpected network activity
- [ ] Connectivity verification tool
- [ ] Firewall reset capability for emergencies

## Priority
HIGH - Network security is fundamental

## Estimated Effort
2-3 days
