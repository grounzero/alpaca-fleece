# Performance Analytics Module Implementation

## Overview
Implement a comprehensive performance analytics module that calculates risk-adjusted returns and trading metrics from the trade history database. This is critical for evaluating whether the trading strategy is actually profitable or just getting lucky.

## Current State
- Trade data stored in SQLite at `data/trades.db`
- No metrics calculation beyond basic counters
- `src/metrics.py` has runtime counters but no historical analysis

## Required Implementation

### 1. Core Metrics Calculator (`src/analytics/performance.py`)

Create a new module that calculates:

**Risk-Adjusted Returns:**
- Sharpe Ratio: (Return - Risk-free rate) / Standard deviation of returns
- Sortino Ratio: (Return - Risk-free rate) / Downside deviation
- Calmar Ratio: Annualized return / Max drawdown

**Drawdown Metrics:**
- Max Drawdown: Largest peak-to-trough decline
- Max Drawdown Duration: Longest time to recover from drawdown
- Current Drawdown: Drawdown from last equity high

**Trade Statistics:**
- Win Rate: % of profitable trades
- Profit Factor: Gross profit / Gross loss
- Average Win: Mean profit on winning trades
- Average Loss: Mean loss on losing trades
- Win/Loss Ratio: Average win / Average loss
- Expectancy: (Win% × Avg Win) - (Loss% × Avg Loss)

**Time-Based Metrics:**
- Daily/Weekly/Monthly returns
- Volatility (annualized standard deviation)
- Best/Worst trading days

### 2. Data Requirements

Query from `trades.db`:
- `trades` table: entry/exit times, prices, quantities, P&L
- `equity_curve` table: timestamped equity snapshots
- `positions_snapshot` table: current holdings

### 3. API Design

```python
class PerformanceAnalyzer:
    def __init__(self, db_path: str, risk_free_rate: float = 0.05):
        ...
    
    def calculate_metrics(self, start_date: Optional[datetime] = None, 
                         end_date: Optional[datetime] = None) -> MetricsReport:
        """Calculate all metrics for specified period."""
        ...
    
    def get_drawdown_series(self) -> pd.DataFrame:
        """Return equity curve with drawdown calculations."""
        ...
    
    def get_trade_statistics(self) -> TradeStats:
        """Detailed trade-level statistics."""
        ...
    
    def compare_to_benchmark(self, benchmark_symbol: str = "SPY") -> BenchmarkComparison:
        """Alpha, beta, correlation to benchmark."""
        ...
```

### 4. Output Formats

**Console Report:**
```
Performance Report (2026-01-01 to 2026-02-09)
============================================
Total Return:        +12.34%
Annualized Return:   +45.67%
Sharpe Ratio:        1.82
Sortino Ratio:       2.34
Max Drawdown:        -8.92%
Calmar Ratio:        5.12

Trade Statistics:
-----------------
Total Trades:        45
Win Rate:            62.2%
Profit Factor:       1.87
Avg Win:             +$234.56
Avg Loss:            -$123.45
Expectancy:          +$67.89 per trade
```

**JSON Export:** For API consumption
**CSV Export:** For Excel analysis

### 5. Integration Points

- Add to cron job: Daily metrics calculation at market close
- Store results in new `analytics` table or JSON files
- Expose via admin panel (read-only sidekick)
- Alert if Sharpe < 0.5 or max drawdown exceeds 10%

### 6. Testing Requirements

- Unit tests with known trade sequences
- Verify calculations against Excel/manual calculations
- Test with empty database (graceful handling)
- Test with partial data (intraday)

### 7. Performance Considerations

- Cache results for intraday queries
- Incremental updates (don't recalculate entire history daily)
- Use pandas for vectorized calculations

## Acceptance Criteria

- [ ] All metrics calculate correctly for historical data
- [ ] Daily automated report generated and stored
- [ ] CLI command: `python -m src.analytics.report --days 30`
- [ ] JSON export for programmatic access
- [ ] Unit tests with >90% coverage
- [ ] Documentation with formula references

## Priority
CRITICAL - Must have before live trading

## Estimated Effort
3-4 days
