# Multi-Strategy Framework

## Overview
Implement a strategy registry and capital allocation system that allows running multiple strategies simultaneously with different capital allocations, timeframes, and symbol universes. Enables diversification across strategy types and regime-specific performance.

## Current State
- Only `SMACrossover` strategy exists in `src/strategy/sma_crossover.py`
- Strategy is hardcoded in `orchestrator.py`
- No way to run multiple strategies or allocate capital between them
- Strategy changes require code modification

## Required Implementation

### 1. Strategy Registry (`src/strategy/registry.py`)

```python
from typing import Dict, Type, Optional
from abc import ABC, abstractmethod
import importlib

class StrategyRegistry:
    """Central registry for all available strategies."""
    
    _strategies: Dict[str, Type[BaseStrategy]] = {}
    
    @classmethod
    def register(cls, name: str, strategy_class: Type[BaseStrategy]) -> None:
        """Register a strategy class."""
        cls._strategies[name] = strategy_class
        logger.info(f"Registered strategy: {name}")
    
    @classmethod
    def get(cls, name: str) -> Type[BaseStrategy]:
        """Get strategy class by name."""
        if name not in cls._strategies:
            raise ValueError(f"Unknown strategy: {name}. Available: {list(cls._strategies.keys())}")
        return cls._strategies[name]
    
    @classmethod
    def list_strategies(cls) -> Dict[str, StrategyMetadata]:
        """List all registered strategies with metadata."""
        return {
            name: {
                'class': strat.__name__,
                'description': strat.__doc__,
                'params': strat.get_default_params()
            }
            for name, strat in cls._strategies.items()
        }
    
    @classmethod
    def load_from_module(cls, module_path: str) -> None:
        """Auto-discover and register strategies from a module."""
        module = importlib.import_module(module_path)
        for name, obj in inspect.getmembers(module):
            if (inspect.isclass(obj) and 
                issubclass(obj, BaseStrategy) and 
                obj != BaseStrategy):
                cls.register(name.lower().replace('strategy', ''), obj)

# Decorator for easy registration
def register_strategy(name: str):
    """Decorator to register a strategy."""
    def decorator(cls: Type[BaseStrategy]):
        StrategyRegistry.register(name, cls)
        return cls
    return decorator

# Usage in strategy files:
@register_strategy("sma_crossover")
class SMACrossover(BaseStrategy):
    ...

@register_strategy("mean_reversion")
class MeanReversionStrategy(BaseStrategy):
    ...

@register_strategy("momentum")
class MomentumStrategy(BaseStrategy):
    ...
```

### 2. Enhanced Base Strategy Class

```python
class BaseStrategy(ABC):
    """Enhanced base class with configuration and metadata support."""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        self.name = self.__class__.__name__
        self.enabled = True
        self.performance_stats = StrategyPerformance()
    
    @property
    @abstractmethod
    def name(self) -> str:
        pass
    
    @property
    @abstractmethod
    def description(self) -> str:
        """Human-readable strategy description."""
        pass
    
    @property
    @abstractmethod
    def timeframe(self) -> str:
        """Primary timeframe (1Min, 5Min, 1H, etc.)."""
        pass
    
    @property
    @abstractmethod
    def universe(self) -> List[str]:
        """Symbols this strategy trades."""
        pass
    
    @abstractmethod
    async def on_bar(self, symbol: str, df: pd.DataFrame) -> List[SignalEvent]:
        pass
    
    @abstractmethod
    def get_required_history(self, symbol: str | None = None) -> int:
        pass
    
    # Optional hooks
    async def on_market_open(self) -> None:
        """Called at market open."""
        pass
    
    async def on_market_close(self) -> None:
        """Called at market close."""
        pass
    
    async def on_position_update(self, position: Position) -> None:
        """Called when position changes."""
        pass
    
    def get_allocation_weight(self, regime: MarketRegime) -> float:
        """Dynamic allocation based on market regime."""
        return 1.0  # Default: equal weight
    
    def record_performance(self, trade_pnl: float) -> None:
        """Record trade result for strategy evaluation."""
        self.performance_stats.add_trade(trade_pnl)
```

### 3. Strategy Configuration (`config/strategies.yaml`)

```yaml
strategies:
  sma_crossover:
    enabled: true
    allocation_pct: 40  # 40% of capital
    symbols: [AAPL, MSFT, GOOGL, NVDA, QQQ, SPY]
    params:
      fast_period: 10
      slow_period: 30
      timeframe: 1Min
    risk_limits:
      max_position_pct: 0.10
      max_trades_per_day: 10
    
  mean_reversion:
    enabled: true
    allocation_pct: 30  # 30% of capital
    symbols: [TSLA, COIN, MSTR, ARKK]  # High volatility
    params:
      lookback_period: 20
      zscore_threshold: 2.0
      timeframe: 5Min  # Slower timeframe
    risk_limits:
      max_position_pct: 0.08  # Smaller positions
      max_trades_per_day: 5
      
  momentum:
    enabled: true
    allocation_pct: 30
    symbols: [META, NFLX, UBER, AMD]
    params:
      momentum_period: 10
      volume_threshold: 1.5
      timeframe: 1Min
    risk_limits:
      max_position_pct: 0.10
      max_trades_per_day: 8

# Dynamic allocation based on regime
regime_allocation:
  trending:  # When market is trending
    sma_crossover: 0.50  # Increase trend-following
    mean_reversion: 0.20  # Reduce mean reversion
    momentum: 0.30
    
  ranging:  # When market is ranging
    sma_crossover: 0.20  # Reduce trend-following
    mean_reversion: 0.50  # Increase mean reversion
    momentum: 0.30
```

### 4. Capital Allocator (`src/strategy/allocator.py`)

```python
class CapitalAllocator:
    """Allocate capital across multiple strategies."""
    
    def __init__(self, total_capital: float, strategies: List[StrategyConfig]):
        self.total_capital = total_capital
        self.strategies = strategies
        self.allocations: Dict[str, float] = {}
        self._calculate_allocations()
    
    def _calculate_allocations(self) -> None:
        """Calculate capital allocation per strategy."""
        total_allocation = sum(s.allocation_pct for s in self.strategies if s.enabled)
        
        for strategy in self.strategies:
            if strategy.enabled:
                self.allocations[strategy.name] = (
                    self.total_capital * strategy.allocation_pct / total_allocation
                )
    
    def adjust_for_regime(self, regime: MarketRegime) -> None:
        """Dynamically adjust allocations based on market regime."""
        regime_weights = REGIME_ALLOCATIONS.get(regime, {})
        
        new_allocations = {}
        for strategy in self.strategies:
            if strategy.enabled:
                weight = regime_weights.get(strategy.name, strategy.allocation_pct / 100)
                new_allocations[strategy.name] = self.total_capital * weight
        
        self.allocations = new_allocations
        logger.info(f"Adjusted allocations for {regime} regime: {self.allocations}")
    
    def get_strategy_capital(self, strategy_name: str) -> float:
        """Get allocated capital for a specific strategy."""
        return self.allocations.get(strategy_name, 0)
    
    def rebalance(self, strategy_performance: Dict[str, float]) -> None:
        """Rebalance based on recent performance (momentum allocation)."""
        # Increase allocation to better-performing strategies
        # (with constraints to prevent concentration)
        ...
```

### 5. Multi-Strategy Orchestrator

```python
class MultiStrategyOrchestrator:
    """Orchestrator that runs multiple strategies concurrently."""
    
    def __init__(self, config_path: str):
        self.config = self._load_strategy_config(config_path)
        self.strategies: Dict[str, BaseStrategy] = {}
        self.allocators: Dict[str, CapitalAllocator] = {}
        self.event_bus = EventBus()
        
    async def initialize(self) -> None:
        """Initialize all configured strategies."""
        StrategyRegistry.load_from_module('src.strategy')
        
        for strat_config in self.config.strategies:
            if not strat_config.enabled:
                continue
            
            # Instantiate strategy with config
            strategy_class = StrategyRegistry.get(strat_config.name)
            strategy = strategy_class(strat_config.params)
            
            # Create isolated allocator for this strategy
            allocator = CapitalAllocator(
                capital=strat_config.allocated_capital,
                risk_limits=strat_config.risk_limits
            )
            
            self.strategies[strat_config.name] = strategy
            self.allocators[strat_config.name] = allocator
            
            logger.info(f"Initialized {strat_config.name} with ${strat_config.allocated_capital:,.2f}")
    
    async def on_bar(self, symbol: str, df: pd.DataFrame) -> None:
        """Process bar data for all strategies that trade this symbol."""
        
        for name, strategy in self.strategies.items():
            if symbol not in strategy.universe:
                continue
            
            # Check if strategy has available capital
            allocator = self.allocators[name]
            if allocator.get_available_capital() <= 0:
                continue
            
            # Generate signals
            signals = await strategy.on_bar(symbol, df)
            
            # Tag signals with strategy name for tracking
            for signal in signals:
                signal.metadata['strategy'] = name
                signal.metadata['allocated_capital'] = allocator.get_strategy_capital(name)
            
            # Route to risk manager with strategy-specific limits
            await self.process_signals(signals, strategy)
    
    async def process_signals(self, signals: List[SignalEvent], 
                             strategy: BaseStrategy) -> None:
        """Process signals with strategy-specific risk limits."""
        
        for signal in signals:
            # Use strategy-specific risk manager
            risk_manager = self.get_risk_manager_for_strategy(strategy.name)
            
            if await risk_manager.check_signal(signal):
                # Adjust position size for strategy allocation
                adjusted_signal = self._adjust_for_allocation(signal, strategy.name)
                await self.submit_order(adjusted_signal)
```

### 6. Strategy Performance Tracker

```python
class StrategyPerformanceTracker:
    """Track performance of each strategy independently."""
    
    def __init__(self, db_path: str):
        self.db = db_path
        
    async def record_trade(self, trade: Trade, strategy_name: str) -> None:
        """Record trade attributed to specific strategy."""
        ...
    
    async def get_strategy_metrics(self, strategy_name: str, 
                                   period: str = "30d") -> StrategyMetrics:
        """Get isolated metrics for a single strategy."""
        ...
    
    async def compare_strategies(self) -> ComparisonReport:
        """Compare all strategies head-to-head."""
        ...
    
    def detect_underperformers(self, threshold: float = -0.05) -> List[str]:
        """Identify strategies with negative alpha."""
        ...
```

### 7. New Strategy Examples

**Mean Reversion Strategy:**
```python
@register_strategy("mean_reversion")
class MeanReversionStrategy(BaseStrategy):
    """
    Mean reversion strategy for high-volatility symbols.
    Enters when price deviates significantly from moving average.
    """
    
    def __init__(self, config: Dict):
        super().__init__(config)
        self.lookback = config.get('lookback_period', 20)
        self.zscore_threshold = config.get('zscore_threshold', 2.0)
    
    async def on_bar(self, symbol: str, df: pd.DataFrame) -> List[SignalEvent]:
        if len(df) < self.lookback:
            return []
        
        # Calculate z-score
        mean = df['close'].rolling(self.lookback).mean().iloc[-1]
        std = df['close'].rolling(self.lookback).std().iloc[-1]
        current = df['close'].iloc[-1]
        zscore = (current - mean) / std
        
        signals = []
        if zscore < -self.zscore_threshold:
            # Price too low, expect reversion up
            signals.append(SignalEvent(
                symbol=symbol,
                side=OrderSide.BUY,
                confidence=min(abs(zscore) / 3, 1.0),
                metadata={'zscore': zscore, 'mean': mean}
            ))
        elif zscore > self.zscore_threshold:
            # Price too high, expect reversion down
            signals.append(SignalEvent(
                symbol=symbol,
                side=OrderSide.SELL,
                confidence=min(abs(zscore) / 3, 1.0),
                metadata={'zscore': zscore, 'mean': mean}
            ))
        
        return signals
```

**Momentum Strategy:**
```python
@register_strategy("momentum")
class MomentumStrategy(BaseStrategy):
    """
    Momentum strategy that rides trends with volume confirmation.
    """
    
    def __init__(self, config: Dict):
        super().__init__(config)
        self.momentum_period = config.get('momentum_period', 10)
        self.volume_threshold = config.get('volume_threshold', 1.5)
    
    async def on_bar(self, symbol: str, df: pd.DataFrame) -> List[SignalEvent]:
        if len(df) < self.momentum_period + 5:
            return []
        
        # Price momentum
        returns = df['close'].pct_change(self.momentum_period).iloc[-1]
        
        # Volume confirmation
        avg_volume = df['volume'].rolling(20).mean().iloc[-1]
        current_volume = df['volume'].iloc[-1]
        volume_confirmed = current_volume > avg_volume * self.volume_threshold
        
        signals = []
        if returns > 0.05 and volume_confirmed:  # 5% gain with volume
            signals.append(SignalEvent(
                symbol=symbol,
                side=OrderSide.BUY,
                confidence=min(returns * 10, 1.0),
                metadata={'momentum': returns, 'volume_ratio': current_volume/avg_volume}
            ))
        elif returns < -0.05 and volume_confirmed:
            signals.append(SignalEvent(
                symbol=symbol,
                side=OrderSide.SELL,
                confidence=min(abs(returns) * 10, 1.0),
                metadata={'momentum': returns, 'volume_ratio': current_volume/avg_volume}
            ))
        
        return signals
```

### 8. CLI for Strategy Management

```bash
# List available strategies
python -m src.strategy.cli list

# Add new strategy to config
python -m src.strategy.cli add mean_reversion \
    --allocation 30 \
    --symbols TSLA,COIN,MSTR \
    --params '{"lookback_period": 20, "zscore_threshold": 2.0}'

# Enable/disable strategy
python -m src.strategy.cli disable momentum
python -m src.strategy.cli enable mean_reversion

# View strategy performance
python -m src.strategy.cli performance --strategy sma_crossover --period 30d

# Compare all strategies
python -m src.strategy.cli compare --period 90d --plot

# Rebalance allocations
python -m src.strategy.cli rebalance --sma_crossover 50 --mean_reversion 25 --momentum 25
```

## Acceptance Criteria

- [ ] Strategy registry with auto-discovery
- [ ] Multiple strategies can run simultaneously
- [ ] Capital allocation per strategy (fixed or regime-based)
- [ ] Strategy-specific risk limits
- [ ] Isolated performance tracking per strategy
- [ ] At least 3 working strategies (trend, mean reversion, momentum)
- [ ] Dynamic regime-based allocation switching
- [ ] CLI for strategy management
- [ ] Strategy comparison and attribution reporting
- [ ] Can disable/enable strategies without restart

## Priority
MEDIUM - Important for diversification and robustness

## Estimated Effort
7-10 days
