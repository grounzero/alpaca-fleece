# Performance Reporting System

## Overview
Implement automated daily, weekly, and monthly performance reports that generate human-readable summaries, tax-ready exports, and trading journals. Eliminates manual database queries for routine analysis.

## Current State
- Raw data in SQLite (`trades.db`, `equity_curve` table)
- `metrics.py` tracks runtime counters
- No automated reporting or export functionality
- User must query database manually for analysis

## Required Implementation

### 1. Report Generator Module (`src/reporting/generator.py`)

```python
from enum import Enum
from dataclasses import dataclass
from datetime import datetime, date
from typing import Optional, List

class ReportPeriod(Enum):
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    QUARTERLY = "quarterly"
    ANNUAL = "annual"
    CUSTOM = "custom"

@dataclass
class PerformanceReport:
    period: ReportPeriod
    start_date: date
    end_date: date
    generated_at: datetime
    
    # Trading metrics
    total_trades: int
    winning_trades: int
    losing_trades: int
    win_rate: float
    gross_profit: float
    gross_loss: float
    net_pnl: float
    
    # Equity metrics
    starting_equity: float
    ending_equity: float
    return_pct: float
    max_drawdown_pct: float
    
    # Risk metrics
    sharpe_ratio: float
    volatility_annualized: float
    
    # Trade list
    trades: List[TradeDetail]
    
    # Additional sections
    daily_pnls: List[DailyPnl]
    sector_breakdown: Dict[str, float]
    strategy_notes: Optional[str]

class ReportGenerator:
    def __init__(self, db_path: str, analytics: PerformanceAnalyzer):
        self.db = db_path
        self.analytics = analytics
    
    async def generate_daily_report(self, report_date: date) -> PerformanceReport:
        """Generate report for a single trading day."""
        ...
    
    async def generate_period_report(
        self, 
        start: date, 
        end: date,
        period_type: ReportPeriod
    ) -> PerformanceReport:
        """Generate report for arbitrary date range."""
        ...
    
    async def export_to_csv(self, report: PerformanceReport, filepath: str):
        """Export trades to CSV for Excel analysis."""
        ...
    
    async def export_to_pdf(self, report: PerformanceReport, filepath: str):
        """Generate formatted PDF report."""
        ...
```

### 2. Report Storage

Store generated reports for historical access:

```sql
CREATE TABLE generated_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    report_type TEXT NOT NULL,  -- daily, weekly, monthly
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    json_data TEXT NOT NULL,  -- Full report as JSON
    csv_path TEXT,  -- Path to CSV export
    pdf_path TEXT,  -- Path to PDF export
    is_tax_relevant BOOLEAN DEFAULT FALSE
);

CREATE INDEX idx_reports_date ON generated_reports(period_start, period_end);
CREATE INDEX idx_reports_type ON generated_reports(report_type);
```

### 3. Daily Report Format (WhatsApp/Email)

```
📊 Daily Trading Report - Monday, Feb 9, 2026
==============================================

💰 P&L Summary:
   Starting Equity:  $102,345.67
   Ending Equity:    $102,456.78
   Daily P&L:        +$111.11 (+0.11%)
   Daily Trades:     3

📈 Trade Details:
   1. AAPL  BUY  100 @ $182.50 → SELL @ $183.20 | +$70.00 ✅
   2. MSFT  BUY   50 @ $420.00 → SELL @ $419.50 | -$25.00 ❌
   3. TSLA  BUY   25 @ $220.00 → SELL @ $223.00 | +$75.00 ✅

📊 Cumulative Stats:
   Win Rate:         66.7% (2/3)
   Avg Win:          +$72.50
   Avg Loss:         -$25.00
   Profit Factor:    5.67

🎯 Open Positions:
   - NVDA: 20 shares @ $680.00 avg (unrealized: +$120)

⚠️ Risk Status:
   Daily Loss Limit:  2.0% used
   Max Position:      8.2% of equity
   Portfolio Beta:    1.12
```

### 4. Monthly Report Format (Detailed)

```
MONTHLY PERFORMANCE REPORT
February 2026
Generated: March 1, 2026

EXECUTIVE SUMMARY
-----------------
Starting Equity:        $100,000.00
Ending Equity:          $104,567.89
Monthly Return:         +4.57%
Benchmark (SPY):        +2.34%
Alpha:                  +2.23%

TRADING STATISTICS
------------------
Total Trades:           45
Winning Trades:         28 (62.2%)
Losing Trades:          17 (37.8%)
Win/Loss Ratio:         1.85
Profit Factor:          3.04
Expectancy per Trade:   +$101.51

RISK METRICS
------------
Max Drawdown:           -3.45%
Sharpe Ratio:           2.14
Sortino Ratio:          3.21
Volatility (Annual):    18.5%
Calmar Ratio:           5.28

SECTOR PERFORMANCE
------------------
Technology:     +$1,234 (8 trades)
Healthcare:     +$567  (5 trades)
Finance:        -$123  (3 trades)

BEST/WORST TRADES
-----------------
Best:  NVDA  +$345.67 (Feb 15)
Worst: XOM   -$89.45  (Feb 8)

TAX SUMMARY (UK)
----------------
Capital Gains:          +$4,567.89
Realized Losses:        -$890.12
Net Taxable Gain:       +$3,677.77
Dividends Received:     +$45.67
US Withholding:         -$6.85
UK Tax Estimate:        ~$735.55 (at 20%)

NOTES
-----
- Strategy performed well in trending market
- Reduced position sizes during high VIX period (Feb 20-22)
- Implemented new correlation filter on Feb 18
```

### 5. CSV Export Format

**trades_export_2026-02-01_2026-02-28.csv:**
```csv
Trade ID,Symbol,Side,Entry Date,Entry Price,Exit Date,Exit Price,Quantity,Commission,Realized P&L,Holding Days,Entry Signal,Exit Reason
T001,AAPL,BUY,2026-02-05,182.50,2026-02-05,183.20,100,0.35,69.65,0,SMA_CROSSOVER,PROFIT_TARGET
T002,MSFT,BUY,2026-02-05,420.00,2026-02-05,419.50,50,0.15,-25.15,0,SMA_CROSSOVER,STOP_LOSS
...
```

**equity_curve_2026-02-01_2026-02-28.csv:**
```csv
Date,Equity,Daily P&L,Cumulative P&L,Drawdown %
2026-02-01,100000.00,0.00,0.00,0.00
2026-02-02,100123.45,123.45,123.45,0.00
...
```

### 6. Trading Journal Integration

Allow manual notes on trades:

```sql
CREATE TABLE trade_journal (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trade_id TEXT REFERENCES trades(id),
    entry_note TEXT,  -- Why did I take this trade?
    exit_note TEXT,   -- Thoughts on exit
    lesson_learned TEXT,
    would_take_again BOOLEAN,
    mood TEXT,  -- "confident", "fearful", "impatient"
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

```python
class TradingJournal:
    async def add_entry(self, trade_id: str, entry_note: str, 
                       mood: str = None) -> None:
        ...
    
    async def add_exit_reflection(self, trade_id: str, exit_note: str,
                                   lesson: str) -> None:
        ...
    
    async def get_entries_for_period(self, start: date, end: date) -> List[JournalEntry]:
        ...
```

### 7. Scheduled Report Generation

Update cron to generate reports:

```python
# config/cron_jobs.py or similar
REPORT_SCHEDULE = {
    "daily_report": {
        "schedule": "0 17 * * 1-5",  # 5 PM UTC on weekdays (after market close)
        "action": "generate_daily_report",
        "channels": ["whatsapp", "email"]
    },
    "weekly_report": {
        "schedule": "0 18 * * 5",  # Friday 6 PM UTC
        "action": "generate_weekly_report",
        "channels": ["email"]
    },
    "monthly_report": {
        "schedule": "0 9 1 * *",  # 1st of month 9 AM UTC
        "action": "generate_monthly_report",
        "channels": ["email"],
        "include_tax_summary": True
    }
}
```

### 8. Report Delivery

```python
class ReportDelivery:
    async def send_whatsapp(self, report: PerformanceReport) -> None:
        """Send condensed report to WhatsApp."""
        message = self.format_for_whatsapp(report)
        await self.whatsapp_client.send(message)
    
    async def send_email(self, report: PerformanceReport, 
                        attachments: List[str]) -> None:
        """Send full report with CSV/PDF attachments."""
        ...
    
    async def save_to_disk(self, report: PerformanceReport,
                          base_path: str = "reports/") -> Dict[str, str]:
        """Save all formats to disk."""
        paths = {
            "json": f"{base_path}/{report.period.value}_{report.start_date}.json",
            "csv": f"{base_path}/{report.period.value}_{report.start_date}_trades.csv",
            "pdf": f"{base_path}/{report.period.value}_{report.start_date}.pdf"
        }
        ...
        return paths
```

### 9. Tax Year Report (UK Specific)

Generate end-of-tax-year report for HMRC:

```
TAX YEAR 2025/26 REPORT (6 Apr 2025 - 5 Apr 2026)
===================================================

Capital Gains Summary:
----------------------
Total Disposals:          245 trades
Total Proceeds:           $145,678.90
Total Cost Basis:         $140,123.45
Total Gains:              +$8,234.56
Total Losses:             -$2,679.11
Net Capital Gain:         +$5,555.45

Section 104 Holdings:
---------------------
AAPL: 150 shares @ blended avg $175.34
MSFT: 75 shares @ blended avg $410.22
...

Bed and Breakfast Rule:
-----------------------
No matching trades within 30 days (checked 245 transactions)

Foreign Income:
---------------
US Dividends Received:    $234.56
US Tax Withheld (15%):    -$35.18
Net Dividends:            $199.38

HMRC Reporting Ready:
- Box XX: $5,555.45 (Net gains)
- Box XX: $199.38 (Foreign dividends)
- Foreign Tax Credit: $35.18
```

### 10. Interactive Report CLI

```bash
# Generate and view daily report
python -m src.reporting.cli daily --date 2026-02-09 --format console

# Export month to CSV
python -m src.reporting.cli export --start 2026-02-01 --end 2026-02-28 --format csv --output ./feb_2026.csv

# Generate tax year report
python -m src.reporting.cli tax-year 2025 --format pdf --output ./tax_2025_26.pdf

# View specific trade with journal
python -m src.reporting.cli trade T001 --with-journal
```

## Acceptance Criteria

- [ ] Daily reports auto-generated at market close (5 PM ET)
- [ ] Weekly summary every Friday evening
- [ ] Monthly comprehensive report with tax data
- [ ] CSV exports match HMRC requirements
- [ ] PDF reports formatted professionally
- [ ] Reports stored in database for historical access
- [ ] WhatsApp delivery for daily summaries
- [ ] Email delivery with attachments for weekly/monthly
- [ ] Trading journal interface for manual notes
- [ ] CLI tool for on-demand report generation
- [ ] Tax year report ready for accountant

## Priority
MEDIUM - Important for operational visibility and tax compliance

## Estimated Effort
4-5 days
