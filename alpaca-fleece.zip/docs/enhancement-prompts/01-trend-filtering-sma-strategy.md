# Technical Specification: Trend Filtering for SMA Crossover Strategy

**Document ID:** 11-trend-filtering-sma-strategy  
**Status:** Draft  
**Priority:** HIGH  
**Target Branch:** `feat/signal-dedupe`  
**Related:** 06-multi-strategy-framework.md

---

## 1. Problem Statement

### Current Performance Issues

Recent trading results have identified critical problems with the existing SMA Crossover strategy:

| Metric | Current | Target |
|--------|---------|--------|
| Trade Count (2 days) | 75 trades | < 25 trades |
| P&L | -$1,553 (-1.56%) | Positive |
| Lookback Period | ~100 minutes (100 bars) | 200-500 minutes |
| Stop Loss Hits | -1.5% to -2.6% | Reduce by 50% |
| Duplicate Signals | TSLA bought twice in 3 hours | Zero duplicates |

### Root Cause Analysis

1. **Insufficient Lookback**: The current 100-minute lookback provides insufficient context for the slowest SMA pair (20,50), leading to premature signals based on noise rather than genuine trend changes.

2. **No Higher-Timeframe Context**: The strategy operates solely on 1-minute bars without reference to daily trends, causing counter-trend trades that fight the primary market direction.

3. **Low Signal Quality**: Signals lack volume confirmation, volatility filtering, or time-of-day context, resulting in trades during low-probability periods.

4. **Regime Detection Limitations**: While regime detection exists, it only uses intraday data and doesn't filter trades against the broader market trend.

---

## 2. Goals

### Primary Goals

1. **Reduce Trade Churn by 50-70%**: Filter out low-quality signals while preserving high-probability setups
2. **Improve Win Rate**: Trade only in direction of daily trend
3. **Better Risk-Adjusted Returns**: Target Sharpe ratio improvement from negative to > 1.0
4. **Maintain Backward Compatibility**: All filters can be disabled via configuration

### Secondary Goals

1. **Configurable Lookback**: Allow strategy-specific lookback periods (200-500 bars default)
2. **Volume Confirmation**: Only trade on above-average volume
3. **Volatility Filtering**: Skip trades during low-volatility regimes
4. **Time-of-Day Awareness**: Optional filtering around market open/close

---

## 3. Architecture

### System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                  TREND FILTERING STRATEGY                        │
├─────────────────────────────────────────────────────────────────┤
│  TIER 1: TREND BIAS                                             │
│  ┌──────────────┐  ┌──────────────┐                            │
│  │ Daily Bars   │  │ 5-Min Bars   │                            │
│  │ (20-day SMA) │  │ (Structure)  │                            │
│  └──────┬───────┘  └──────┬───────┘                            │
│         │                 │                                     │
│         ▼                 ▼                                     │
│  ┌──────────────────────────────────┐                          │
│  │  TIER 2: EXECUTION TRIGGER       │                          │
│  │  ┌──────────────────────────┐    │                          │
│  │  │ 1-Minute Bars            │    │                          │
│  │  │ SMA Crossover (5,15)     │    │                          │
│  │  │ SMA Crossover (10,30)    │    │                          │
│  │  │ SMA Crossover (20,50)    │    │                          │
│  │  └───────────┬──────────────┘    │                          │
│  │              │                    │                          │
│  │              ▼                    │                          │
│  │  ┌──────────────────────────┐    │                          │
│  │  │ Signal Quality Filters   │    │                          │
│  │  │ • Volume                 │    │                          │
│  │  │ • Volatility             │    │                          │
│  │  │ • Time-of-day            │    │                          │
│  │  └───────────┬──────────────┘    │                          │
│  └──────────────┼───────────────────┘                          │
│                 │                                               │
│                 ▼                                               │
│  ┌──────────────────────────────────┐                          │
│  │  TIER 3: RISK MANAGEMENT         │                          │
│  │  • VWAP stops                    │                          │
│  │  • ATR-based sizing              │                          │
│  └──────────────────────────────────┘                          │
└─────────────────────────────────────────────────────────────────┘
```

### Component Interaction

```
Data Flow:
──────────
BarsHandler (1-min) ──► SMACrossover.on_bar()
                              │
                              ▼
BarsHandler (daily) ──► daily_df cache
                              │
                              ▼
                    ┌─────────────────┐
                    │ TrendFilter     │
                    │ • check_daily() │
                    │ • check_volume()│
                    │ • check_vol()   │
                    │ • check_time()  │
                    └────────┬────────┘
                             │
                    Pass? ──► SignalEvent
                    Fail? ──► [] (no signal)
```

---

## 4. Implementation Details

### 4.1 Configurable Lookback Periods

**Current State:**
```python
# BarsHandler.__init__
history_size: int = 100

# SMACrossover.get_required_history
return 51  # 50 for SMA(20,50) + 1 for crossover
```

**Required Changes:**

1. **BarsHandler** - Support configurable history size:
```python
class BarsHandler:
    def __init__(
        self,
        state_store: StateStore,
        event_bus: EventBus,
        market_data_client: MarketDataClient,
        history_size: int = 200,  # Increased from 100
    ) -> None:
```

2. **SMACrossover** - Dynamic history based on strategy config:
```python
def __init__(self, config: Optional[dict] = None) -> None:
    self.config = config or {}
    self.lookback_bars = self.config.get('lookback_bars', 200)
    
def get_required_history(self, symbol: Optional[str] = None) -> int:
    # Need longest SMA period + lookback for trend context
    return max(51, self.lookback_bars)
```

3. **Config Addition** (`trading.yaml`):
```yaml
strategy:
  name: sma_crossover
  params:
    lookback_bars: 200  # 3+ hours of 1-min data
    daily_trend_filter:
      enabled: true
      sma_period: 20    # 20-day SMA for trend
    volume_filter:
      enabled: true
      min_ratio: 1.2    # 1.2x average volume
    volatility_filter:
      enabled: true
      min_atr_pct: 0.005  # 0.5% minimum ATR
    time_filter:
      enabled: true
      skip_first_minutes: 15  # Skip first 15 min after open
      skip_last_minutes: 15   # Skip last 15 min before close
```

### 4.2 Daily Trend Filter (Primary)

**Architecture:**

```python
class TrendFilter:
    """Multi-layer filter for signal quality."""
    
    def __init__(self, config: dict, market_data_client: MarketDataClient):
        self.config = config
        self.market_data = market_data_client
        self.daily_cache: dict[str, pd.DataFrame] = {}
        self.last_update: dict[str, datetime] = {}
        
    async def initialize_daily_data(self, symbols: list[str]) -> None:
        """Pre-fetch daily bars for all traded symbols."""
        for symbol in symbols:
            await self._update_daily_bars(symbol)
    
    async def _update_daily_bars(self, symbol: str) -> None:
        """Fetch/update daily bars (cached, refreshed every hour)."""
        now = datetime.now(timezone.utc)
        
        # Refresh if cache miss or older than 1 hour
        if (symbol not in self.last_update or 
            (now - self.last_update[symbol]).seconds > 3600):
            
            df = self.market_data.get_bars(
                symbol=symbol,
                timeframe='1Day',
                limit=60  # 60 days for 50-day SMA + buffer
            )
            self.daily_cache[symbol] = df
            self.last_update[symbol] = now
    
    def check_daily_trend(self, symbol: str, signal_type: str) -> tuple[bool, dict]:
        """Check if signal aligns with daily trend.
        
        Returns:
            (pass: bool, metadata: dict)
        """
        if not self.config.get('daily_trend_filter', {}).get('enabled', True):
            return True, {'filter': 'daily_trend', 'skipped': False}
        
        df = self.daily_cache.get(symbol)
        if df is None or len(df) < 50:
            return True, {'filter': 'daily_trend', 'skipped': False, 'reason': 'no_data'}
        
        sma_period = self.config['daily_trend_filter'].get('sma_period', 20)
        daily_sma = df['close'].rolling(sma_period).mean().iloc[-1]
        last_close = df['close'].iloc[-1]
        
        # Price relative to daily SMA determines trend
        trend_up = last_close > daily_sma
        trend_down = last_close < daily_sma
        
        # Signal must align with daily trend
        if signal_type == 'BUY' and trend_up:
            return True, {
                'filter': 'daily_trend',
                'skipped': False,
                'daily_sma': daily_sma,
                'daily_close': last_close,
                'trend': 'up'
            }
        elif signal_type == 'SELL' and trend_down:
            return True, {
                'filter': 'daily_trend',
                'skipped': False,
                'daily_sma': daily_sma,
                'daily_close': last_close,
                'trend': 'down'
            }
        
        # Counter-trend signal - filtered out
        return False, {
            'filter': 'daily_trend',
            'skipped': True,
            'daily_sma': daily_sma,
            'daily_close': last_close,
            'trend': 'up' if trend_up else 'down',
            'signal': signal_type,
            'reason': 'counter_trend'
        }
```

**Integration in SMACrossover:**

```python
async def on_bar(self, symbol: str, df: pd.DataFrame) -> list[SignalEvent]:
    if len(df) < self.get_required_history():
        return []
    
    signals: list[SignalEvent] = []
    regime = self._detect_regime(df)
    atr = self._calculate_atr(df)
    
    for fast_period, slow_period in self.periods:
        signal = self._check_crossover(symbol, df, fast_period, slow_period, atr)
        
        if signal:
            # Apply trend filter
            pass_filter, filter_meta = self.trend_filter.check_daily_trend(
                symbol, signal.signal_type
            )
            
            if not pass_filter:
                logger.info(
                    "Filtered %s signal for %s: counter-trend (daily SMA: %.2f)",
                    signal.signal_type, symbol, filter_meta.get('daily_sma', 0)
                )
                continue
            
            # Apply additional filters
            if not self._check_volume_filter(symbol, df):
                continue
                
            if not self._check_volatility_filter(df, atr):
                continue
            
            # Score and emit signal
            confidence = self._score_confidence(fast_period, slow_period, regime)
            signal.metadata["confidence"] = confidence
            signal.metadata["regime"] = regime["regime"]
            signal.metadata["filter_meta"] = filter_meta
            
            signals.append(signal)
    
    return signals
```

### 4.3 5-Minute Structure Filter

**Purpose:** Confirm 1-minute signals against 5-minute structure to ensure trades align with higher-timeframe momentum.

**Architecture:**
```
Daily (trend) → 5-Min (structure) → 1-Min (execution)
```

**Implementation:**

```python
class TrendFilter:
    """Multi-layer filter for signal quality."""
    
    def __init__(self, config: dict, market_data_client: MarketDataClient):
        self.config = config
        self.market_data = market_data_client
        self.five_min_cache: dict[str, pd.DataFrame] = {}
        
    async def initialize_five_min_data(self, symbols: list[str]) -> None:
        """Pre-fetch 5-minute bars for all traded symbols."""
        for symbol in symbols:
            await self._update_five_min_bars(symbol)
    
    async def _update_five_min_bars(self, symbol: str) -> None:
        """Fetch/update 5-minute bars (cached, refreshed every 5 minutes)."""
        now = datetime.now(timezone.utc)
        
        # Refresh if cache miss or older than 5 minutes
        if (symbol not in self.five_min_cache or 
            (now - self.five_min_cache[symbol].index[-1]).seconds > 300):
            
            df = self.market_data.get_bars(
                symbol=symbol,
                timeframe='5Min',
                limit=60  # 60 bars = 5 hours of data
            )
            self.five_min_cache[symbol] = df
    
    def check_five_minute_structure(self, symbol: str, signal_type: str) -> tuple[bool, dict]:
        """Check if signal aligns with 5-minute structure.
        
        Returns:
            (pass: bool, metadata: dict)
        """
        config = self.config.get('five_minute_filter', {})
        if not config.get('enabled', True):
            return True, {'filter': 'five_minute', 'skipped': False}
        
        df = self.five_min_cache.get(symbol)
        if df is None or len(df) < 20:
            return True, {'filter': 'five_minute', 'skipped': False, 'reason': 'no_data'}
        
        ema_period = config.get('ema_period', 20)
        ema = df['close'].ewm(span=ema_period).mean().iloc[-1]
        last_close = df['close'].iloc[-1]
        
        # Check trend alignment with 5-min EMA
        trend_up = last_close > ema
        trend_down = last_close < ema
        
        # RSI check if enabled
        rsi_pass = True
        if config.get('rsi_enabled', True):
            delta = df['close'].diff()
            gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
            rs = gain / loss
            rsi = 100 - (100 / (1 + rs)).iloc[-1]
            
            rsi_low = config.get('rsi_low', 30)
            rsi_high = config.get('rsi_high', 70)
            rsi_pass = rsi_low < rsi < rsi_high
        
        # Volume check if enabled
        volume_pass = True
        if config.get('volume_enabled', True) and len(df) >= 20:
            current_vol = df['volume'].iloc[-1]
            avg_vol = df['volume'].rolling(20).mean().iloc[-1]
            volume_pass = current_vol > avg_vol
        
        # Combine checks
        if signal_type == 'BUY':
            passed = trend_up and rsi_pass and volume_pass
            trend = 'up' if trend_up else 'down'
        else:  # SELL
            passed = trend_down and rsi_pass and volume_pass
            trend = 'down' if trend_down else 'up'
        
        return passed, {
            'filter': 'five_minute',
            'skipped': not passed,
            'ema': ema,
            'price': last_close,
            'trend': trend,
            'signal': signal_type,
            'reason': 'structure_misalignment' if not passed else None,
            'rsi': rsi if config.get('rsi_enabled') else None,
            'volume_pass': volume_pass
        }
```

**Configuration:**

```yaml
# 5-Minute Structure Filter
five_minute_filter:
  enabled: true
  ema_period: 20           # 5-min EMA period for trend
  rsi_enabled: true        # Enable RSI filter
  rsi_low: 30              # Lower RSI bound
  rsi_high: 70             # Upper RSI bound
  volume_enabled: true     # Require above-average 5-min volume
```

### 4.4 Signal Quality Filters

**Volume Confirmation:**

```python
def _check_volume_filter(self, symbol: str, df: pd.DataFrame) -> bool:
    """Require volume above average for signal confirmation."""
    if not self.config.get('volume_filter', {}).get('enabled', False):
        return True
    
    if len(df) < 20:
        return True  # Not enough data, allow signal
    
    current_volume = df['volume'].iloc[-1]
    avg_volume = df['volume'].rolling(20).mean().iloc[-1]
    
    if avg_volume == 0:
        return True
    
    volume_ratio = current_volume / avg_volume
    min_ratio = self.config['volume_filter'].get('min_ratio', 1.2)
    
    return volume_ratio >= min_ratio
```

**Volatility Filter:**

```python
def _check_volatility_filter(self, df: pd.DataFrame, atr: Optional[float]) -> bool:
    """Skip low-volatility periods where breakouts are less reliable."""
    if not self.config.get('volatility_filter', {}).get('enabled', False):
        return True
    
    if atr is None or len(df) < 2:
        return True
    
    current_price = df['close'].iloc[-1]
    atr_pct = atr / current_price
    
    min_atr_pct = self.config['volatility_filter'].get('min_atr_pct', 0.005)
    
    return atr_pct >= min_atr_pct
```

**Time-of-Day Filter:**

```python
def _check_time_filter(self, timestamp: datetime) -> bool:
    """Skip first/last minutes of trading session."""
    if not self.config.get('time_filter', {}).get('enabled', False):
        return True
    
    # Convert to Eastern Time for market hours
    et = timestamp.astimezone(zoneinfo.ZoneInfo("America/New_York"))
    time_str = et.strftime("%H:%M")
    
    market_open = "09:30"
    market_close = "16:00"
    
    skip_first = self.config['time_filter'].get('skip_first_minutes', 15)
    skip_last = self.config['time_filter'].get('skip_last_minutes', 15)
    
    # Calculate skip windows
    open_time = datetime.strptime(market_open, "%H:%M").time()
    close_time = datetime.strptime(market_close, "%H:%M").time()
    
    skip_after_open = (datetime.combine(datetime.today(), open_time) + 
                       timedelta(minutes=skip_first)).time()
    skip_before_close = (datetime.combine(datetime.today(), close_time) - 
                         timedelta(minutes=skip_last)).time()
    
    # Allow signals only during core hours
    if open_time <= et.time() <= skip_after_open:
        return False  # Too close to open
    if skip_before_close <= et.time() <= close_time:
        return False  # Too close to close
    
    return True
```

### 4.5 VWAP Risk Management

**Purpose:** Use VWAP (Volume-Weighted Average Price) as dynamic support/resistance for risk management and entry/exit decisions.

**Architecture:**
```
Signal Generated → VWAP Entry Check → Position Entry → VWAP Stop Management
```

**Implementation:**

```python
class VWAPRiskManager:
    """VWAP-based risk management for intraday positions."""
    
    def __init__(self, config: dict):
        self.config = config.get('vwap_risk', {})
        self.vwap_data: dict[str, dict] = {}  # symbol -> vwap data
        
    def calculate_vwap(self, df: pd.DataFrame, session_start: Optional[datetime] = None) -> dict:
        """Calculate session VWAP and standard deviation bands.
        
        Args:
            df: 1-minute bars for current session
            session_start: When session started (default: 9:30 AM ET)
            
        Returns:
            Dictionary with vwap, bands, and metadata
        """
        if session_start is None:
            # Default to 9:30 AM ET for US equities
            import pytz
            et = pytz.timezone('US/Eastern')
            now = datetime.now(et)
            session_start = now.replace(hour=9, minute=30, second=0, microsecond=0)
        
        # Filter to current session only
        session_df = df[df.index >= session_start].copy()
        
        if len(session_df) < 5:  # Need some bars
            return None
        
        # Calculate VWAP: Sum(price * volume) / Sum(volume)
        typical_price = (session_df['high'] + session_df['low'] + session_df['close']) / 3
        tp_vol = typical_price * session_df['volume']
        
        cum_tp_vol = tp_vol.cumsum()
        cum_vol = session_df['volume'].cumsum()
        
        vwap = cum_tp_vol / cum_vol
        
        # Calculate standard deviation bands
        squared_dev = ((typical_price - vwap) ** 2) * session_df['volume']
        variance = squared_dev.cumsum() / cum_vol
        std = np.sqrt(variance)
        
        # Get current values
        current_vwap = vwap.iloc[-1]
        current_std = std.iloc[-1]
        current_price = session_df['close'].iloc[-1]
        
        std_multiplier = self.config.get('std_multiplier', 1.0)
        
        return {
            'vwap': current_vwap,
            'upper_1std': current_vwap + current_std * std_multiplier,
            'lower_1std': current_vwap - current_std * std_multiplier,
            'upper_2std': current_vwap + current_std * 2,
            'lower_2std': current_vwap - current_std * 2,
            'price': current_price,
            'distance_pct': abs(current_price - current_vwap) / current_vwap,
            'position_relative': (current_price - current_vwap) / current_std if current_std > 0 else 0
        }
    
    def check_entry_zone(self, symbol: str, signal_type: str, vwap_data: dict) -> tuple[bool, dict]:
        """Check if price is in favorable entry zone relative to VWAP.
        
        Returns:
            (pass: bool, metadata: dict)
        """
        if not self.config.get('enabled', False):
            return True, {'filter': 'vwap_entry', 'skipped': False}
        
        if vwap_data is None:
            return True, {'filter': 'vwap_entry', 'skipped': False, 'reason': 'no_data'}
        
        entry_zone_pct = self.config.get('entry_zone_pct', 0.002)  # 0.2%
        price = vwap_data['price']
        vwap = vwap_data['vwap']
        distance_pct = abs(price - vwap) / vwap
        
        # For longs: prefer price near or slightly below VWAP
        # For shorts: prefer price near or slightly above VWAP
        if signal_type == 'BUY':
            # Ideal: price within entry_zone of VWAP or below
            passed = distance_pct <= entry_zone_pct or price < vwap
            reason = 'too_far_above_vwap' if not passed else None
        else:  # SELL
            # Ideal: price within entry_zone of VWAP or above
            passed = distance_pct <= entry_zone_pct or price > vwap
            reason = 'too_far_below_vwap' if not passed else None
        
        return passed, {
            'filter': 'vwap_entry',
            'skipped': not passed,
            'vwap': vwap,
            'price': price,
            'distance_pct': distance_pct,
            'signal': signal_type,
            'reason': reason
        }
    
    def calculate_stop_price(self, signal_type: str, vwap_data: dict, 
                            atr: Optional[float] = None) -> float:
        """Calculate stop price based on VWAP bands.
        
        Args:
            signal_type: 'BUY' or 'SELL'
            vwap_data: VWAP calculation results
            atr: Optional ATR for minimum stop distance
            
        Returns:
            Stop price
        """
        if not self.config.get('enabled', False) or vwap_data is None:
            # Fallback to ATR-based stop
            return None
        
        stop_buffer_pct = self.config.get('stop_buffer_pct', 0.005)  # 0.5%
        vwap = vwap_data['vwap']
        use_bands = self.config.get('use_bands', True)
        
        if signal_type == 'BUY':
            if use_bands:
                # Stop below lower 1std band
                stop = vwap_data['lower_1std'] * (1 - stop_buffer_pct)
            else:
                # Stop below VWAP
                stop = vwap * (1 - stop_buffer_pct)
        else:  # SELL
            if use_bands:
                # Stop above upper 1std band
                stop = vwap_data['upper_1std'] * (1 + stop_buffer_pct)
            else:
                # Stop above VWAP
                stop = vwap * (1 + stop_buffer_pct)
        
        # Ensure minimum stop distance if ATR provided
        if atr:
            current_price = vwap_data['price']
            min_stop_distance = atr * 2  # 2x ATR minimum
            
            if signal_type == 'BUY':
                min_stop = current_price - min_stop_distance
                stop = min(stop, min_stop)
            else:
                min_stop = current_price + min_stop_distance
                stop = max(stop, min_stop)
        
        return stop
```

**Integration in SMACrossover:**

```python
async def on_bar(self, symbol: str, df: pd.DataFrame) -> list[SignalEvent]:
    # ... existing code ...
    
    # Calculate VWAP for risk management
    vwap_data = self.vwap_manager.calculate_vwap(df) if self.config.get('vwap_risk', {}).get('enabled') else None
    
    for fast_period, slow_period in self.periods:
        signal = self._check_crossover(symbol, df, fast_period, slow_period, atr)
        
        if signal:
            # Apply existing filters...
            
            # VWAP entry zone check
            pass_vwap, vwap_meta = self.vwap_manager.check_entry_zone(
                symbol, signal.signal_type, vwap_data
            )
            
            if not pass_vwap:
                logger.info(
                    "Filtered %s signal for %s: outside VWAP entry zone",
                    signal.signal_type, symbol
                )
                continue
            
            # Calculate VWAP-based stop
            stop_price = self.vwap_manager.calculate_stop_price(
                signal.signal_type, vwap_data, atr
            )
            
            if stop_price:
                signal.metadata['stop_price'] = stop_price
                signal.metadata['stop_type'] = 'vwap_band'
            
            signal.metadata['vwap'] = vwap_data['vwap'] if vwap_data else None
            signals.append(signal)
    
    return signals
```

**Configuration:**

```yaml
# VWAP Risk Management
vwap_risk:
  enabled: false              # OFF by default - enable after testing
  use_bands: true             # Use 1std deviation bands
  std_multiplier: 1.0         # 1σ band for entry/stop calculations
  entry_zone_pct: 0.002       # Within 0.2% of VWAP for entry
  stop_buffer_pct: 0.005      # 0.5% beyond band for stop placement
```

### 4.6 BarsHandler Daily Bar Support

**Add Daily Bar Fetching:**

```python
class BarsHandler:
    def __init__(
        self,
        state_store: StateStore,
        event_bus: EventBus,
        market_data_client: MarketDataClient,
        history_size: int = 200,
        enable_daily_bars: bool = True,  # New parameter
    ) -> None:
        # ... existing init ...
        self.enable_daily_bars = enable_daily_bars
        self.daily_deque: dict[str, deque] = {}
        
    async def initialize_daily_data(self, symbols: list[str]) -> None:
        """Pre-fetch daily bars for trend filtering."""
        if not self.enable_daily_bars:
            return
            
        for symbol in symbols:
            try:
                df = self.market_data_client.get_bars(
                    symbol=symbol,
                    timeframe='1Day',
                    limit=60
                )
                if not df.empty:
                    self.daily_deque[symbol] = deque(df.to_dict('records'), maxlen=60)
                    logger.info(f"Loaded {len(df)} daily bars for {symbol}")
            except Exception as e:
                logger.warning(f"Failed to load daily bars for {symbol}: {e}")
    
    def get_daily_dataframe(self, symbol: str) -> Optional[pd.DataFrame]:
        """Get daily bars for trend analysis."""
        if symbol not in self.daily_deque:
            return None
        
        records = list(self.daily_deque[symbol])
        return pd.DataFrame(records)
```

### 4.7 Configuration Schema

**Full Configuration Example** (`config/trading.yaml`):

```yaml
# =============================================================================
# STRATEGY (Enhanced with Trend Filtering)
# =============================================================================
strategy:
  name: sma_crossover
  params:
    # SMA Periods for crossover detection
    periods:
      - [5, 15]    # Fast scalp
      - [10, 30]   # Medium baseline  
      - [20, 50]   # Slow trend
    
    # Lookback configuration
    lookback_bars: 200              # 3+ hours of 1-min data
    
    # Daily trend filter (primary - Tier 1)
    daily_trend_filter:
      enabled: true
      sma_period: 20                # 20-day SMA for trend direction
      require_alignment: true       # Only trade with daily trend
    
    # 5-Minute structure filter (Tier 2)
    five_minute_filter:
      enabled: true
      ema_period: 20                # 5-min EMA period for structure
      rsi_enabled: true             # Enable RSI confirmation
      rsi_low: 30                   # Lower RSI bound
      rsi_high: 70                  # Upper RSI bound
      volume_enabled: true          # Require above-average 5-min volume
      
    # Volume confirmation filter
    volume_filter:
      enabled: true
      lookback_bars: 20             # Volume moving average period
      min_ratio: 1.2                # Current volume must be 1.2x average
      
    # Volatility filter
    volatility_filter:
      enabled: true
      atr_period: 14
      min_atr_pct: 0.005            # Minimum 0.5% ATR
      
    # Time-of-day filter
    time_filter:
      enabled: false                # OFF by default
      skip_first_minutes: 15        # Skip first 15 min after open
      skip_last_minutes: 15         # Skip last 15 min before close
    
    # VWAP Risk Management (Tier 3 - OFF by default)
    vwap_risk:
      enabled: false                # OFF by default - enable after testing
      use_bands: true               # Use 1std deviation bands
      std_multiplier: 1.0           # 1σ band for entry/stop
      entry_zone_pct: 0.002         # Within 0.2% of VWAP for entry
      stop_buffer_pct: 0.005        # 0.5% beyond band for stop
      
    # Signal confidence thresholds
    min_confidence: 0.5             # Only emit signals with confidence >= 0.5

# =============================================================================
# DATA HANDLER (Enhanced)
# =============================================================================
data:
  history_size: 200                 # Bars to keep in memory per symbol
  enable_daily_bars: true           # Fetch daily bars for trend filtering
  daily_bar_refresh_minutes: 60     # Refresh daily bars every hour
```

---

## 5. Configuration Options

### 5.1 Strategy Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `lookback_bars` | int | 200 | Number of 1-min bars to keep for analysis |
| **Tier 1: Essential Filters** ||||
| `daily_trend_filter.enabled` | bool | true | Enable daily trend filtering |
| `daily_trend_filter.sma_period` | int | 20 | SMA period for daily trend (20 or 50) |
| `daily_trend_filter.require_alignment` | bool | true | Only trade with trend direction |
| **Tier 2: Quality Filters** ||||
| `five_minute_filter.enabled` | bool | true | Enable 5-min structure confirmation |
| `five_minute_filter.ema_period` | int | 20 | 5-min EMA period for structure |
| `five_minute_filter.rsi_enabled` | bool | true | Enable RSI on 5-min timeframe |
| `five_minute_filter.rsi_low` | int | 30 | Lower RSI bound |
| `five_minute_filter.rsi_high` | int | 70 | Upper RSI bound |
| `five_minute_filter.volume_enabled` | bool | true | Require 5-min volume confirmation |
| `volume_filter.enabled` | bool | true | Enable volume confirmation |
| `volume_filter.min_ratio` | float | 1.2 | Minimum volume ratio vs average |
| **Tier 3: Fine-tuning Filters** ||||
| `vwap_risk.enabled` | bool | false | Enable VWAP risk management |
| `vwap_risk.use_bands` | bool | true | Use standard deviation bands |
| `vwap_risk.std_multiplier` | float | 1.0 | Standard deviation multiplier |
| `vwap_risk.entry_zone_pct` | float | 0.002 | Max distance from VWAP for entry |
| `vwap_risk.stop_buffer_pct` | float | 0.005 | Stop distance beyond VWAP band |
| `volatility_filter.enabled` | bool | false | Enable volatility filter |
| `volatility_filter.min_atr_pct` | float | 0.005 | Minimum ATR as % of price |
| `time_filter.enabled` | bool | false | Enable time-of-day filtering |
| `time_filter.skip_first_minutes` | int | 15 | Minutes after open to skip |
| `time_filter.skip_last_minutes` | int | 15 | Minutes before close to skip |
| `min_confidence` | float | 0.5 | Minimum confidence score to emit signal |

### 5.2 Backward Compatibility

All trend filtering features can be disabled to restore previous behavior:

```yaml
strategy:
  name: sma_crossover
  params:
    lookback_bars: 100              # Original 100-bar lookback
    daily_trend_filter:
      enabled: false                # Disable trend filter
    five_minute_filter:
      enabled: false                # Disable 5-min structure filter
    vwap_risk:
      enabled: false                # Disable VWAP risk management
    volume_filter:
      enabled: false
    volatility_filter:
      enabled: false
    time_filter:
      enabled: false
    min_confidence: 0.0             # Accept all signals
```

### 5.3 Per-Strategy Overrides

When multi-strategy framework is implemented, filters can be configured per strategy:

```yaml
strategies:
  sma_crossover_slow:
    enabled: true
    params:
      periods: [[20, 50]]
      lookback_bars: 500
      daily_trend_filter:
        enabled: true
        sma_period: 50              # More conservative 50-day filter
        
  sma_crossover_fast:
    enabled: true
    params:
      periods: [[5, 15]]
      lookback_bars: 100
      daily_trend_filter:
        enabled: false              # Fast strategy ignores daily trend
```

### 5.4 Anti-Overfitting Design Principles

**Modular Architecture:**

Filters are organized into tiers based on impact and complexity:

```yaml
filters:
  # Tier 1: Essential (high impact, low complexity)
  daily_trend:
    enabled: true      # Core filter - always on
    
  # Tier 2: Quality (medium impact, medium complexity)
  five_minute_structure:
    enabled: true      # Structure confirmation
  volume:
    enabled: true      # Volume confirmation
    
  # Tier 3: Fine-tuning (incremental improvement)
  vwap_risk:
    enabled: false     # OFF by default - enable after testing
  volatility:
    enabled: false     # OFF by default
  time:
    enabled: false     # OFF by default
```

**Default Configuration (Conservative):**

| Filter | Default | Reasoning |
|--------|---------|-----------|
| Daily trend | ON | Core directional bias, proven impact |
| 5-min structure | ON | Quality confirmation without over-tuning |
| Volume | ON | Simple, robust confirmation |
| VWAP | OFF | Requires testing on specific instruments |
| Volatility | OFF | Can overfit to past volatility regimes |
| Time-of-day | OFF | Too specific to historical patterns |

**Overfitting Prevention Strategies:**

1. **Simple Defaults (Not Optimized)**
   - Use round numbers for parameters (20, 30, 50 - not 17, 23, 47)
   - Avoid values that "look good" on backtests
   - Document rationale for each default

2. **Independent Filters**
   - Each filter can be tested in isolation
   - No filter depends on another filter's output
   - Easy to A/B test: daily only vs daily + 5-min

3. **Clear Disable Switches**
   - Every filter has `enabled: true/false`
   - Can disable without code changes
   - Useful for debugging and A/B testing

4. **A/B Testing Framework**
   ```yaml
   ab_test:
     enabled: true
     control_group: 50%      # 50% trades use control config
     variant_config:
       vwap_risk:
         enabled: true       # Test VWAP in variant only
   ```

5. **Walk-Forward Validation Required**
   - Never optimize parameters on entire dataset
   - Use expanding window: train on 2023, test on 2024
   - Document out-of-sample performance

**Warning Signs of Overfitting:**

| Symptom | Action |
|---------|--------|
| Parameter values are "precise" (e.g., 13.7) | Round to simple numbers |
| Filter only works on specific symbol | Remove or generalize |
| Performance degrades on new data | Walk-forward test failed |
| Many filters needed for profitability | Strategy fundamentals weak |
| Best config is "all enabled" | Likely curve-fitted |

---

## 6. Testing Strategy

### 6.1 Unit Tests

**Trend Filter Tests:**
```python
class TestTrendFilter:
    def test_daily_trend_filter_allows_with_trend_signals(self):
        """BUY signals allowed when price > daily SMA."""
        
    def test_daily_trend_filter_blocks_counter_trend(self):
        """SELL signals blocked when price > daily SMA."""
        
    def test_volume_filter_blocks_low_volume(self):
        """Signals blocked when volume < threshold."""
        
    def test_volatility_filter_blocks_low_volatility(self):
        """Signals blocked when ATR < threshold."""
        
    def test_time_filter_skips_open_minutes(self):
        """Signals filtered during first N minutes."""
```

**Integration Tests:**
```python
class TestSMACrossoverWithTrendFilter:
    def test_strategy_emits_filtered_signals_only(self):
        """End-to-end test with all filters enabled."""
        
    def test_backward_compatibility_disabled_filters(self):
        """All filters disabled = original behavior."""
```

### 6.2 Backtest Validation

**Test Scenarios:**

1. **Baseline (No Filters)**: 
   - Run existing strategy with 100-bar lookback
   - Document trade count, win rate, P&L

2. **Extended Lookback Only**:
   - 200-bar lookback, no other filters
   - Measure impact on signal timing

3. **Daily Trend Filter Only**:
   - Daily SMA filter, 100-bar lookback
   - Measure reduction in counter-trend trades

4. **Full Filter Stack**:
   - All filters enabled with 200-bar lookback
   - Target: 50-70% trade reduction

### 6.3 Success Metrics

| Metric | Baseline | Target | Measurement |
|--------|----------|--------|-------------|
| Trades per day | ~37 | < 15 | Count from backtest |
| Win rate | Current | +15% | Winning trades / Total |
| Profit factor | Current | > 1.5 | Gross profit / Gross loss |
| Sharpe ratio | Negative | > 1.0 | Risk-adjusted return |
| Counter-trend trades | Unknown | 0 | Manual inspection |
| Avg trade duration | Current | +20% | From filled signals |

---

## 7. Success Metrics

### 7.1 Primary KPIs

1. **Trade Count Reduction**: 50-70% fewer trades
   - Current: 75 trades / 2 days = 37.5/day
   - Target: 10-15 trades/day

2. **Win Rate Improvement**: +15 percentage points
   - Track before/after with same market conditions

3. **Profit Factor**: > 1.5
   - Gross profits / Gross losses

4. **Sharpe Ratio**: > 1.0
   - Risk-adjusted returns

### 7.2 Secondary KPIs

1. **Signal Quality Score**: 
   - Combine confidence + filter pass rate
   - Target: Average confidence > 0.7

2. **Counter-Trend Trade Elimination**:
   - 0 trades against daily SMA direction

3. **Stop Loss Hit Reduction**:
   - 50% fewer stop loss hits

4. **Average Trade Duration**:
   - +20% longer (better quality holds)

### 7.3 Monitoring Dashboard

```python
# Metrics to log per signal
{
    "signal_id": "uuid",
    "timestamp": "2025-01-15T10:30:00Z",
    "symbol": "TSLA",
    "signal_type": "BUY",
    "filters_passed": {
        "daily_trend": true,
        "volume": true,
        "volatility": true,
        "time_of_day": true
    },
    "confidence": 0.85,
    "regime": "trending",
    "daily_sma": 250.50,
    "daily_close": 255.00,
    "volume_ratio": 1.45,
    "atr_pct": 0.012
}
```

---

## 8. Risks & Mitigations

### 8.1 Identified Risks

| Risk | Impact | Likelihood | Mitigation |
|------|--------|------------|------------|
| **Over-filtering** | Miss good trades | Medium | Configurable thresholds; start permissive |
| **Daily lag** | Slow to catch trend changes | Medium | Use 20-day SMA (responsive) vs 50-day |
| **Data fetch failures** | Missing daily bars | Low | Graceful fallback (allow signals if no daily data) |
| **Increased latency** | Slower signal generation | Low | Cache daily bars; refresh hourly not per-bar |
| **Whipsaw in chop** | False trend signals | Medium | Combine with volatility filter |
| **Overfitting** | Params tuned to past data | Medium | Walk-forward testing; conservative defaults |

### 8.2 Mitigation Strategies

**Over-filtering Prevention:**
- Start with permissive thresholds
- A/B test: run filtered and unfiltered side-by-side
- Gradually tighten filters based on results

**Daily Lag Mitigation:**
- Default to 20-day SMA (more responsive than 50)
- Consider EMA instead of SMA for faster response
- Optional: Use 2-day or weekly timeframe for intermediate filter

**Data Fetch Resilience:**
```python
async def check_daily_trend(self, symbol: str, signal_type: str) -> tuple[bool, dict]:
    try:
        df = await self._get_daily_bars(symbol)
        if df is None or len(df) < 20:
            # Graceful fallback: allow signal if no data
            logger.warning(f"No daily data for {symbol}, allowing signal")
            return True, {'skipped': False, 'reason': 'no_data_fallback'}
        # ... filter logic ...
    except Exception as e:
        logger.error(f"Daily filter error for {symbol}: {e}")
        return True, {'skipped': False, 'reason': 'error_fallback'}
```

**Latency Management:**
- Pre-fetch daily bars at startup
- Hourly refresh via background task
- Never block signal path for daily data fetch

### 8.3 Rollback Plan

If trend filtering causes unexpected issues:

1. **Immediate**: Disable via config (`daily_trend_filter.enabled: false`)
2. **Short-term**: Revert to 100-bar lookback
3. **Long-term**: Full code revert to pre-filter commit

---

## 9. Implementation Phases

### Phase 1: Foundation (Day 1-2)
- [ ] Update `BarsHandler` with configurable `history_size`
- [ ] Update `SMACrossover.get_required_history()` to use config
- [ ] Add daily bar fetching to `BarsHandler`
- [ ] Update `trading.yaml` with new config schema

### Phase 2: Trend Filters (Day 3-5)
- [ ] Implement `TrendFilter` class
- [ ] Add `check_daily_trend()` method
- [ ] Add 5-minute bar fetching to `BarsHandler`
- [ ] Add `check_five_minute_structure()` method
- [ ] Integrate filters into `SMACrossover.on_bar()`
- [ ] Add filter metadata to signal logging

### Phase 3: Quality & Risk Filters (Day 6)
- [ ] Implement volume confirmation filter
- [ ] Implement volatility filter (disabled by default)
- [ ] Implement time-of-day filter (disabled by default)
- [ ] Implement `VWAPRiskManager` class (disabled by default)
- [ ] Add filter metrics to signal metadata

### Phase 4: Testing & Validation (Day 7-8)
- [ ] Unit tests for all filter components
- [ ] Backtest: baseline vs daily-only vs full stack
- [ ] A/B test: 5-min filter impact on signal quality
- [ ] Document conservative default configuration

### Phase 5: Deployment (Day 9-10)
- [ ] Deploy to paper trading with conservative defaults
- [ ] Monitor for 3-5 days
- [ ] Compare metrics to baseline
- [ ] Gradually enable Tier 3 filters (VWAP) if warranted
- [ ] Enable for live trading if targets met

---

## 10. Appendix

### A. References

- Current strategy: `src/strategy/sma_crossover.py`
- Bar handling: `src/data/bars.py`
- Configuration: `config/trading.yaml`
- Multi-strategy patterns: `docs/enhancement-prompts/06-multi-strategy-framework.md`

### B. Related Issues

- Excessive churn: 75 trades in 2 days
- P&L: -$1,553 (-1.56%)
- Duplicate signals: TSLA bought twice in 3 hours

### C. Configuration Migration Guide

To migrate existing configs:

```yaml
# OLD
timeframe: 1Min
lookback: 100

# NEW - Conservative Defaults (Recommended)
timeframe: 1Min
lookback_bars: 200

# Tier 1: Essential
daily_trend_filter:
  enabled: true
  sma_period: 20

# Tier 2: Quality
five_minute_filter:
  enabled: true
  ema_period: 20
  rsi_enabled: true
  rsi_low: 30
  rsi_high: 70
  volume_enabled: true

volume_filter:
  enabled: true
  min_ratio: 1.2

# Tier 3: Fine-tuning (OFF by default)
vwap_risk:
  enabled: false              # Enable after testing
  use_bands: true
  std_multiplier: 1.0
  entry_zone_pct: 0.002
  stop_buffer_pct: 0.005

volatility_filter:
  enabled: false              # Enable after testing
  min_atr_pct: 0.005

time_filter:
  enabled: false              # Enable if needed
  skip_first_minutes: 15
  skip_last_minutes: 15
```

---

## 8. Data Model Requirements

This section defines the dataclasses and data structures required for the trend filtering system.

### 8.1 TrendFilterConfig Dataclass

Configuration container for all trend filtering parameters.

```python
@dataclass
class TrendFilterConfig:
    """Configuration for all trend filters (daily SMA, RSI bounds, volume ratio, time filters)."""
    
    enabled: bool = True
    
    # Daily trend filter
    daily_sma_period: int = 20
    require_daily_alignment: bool = True
    
    # 5-minute structure filter
    check_5min_structure: bool = True
    ema_period: int = 20
    rsi_enabled: bool = True
    rsi_low: float = 30.0
    rsi_high: float = 70.0
    
    # Volume filter
    volume_enabled: bool = True
    min_volume_ratio: float = 1.2
    
    # Time filter
    time_enabled: bool = True
    skip_first_minutes: int = 15
    skip_last_minutes: int = 15
```

### 8.2 TrendFilterResult Dataclass

Output of the filter check operation, containing pass/fail status and metadata.

```python
@dataclass
class TrendFilterResult:
    """Output of filter check (passed/failed, reason, trend metadata)."""
    
    passed: bool
    reason: str
    filters_applied: List[str]
    daily_trend: Optional[DailyTrend] = None
    market_structure: Optional[MarketStructure] = None
    timestamp: datetime = field(default_factory=datetime.utcnow)
```

### 8.3 MarketStructure Dataclass

5-minute timeframe data for structure confirmation.

```python
@dataclass
class MarketStructure:
    """5-minute timeframe data (EMA20, RSI, volume confirmation)."""
    
    symbol: str
    ema_20: float
    rsi: float
    volume_ratio: float
    price_vs_ema: float  # percentage
    is_aligned: bool  # price and EMA aligned with daily trend
    timestamp: datetime
```

### 8.4 DailyTrend Dataclass

Daily trend state for directional bias.

```python
@dataclass
class DailyTrend:
    """Daily trend state (SMA20, price vs SMA, trend direction)."""
    
    symbol: str
    sma_20: float
    last_close: float
    trend_direction: str  # "up", "down", "sideways"
    price_vs_sma_pct: float
    timestamp: datetime
    
    def allows_buy(self) -> bool:
        """Check if buy signals are allowed based on daily trend."""
        return self.trend_direction == "up"
    
    def allows_sell(self) -> bool:
        """Check if sell signals are allowed based on daily trend."""
        return self.trend_direction == "down"
```

### 8.5 OrderIntent Integration

The trend filter results should be integrated with the existing order flow. The `OrderIntentEvent` (defined in `src/event_bus.py`) should be extended to carry filter results:

```python
@dataclass(frozen=True)
class OrderIntentEvent:
    """Order intent before submission - extended with filter metadata."""
    
    symbol: str
    side: str  # "buy", "sell"
    qty: float
    client_order_id: str
    timestamp: datetime
    # NEW: Trend filter results
    filter_result: Optional[TrendFilterResult] = None
    filter_passed: bool = True  # Pre-validation result
```

### 8.6 OrderState Enum Usage

The existing `OrderState` enum (from `src/models/order_state.py`) is used for state tracking throughout the order lifecycle:

```python
class OrderState(Enum):
    """Canonical order states for the trading system."""
    
    # Non-terminal states (order is still open)
    PENDING = "pending"
    SUBMITTED = "submitted"
    PARTIAL = "partial"
    
    # Terminal states (order is complete/cancelled)
    FILLED = "filled"
    CANCELLED = "cancelled"
    EXPIRED = "expired"
    REJECTED = "rejected"
```

Trend-filtered signals that fail validation should be logged with state metadata but never transition to `OrderState.PENDING`, preventing unnecessary order creation.

### 8.7 PositionTracker Integration

The `PositionTracker` (from `src/position_tracker.py`) provides position awareness for trend filtering:

```python
@dataclass
class PositionData:
    """Position data used for filter decisions."""
    
    symbol: str
    side: str  # "long" or "short"
    qty: float
    entry_price: float
    entry_time: datetime
    extreme_price: float
    atr: Optional[float] = None
    # ... additional fields

class PositionTracker:
    """Track positions and provide position awareness for filters."""
    
    def get_position(self, symbol: str) -> Optional[PositionData]:
        """Get current position for symbol (if any)."""
        pass
    
    def has_position(self, symbol: str) -> bool:
        """Check if we have an open position in the symbol."""
        pass
```

Trend filters should consider existing positions when evaluating signals (e.g., allowing counter-trend signals for position exits).

### 8.8 StateStore Persistence

The `StateStore` (from `src/state_store.py`) persists filter results for analytics:

```python
class StateStore:
    """SQLite state persistence - extended for trend filter results."""
    
    def save_filter_result(
        self,
        symbol: str,
        signal_type: str,
        filter_result: TrendFilterResult,
    ) -> None:
        """Persist filter result for backtesting analysis."""
        pass
    
    def get_filter_analytics(
        self,
        start_date: datetime,
        end_date: datetime,
    ) -> List[Dict[str, Any]]:
        """Retrieve filter analytics for reporting."""
        pass
```

---

**End of Specification**
