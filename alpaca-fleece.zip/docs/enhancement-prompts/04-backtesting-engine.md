# Backtesting Engine

## Overview
Implement a full backtesting framework that allows strategy validation on historical data before live deployment. Essential for testing parameter changes, new filters, and strategy variants without risking capital.

## Current State
- Trading config has `backtest` section with cost model (spread, slippage)
- `trading.yaml` defines strategy parameters
- No actual backtest runner or historical simulation capability
- Strategy changes go straight to paper trading

## Required Implementation

### 1. Backtest Engine Core (`src/backtest/engine.py`)

```python
from dataclasses import dataclass
from typing import List, Dict, Callable, Optional
from datetime import date, datetime
import pandas as pd

@dataclass
class BacktestConfig:
    """Configuration for a backtest run."""
    start_date: date
    end_date: date
    symbols: List[str]
    initial_capital: float
    
    # Cost model
    spread_pct: float = 0.0001  # 1 basis point
    slippage_pct: float = 0.00005  # 0.5 basis points
    commission_per_share: float = 0.0  # Alpaca is commission-free
    
    # Data settings
    timeframe: str = "1Min"  # Bar size
    use_adjusted_prices: bool = True  # Adjust for splits/dividends
    
    # Risk settings
    max_position_pct: float = 0.10
    max_daily_loss_pct: float = 0.05

@dataclass
class BacktestResult:
    """Results from a backtest run."""
    config: BacktestConfig
    
    # Equity curve
    equity_curve: pd.DataFrame  # timestamp, equity, cash, positions_value
    
    # Trades
    trades: List[SimulatedTrade]
    
    # Metrics
    total_return_pct: float
    annualized_return_pct: float
    sharpe_ratio: float
    max_drawdown_pct: float
    max_drawdown_duration_days: int
    win_rate: float
    profit_factor: float
    
    # Comparison
    benchmark_return_pct: float  # vs buy-and-hold SPY
    alpha: float
    beta: float
    
    # Stats
    total_trades: int
    avg_trades_per_day: float
    avg_holding_period_hours: float

class BacktestEngine:
    """Event-driven backtesting engine matching live trading behavior."""
    
    def __init__(self, config: BacktestConfig):
        self.config = config
        self.current_equity = config.initial_capital
        self.cash = config.initial_capital
        self.positions: Dict[str, Position] = {}
        self.trades: List[SimulatedTrade] = []
        self.equity_history: List[EquitySnapshot] = []
        
    async def load_historical_data(
        self, 
        symbol: str,
        data_source: DataSource = DataSource.ALPACA
    ) -> pd.DataFrame:
        """Load historical bar data for backtesting."""
        if data_source == DataSource.ALPACA:
            return await self._load_from_alpaca(symbol)
        elif data_source == DataSource.CSV:
            return await self._load_from_csv(symbol)
        elif data_source == DataSource.PARQUET:
            return await self._load_from_parquet(symbol)
    
    async def run(
        self,
        strategy: BaseStrategy,
        data: Dict[str, pd.DataFrame]
    ) -> BacktestResult:
        """Run backtest simulation."""
        
        # Create event loop matching live trading
        for timestamp in self._generate_timestamps(data):
            # 1. Update positions with current prices
            self._mark_to_market(timestamp, data)
            
            # 2. Check exits (stop loss, profit target)
            await self._process_exits(timestamp, data)
            
            # 3. Generate signals from strategy
            for symbol, df in data.items():
                # Get data up to current timestamp
                hist = df[df.index <= timestamp]
                if len(hist) < strategy.get_required_history():
                    continue
                
                signals = await strategy.on_bar(symbol, hist)
                
                # 4. Process signals
                for signal in signals:
                    if await self._check_risk(signal):
                        await self._execute_signal(timestamp, signal, data)
            
            # 5. Record equity snapshot
            self._record_equity(timestamp)
        
        return self._compile_results()
    
    async def _execute_signal(
        self, 
        timestamp: datetime,
        signal: SignalEvent,
        data: Dict[str, pd.DataFrame]
    ) -> None:
        """Simulate order execution with realistic fill modeling."""
        
        # Get current bar
        bar = data[signal.symbol].loc[timestamp]
        
        # Apply slippage (worse for market orders)
        if signal.side == OrderSide.BUY:
            fill_price = bar['close'] * (1 + self.config.slippage_pct + self.config.spread_pct/2)
        else:
            fill_price = bar['close'] * (1 - self.config.slippage_pct - self.config.spread_pct/2)
        
        # Calculate position size (same logic as live)
        qty = calculate_position_size(
            symbol=signal.symbol,
            side=signal.side.value,
            account_equity=self.current_equity,
            current_price=fill_price,
            max_position_pct=self.config.max_position_pct
        )
        
        # Apply commission
        commission = qty * self.config.commission_per_share
        
        # Update cash and positions
        trade_value = qty * fill_price
        if signal.side == OrderSide.BUY:
            self.cash -= trade_value + commission
            self._add_position(signal.symbol, qty, fill_price)
        else:
            self.cash += trade_value - commission
            self._reduce_position(signal.symbol, qty)
        
        # Record trade
        self.trades.append(SimulatedTrade(
            timestamp=timestamp,
            symbol=signal.symbol,
            side=signal.side,
            qty=qty,
            price=fill_price,
            commission=commission,
            signal_metadata=signal.metadata
        ))
```

### 2. Walk-Forward Optimization

```python
class WalkForwardOptimizer:
    """
    Walk-forward optimization to avoid overfitting.
    
    Process:
    1. Split data into N periods (e.g., monthly)
    2. For each period:
       a. Train on previous period (optimize parameters)
       b. Test on current period with those parameters
    3. Aggregate results across all test periods
    """
    
    def __init__(self, 
                 parameter_grid: Dict[str, List],
                 train_size: timedelta = timedelta(days=90),
                 test_size: timedelta = timedelta(days=30)):
        self.parameter_grid = parameter_grid
        self.train_size = train_size
        self.test_size = test_size
    
    async def optimize(
        self,
        strategy_class: Type[BaseStrategy],
        data: pd.DataFrame
    ) -> WalkForwardResult:
        
        results = []
        
        # Generate train/test windows
        windows = self._generate_windows(data.index.min(), data.index.max())
        
        for train_start, train_end, test_start, test_end in windows:
            train_data = data[train_start:train_end]
            test_data = data[test_start:test_end]
            
            # Grid search on training data
            best_params = await self._grid_search(
                strategy_class, 
                train_data, 
                self.parameter_grid
            )
            
            # Test on unseen data
            test_result = await self._run_backtest(
                strategy_class(best_params),
                test_data
            )
            
            results.append({
                'train_period': (train_start, train_end),
                'test_period': (test_start, test_end),
                'params': best_params,
                'test_return': test_result.total_return_pct,
                'test_sharpe': test_result.sharpe_ratio
            })
        
        return self._aggregate_results(results)
```

### 3. Strategy Comparison Framework

```python
class StrategyComparator:
    """Compare multiple strategies on same data."""
    
    async def compare(
        self,
        strategies: Dict[str, BaseStrategy],
        data: Dict[str, pd.DataFrame],
        config: BacktestConfig
    ) -> ComparisonReport:
        
        results = {}
        for name, strategy in strategies.items():
            engine = BacktestEngine(config)
            results[name] = await engine.run(strategy, data)
        
        return ComparisonReport(
            results=results,
            best_by_sharpe=max(results.items(), key=lambda x: x[1].sharpe_ratio),
            best_by_return=max(results.items(), key=lambda x: x[1].total_return_pct),
            best_by_drawdown=min(results.items(), key=lambda x: x[1].max_drawdown_pct)
        )

# Usage example:
comparison = await comparator.compare({
    "SMA_10_30": SMACrossover(fast=10, slow=30),
    "SMA_20_50": SMACrossover(fast=20, slow=50),
    "SMA_5_20": SMACrossover(fast=5, slow=20),
    "BuyAndHold": BuyAndHoldStrategy()
}, data, config)
```

### 4. Monte Carlo Simulation

```python
class MonteCarloSimulator:
    """
    Run Monte Carlo simulation on backtest results to estimate
    confidence intervals for metrics.
    """
    
    def simulate(
        self,
        backtest_result: BacktestResult,
        n_simulations: int = 1000,
        block_size: int = 10  # Bootstrap blocks to preserve serial correlation
    ) -> MonteCarloResult:
        
        simulated_returns = []
        
        for _ in range(n_simulations):
            # Bootstrap sample trades with replacement
            sample_trades = self._block_bootstrap(backtest_result.trades, block_size)
            
            # Recalculate equity curve
            equity = self._reconstruct_equity(sample_trades)
            
            # Calculate metrics
            simulated_returns.append({
                'total_return': self._calc_return(equity),
                'max_drawdown': self._calc_max_drawdown(equity),
                'sharpe': self._calc_sharpe(equity)
            })
        
        return MonteCarloResult(
            return_confidence_interval=np.percentile([r['total_return'] for r in simulated_returns], [5, 50, 95]),
            drawdown_confidence_interval=np.percentile([r['max_drawdown'] for r in simulated_returns], [5, 50, 95]),
            probability_of_profit=sum(1 for r in simulated_returns if r['total_return'] > 0) / n_simulations
        )
```

### 5. Data Management

```python
class HistoricalDataManager:
    """Manage and cache historical data for backtesting."""
    
    def __init__(self, cache_dir: str = "data/historical"):
        self.cache_dir = cache_dir
        self.alpaca_client = AlpacaHistoricalClient()
    
    async def get_data(
        self,
        symbol: str,
        start: datetime,
        end: datetime,
        timeframe: str = "1Min",
        force_refresh: bool = False
    ) -> pd.DataFrame:
        """Get historical data from cache or download."""
        
        cache_path = f"{self.cache_dir}/{symbol}_{timeframe}_{start.date()}_{end.date()}.parquet"
        
        if os.path.exists(cache_path) and not force_refresh:
            return pd.read_parquet(cache_path)
        
        # Download from Alpaca
        data = await self.alpaca_client.get_bars(
            symbol, start, end, timeframe
        )
        
        # Cache locally
        data.to_parquet(cache_path)
        
        return data
    
    def list_available_data(self) -> List[DataAvailability]:
        """Show what historical data is already cached."""
        ...
```

### 6. CLI Interface

```bash
# Run backtest for date range
python -m src.backtest.cli run \
    --start 2025-01-01 \
    --end 2025-12-31 \
    --strategy sma_crossover \
    --config config/backtest.yaml \
    --output results/backtest_2025.json

# Walk-forward optimization
python -m src.backtest.cli optimize \
    --strategy sma_crossover \
    --param-grid '{"fast_period": [5, 10, 20], "slow_period": [30, 50]}' \
    --start 2025-01-01 \
    --end 2025-12-31 \
    --output results/optimization.json

# Compare strategies
python -m src.backtest.cli compare \
    --strategies sma_crossover,mean_reversion,momentum \
    --start 2025-06-01 \
    --end 2025-12-31 \
    --plot results/comparison.png

# Monte Carlo simulation
python -m src.backtest.cli monte-carlo \
    --backtest-results results/backtest_2025.json \
    --simulations 10000 \
    --output results/mc_analysis.json
```

### 7. Visualization

```python
class BacktestVisualizer:
    """Generate plots and charts from backtest results."""
    
    def plot_equity_curve(self, result: BacktestResult, benchmark: pd.Series = None):
        """Plot equity curve with drawdowns highlighted."""
        ...
    
    def plot_monthly_returns(self, result: BacktestResult):
        """Heatmap of monthly returns."""
        ...
    
    def plot_trade_distribution(self, result: BacktestResult):
        """Histogram of trade P&Ls."""
        ...
    
    def plot_rolling_sharpe(self, result: BacktestResult, window: int = 30):
        """Rolling Sharpe ratio over time."""
        ...
```

### 8. Integration with Live Trading

```python
# Before deploying new strategy version:
async def validate_before_deploy(strategy: BaseStrategy) -> DeployDecision:
    # Run backtest on last 6 months
    data = await data_manager.get_data(
        symbols=config.symbols,
        start=datetime.now() - timedelta(days=180),
        end=datetime.now()
    )
    
    engine = BacktestEngine(BacktestConfig(
        initial_capital=100000,
        start_date=...,
        end_date=...
    ))
    
    result = await engine.run(strategy, data)
    
    # Validate metrics meet thresholds
    if result.sharpe_ratio < 1.0:
        return DeployDecision.REJECT, "Sharpe below 1.0"
    
    if result.max_drawdown_pct > 0.20:
        return DeployDecision.REJECT, "Max drawdown exceeds 20%"
    
    # Monte Carlo for confidence
    mc = MonteCarloSimulator()
    mc_result = mc.simulate(result)
    
    if mc_result.probability_of_profit < 0.70:
        return DeployDecision.REJECT, "Less than 70% probability of profit"
    
    return DeployDecision.APPROVE, "All checks passed"
```

## Acceptance Criteria

- [ ] Event-driven backtest engine matching live behavior
- [ ] Realistic cost model (spread, slippage, commission)
- [ ] Walk-forward optimization framework
- [ ] Monte Carlo simulation for confidence intervals
- [ ] Strategy comparison on same data
- [ ] Historical data caching from Alpaca
- [ ] CLI for running backtests and optimizations
- [ ] Visualization (equity curves, drawdowns, distributions)
- [ ] Pre-deployment validation integration
- [ ] Unit tests with known outcomes (verify correctness)

## Priority
MEDIUM-HIGH - Critical for strategy development, less urgent for initial live trading

## Estimated Effort
10-14 days (largest feature)
