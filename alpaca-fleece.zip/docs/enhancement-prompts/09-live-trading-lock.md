# Live Trading Lock with MFA Gate

## Overview
Implement a multi-factor authentication gate that prevents accidental live trading activation. Requires explicit user confirmation via secondary channel (WhatsApp/Signal) before live mode can be enabled. Includes safeguards to prevent catastrophic "fat finger" errors.

## Current State
- `ALLOW_LIVE_TRADING=false` flag in `.env`
- `ALPACA_PAPER=true` setting
- No verification beyond changing environment variables
- Live mode can be enabled by editing a text file

## Required Implementation

### 1. Live Trading Gatekeeper (`src/security/live_trading_gate.py`)

```python
from enum import Enum
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Optional
import hashlib
import secrets

class TradingMode(Enum):
    PAPER = "paper"
    LIVE = "live"

class LiveTradingStatus(Enum):
    DISABLED = "disabled"           # Paper trading only
    PENDING_APPROVAL = "pending"     # MFA request sent
    APPROVED = "approved"           # Live trading enabled
    LOCKED = "locked"               # Emergency lock (can only reset manually)

@dataclass
class MFAToken:
    token: str
    expires_at: datetime
    request_ip: str
    requested_by: str
    confirmation_code: str  # 6-digit code for user to confirm

class LiveTradingGatekeeper:
    """
    Controls access to live trading with multi-factor authentication.
    
    Security model:
    1. Two-person rule: Requires both config change + MFA confirmation
    2. Time-bounded: Approvals expire after 1 hour
    3. Audited: All state changes logged immutably
    4. Revocable: Can disable instantly via kill switch
    """
    
    MFA_EXPIRY_MINUTES = 60
    MAX_FAILED_ATTEMPTS = 3
    LOCKOUT_DURATION_MINUTES = 60
    
    def __init__(self, db: Database, notifier: NotificationService):
        self.db = db
        self.notifier = notifier
        self._current_mode = TradingMode.PAPER
        self._status = LiveTradingStatus.DISABLED
        self._pending_mfa: Optional[MFAToken] = None
        self._failed_attempts = 0
        self._lockout_until: Optional[datetime] = None
    
    async def request_live_trading_activation(
        self,
        requested_by: str,
        request_ip: str,
        justification: str
    ) -> MFARequestResult:
        """
        Request activation of live trading mode.
        
        Process:
        1. Verify not in lockout
        2. Generate MFA token
        3. Send confirmation code via secondary channel
        4. Log request
        5. Return pending status
        """
        
        # Check lockout
        if self._lockout_until and datetime.now() < self._lockout_until:
            remaining = (self._lockout_until - datetime.now()).seconds // 60
            raise LiveTradingError(
                f"Live trading locked out due to failed attempts. Try again in {remaining} minutes."
            )
        
        # Check if already pending
        if self._status == LiveTradingStatus.PENDING_APPROVAL:
            raise LiveTradingError("Live trading activation already pending. Check your WhatsApp/Signal.")
        
        # Check if already live
        if self._status == LiveTradingStatus.APPROVED:
            raise LiveTradingError("Live trading is already enabled.")
        
        # Generate MFA token
        mfa_token = MFAToken(
            token=secrets.token_urlsafe(32),
            expires_at=datetime.now() + timedelta(minutes=self.MFA_EXPIRY_MINUTES),
            request_ip=request_ip,
            requested_by=requested_by,
            confirmation_code=self._generate_confirmation_code()
        )
        
        self._pending_mfa = mfa_token
        self._status = LiveTradingStatus.PENDING_APPROVAL
        
        # Send MFA notification
        await self._send_mfa_notification(mfa_token, justification)
        
        # Log request
        await self._audit_log("LIVE_TRADING_REQUESTED", {
            "requested_by": requested_by,
            "request_ip": request_ip,
            "justification": justification,
            "mfa_token": mfa_token.token[:16] + "..."  # Partial for security
        })
        
        return MFARequestResult(
            status="pending",
            message=f"Live trading activation requested. Confirmation code sent via {self.notifier.channel}.",
            expires_at=mfa_token.expires_at
        )
    
    async def confirm_live_trading_activation(
        self,
        confirmation_code: str,
        confirmed_by: str,
        confirm_ip: str
    ) -> ActivationResult:
        """
        Confirm live trading activation with MFA code.
        
        Validates:
        - Code matches pending request
        - Request not expired
        - IP address matches (optional security layer)
        """
        
        # Validate state
        if self._status != LiveTradingStatus.PENDING_APPROVAL:
            raise LiveTradingError("No pending live trading activation request.")
        
        if not self._pending_mfa:
            raise LiveTradingError("No MFA token found. Please request activation again.")
        
        # Check expiry
        if datetime.now() > self._pending_mfa.expires_at:
            self._status = LiveTradingStatus.DISABLED
            self._pending_mfa = None
            raise LiveTradingError("MFA token expired. Please request activation again.")
        
        # Validate code
        if confirmation_code != self._pending_mfa.confirmation_code:
            self._failed_attempts += 1
            
            if self._failed_attempts >= self.MAX_FAILED_ATTEMPTS:
                self._lockout_until = datetime.now() + timedelta(minutes=self.LOCKOUT_DURATION_MINUTES)
                self._failed_attempts = 0
                await self._alert_security_team("Multiple failed live trading activation attempts")
            
            await self._audit_log("LIVE_TRADING_CONFIRMATION_FAILED", {
                "attempted_by": confirmed_by,
                "attempt_ip": confirm_ip,
                "failed_attempts": self._failed_attempts
            })
            
            raise LiveTradingError(
                f"Invalid confirmation code. {self.MAX_FAILED_ATTEMPTS - self._failed_attempts} attempts remaining."
            )
        
        # Success - activate live trading
        self._status = LiveTradingStatus.APPROVED
        self._current_mode = TradingMode.LIVE
        self._failed_attempts = 0
        self._pending_mfa = None
        
        # Enable in configuration
        await self._enable_live_trading_in_config()
        
        # Log activation
        await self._audit_log("LIVE_TRADING_ACTIVATED", {
            "activated_by": confirmed_by,
            "activation_ip": confirm_ip,
            "original_request_by": self._pending_mfa.requested_by,
            "original_request_ip": self._pending_mfa.request_ip
        })
        
        # Send confirmation
        await self.notifier.send_alert(
            "🚨 LIVE TRADING ACTIVATED",
            f"Live trading mode is now ACTIVE as of {datetime.now()}.\n"
            f"Activated by: {confirmed_by}\n"
            f"If this was not you, IMMEDIATELY run: python -m src.security kill-switch",
            priority="critical"
        )
        
        return ActivationResult(
            status="activated",
            message="Live trading is now enabled. All subsequent trades will use REAL MONEY.",
            activated_at=datetime.now()
        )
    
    async def disable_live_trading(
        self,
        disabled_by: str,
        reason: str,
        emergency: bool = False
    ) -> None:
        """Disable live trading and return to paper mode."""
        
        self._status = LiveTradingStatus.DISABLED
        self._current_mode = TradingMode.PAPER
        self._pending_mfa = None
        
        await self._disable_live_trading_in_config()
        
        await self._audit_log("LIVE_TRADING_DISABLED", {
            "disabled_by": disabled_by,
            "reason": reason,
            "emergency": emergency
        })
        
        priority = "critical" if emergency else "high"
        await self.notifier.send_alert(
            "✅ Live Trading Disabled",
            f"Live trading has been disabled. Reason: {reason}",
            priority=priority
        )
    
    async def _send_mfa_notification(self, mfa_token: MFAToken, justification: str) -> None:
        """Send MFA code via secondary channel."""
        
        message = f"""
🔐 LIVE TRADING ACTIVATION REQUEST

Someone has requested to activate LIVE TRADING mode.

Request Details:
- Requested by: {mfa_token.requested_by}
- From IP: {mfa_token.request_ip}
- Justification: {justification}
- Expires: {mfa_token.expires_at.strftime('%H:%M:%S')}

Confirmation Code: {mfa_token.confirmation_code}

⚠️ WARNING: Live trading uses REAL MONEY. All trades will have actual financial impact.

To approve, reply with: ENABLE {mfa_token.confirmation_code}
To reject, reply with: REJECT

This code will expire in 60 minutes.
        """
        
        await self.notifier.send_alert(
            "🔐 Live Trading Activation Request",
            message,
            priority="critical",
            require_acknowledgment=True
        )
    
    def _generate_confirmation_code(self) -> str:
        """Generate cryptographically secure 6-digit code."""
        return ''.join(secrets.choice('0123456789') for _ in range(6))
    
    async def _enable_live_trading_in_config(self) -> None:
        """Update configuration files to enable live trading."""
        # Update .env file
        await self._update_env_file("ALLOW_LIVE_TRADING", "true")
        await self._update_env_file("ALPACA_PAPER", "false")
        
        # Update runtime config
        os.environ["ALLOW_LIVE_TRADING"] = "true"
        os.environ["ALPACA_PAPER"] = "false"
    
    async def _disable_live_trading_in_config(self) -> None:
        """Update configuration to disable live trading."""
        await self._update_env_file("ALLOW_LIVE_TRADING", "false")
        await self._update_env_file("ALPACA_PAPER", "true")
        
        os.environ["ALLOW_LIVE_TRADING"] = "false"
        os.environ["ALPACA_PAPER"] = "true"
```

### 2. Trading Mode Enforcer (`src/security/mode_enforcer.py`)

```python
class TradingModeEnforcer:
    """
    Enforces trading mode at multiple levels.
    Prevents accidental live trades even if config is wrong.
    """
    
    def __init__(self, gatekeeper: LiveTradingGatekeeper):
        self.gatekeeper = gatekeeper
        self._live_trade_count = 0
        self._daily_live_trade_limit = 1  # Ultra-conservative for first day
    
    async def validate_order(self, order: OrderRequest) -> None:
        """
        Validate order before submission.
        Multiple safety checks to prevent accidental live trades.
        """
        
        # Check 1: Is live trading approved?
        if self.gatekeeper.current_mode != TradingMode.LIVE:
            # Safe - paper trading
            return
        
        # Check 2: Daily trade limit for first day of live trading
        if self._live_trade_count >= self._daily_live_trade_limit:
            if not await self._request_limit_increase():
                raise TradingModeError(
                    f"Daily live trade limit ({self._daily_live_trade_limit}) reached. "
                    "Contact admin to increase."
                )
        
        # Check 3: Notional value limit for first trades
        max_first_trade = 1000  # $1,000 max first live trade
        if order.notional and order.notional > max_first_trade:
            raise TradingModeError(
                f"First live trade limited to ${max_first_trade}. "
                f"Request to trade ${order.notional} denied."
            )
        
        # Check 4: Trading hours check (prevent after-hours accidents)
        if not is_market_hours():
            raise TradingModeError(
                "Live trading only allowed during market hours (9:30-16:00 ET)."
            )
        
        # Check 5: Duplicate order prevention
        if await self._is_duplicate_order(order):
            raise TradingModeError(
                "Duplicate order detected. Please wait 60 seconds between identical orders."
            )
        
        # All checks passed
        self._live_trade_count += 1
        
        # Log with warning
        logger.critical(
            f"LIVE TRADE EXECUTING: {order.symbol} {order.side} {order.qty}. "
            f"Trade #{self._live_trade_count} today."
        )
```

### 3. Configuration Safeguards

```yaml
# config/trading.yaml additions
live_trading_safeguards:
  # Require MFA for activation
  require_mfa: true
  mfa_channel: "whatsapp"  # or signal, email
  
  # Gradual ramp-up settings
  first_day_trade_limit: 1
  second_day_trade_limit: 3
  third_day_trade_limit: 10
  week_two_onward: unlimited
  
  # First trade limits
  first_trade_max_notional: 1000
  first_trade_max_shares: 10
  
  # Emergency contacts
  emergency_contacts:
    - name: "Primary Admin"
      phone: "+447789771068"
      notify_on_live_activation: true
      notify_on_kill_switch: true
  
  # Cooldown period after disabling
  reactivation_cooldown_hours: 24
  
  # Auto-disable after inactivity
  auto_disable_after_inactive_hours: 8
```

### 4. Audit and Alerting

```python
class LiveTradingAuditor:
    """Immutable audit log for all live trading events."""
    
    async def log_event(self, event_type: str, details: dict) -> None:
        """
        Log event to append-only audit log.
        Write to multiple locations for redundancy.
        """
        audit_record = {
            "timestamp": datetime.utcnow().isoformat(),
            "event_type": event_type,
            "details": details,
            "hash": self._calculate_hash(event_type, details)
        }
        
        # Write to local database
        await self.db.execute(
            "INSERT INTO live_trading_audit (data) VALUES (?)",
            (json.dumps(audit_record),)
        )
        
        # Write to file (append-only)
        with open("logs/live_trading_audit.log", "a") as f:
            f.write(json.dumps(audit_record) + "\n")
        
        # Send to remote audit service (if configured)
        if self.remote_audit_endpoint:
            await self._send_to_remote_audit(audit_record)
    
    def _calculate_hash(self, event_type: str, details: dict) -> str:
        """Calculate hash for tamper detection."""
        data = f"{event_type}{json.dumps(details, sort_keys=True)}"
        return hashlib.sha256(data.encode()).hexdigest()[:16]
```

### 5. CLI Commands

```bash
# Request live trading activation
python -m src.security request-live --justification "Strategy validated in paper for 30 days"

# Check activation status
python -m src.security live-status

# Confirm with MFA code
python -m src.security confirm-live --code 123456

# Disable live trading
python -m src.security disable-live --reason "Market volatility" --emergency

# View audit log
python -m src.security audit-log --limit 50

# Emergency kill switch (alias)
python -m src.security kill-switch
```

## Acceptance Criteria

- [ ] MFA required before live trading can be enabled
- [ ] Confirmation code sent via WhatsApp/Signal
- [ ] 60-minute expiry on MFA tokens
- [ ] Lockout after 3 failed attempts
- [ ] First-day trade limits (1 trade, $1,000 max)
- [ ] Gradual ramp-up over first week
- [ ] Immutable audit log of all live trading events
- [ ] Emergency disable command
- [ ] Auto-disable after market hours/inactivity
- [ ] Real-time alerts to emergency contacts

## Priority
CRITICAL - Prevents catastrophic accidental live trading

## Estimated Effort
3-4 days
