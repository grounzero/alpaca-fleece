# Partial Fill Handling Enhancement

## Overview
Implement robust handling of partial order fills to prevent position tracking drift and ensure the bot always knows its true position state. This is a risk-critical feature for live trading.

## Current State
- Order submission via `src/order_manager.py`
- Position tracking in `src/position_tracker.py`
- Database stores orders but unclear partial fill handling

## The Problem

When an order for 100 shares fills in parts:
1. 50 shares @ $100.00 (fill #1)
2. 30 shares @ $100.05 (fill #2)  
3. 20 shares @ $100.10 (fill #3)

The bot must:
- Track cumulative filled quantity (50 → 80 → 100)
- Calculate blended average price
- Know when order is completely filled
- Handle case where remaining 20 never fill (order expires/cancelled)

## Required Implementation

### 1. Enhanced Order State Machine (`src/order_manager.py`)

```python
class OrderState(Enum):
    PENDING = "pending"           # Submitted, no fills
    PARTIAL = "partial"           # Some fills, still open
    FILLED = "filled"             # Complete
    CANCELLED = "cancelled"       # Cancelled, may have partial fills
    EXPIRED = "expired"           # Expired, may have partial fills
    REJECTED = "rejected"         # Never filled

@dataclass
class OrderFill:
    fill_id: str
    timestamp: datetime
    quantity: int
    price: float
    
@dataclass  
class TrackedOrder:
    order_id: str
    symbol: str
    side: OrderSide
    requested_qty: int
    fills: List[OrderFill]
    state: OrderState
    
    @property
    def filled_qty(self) -> int:
        return sum(f.quantity for f in self.fills)
    
    @property
    def remaining_qty(self) -> int:
        return self.requested_qty - self.filled_qty
    
    @property
    def avg_fill_price(self) -> float:
        if not self.fills:
            return 0.0
        total_cost = sum(f.quantity * f.price for f in self.fills)
        return total_cost / self.filled_qty
```

### 2. Fill Event Processing

Update `OrderManager` to handle Alpaca fill webhooks/polling:

```python
async def on_fill_update(self, fill_event: FillEvent):
    """Process a fill notification from Alpaca."""
    order = self.get_order(fill_event.order_id)
    
    # Record the fill
    new_fill = OrderFill(
        fill_id=fill_event.fill_id,
        timestamp=fill_event.timestamp,
        quantity=fill_event.filled_qty,
        price=fill_event.price
    )
    order.fills.append(new_fill)
    
    # Update state
    if order.filled_qty >= order.requested_qty:
        order.state = OrderState.FILLED
        await self.on_order_complete(order)
    else:
        order.state = OrderState.PARTIAL
        
    # Persist to database
    await self.persist_fill(order, new_fill)
    
    # Update position tracker with ACTUAL filled quantity
    await self.position_tracker.update_position(
        symbol=order.symbol,
        filled_qty=fill_event.filled_qty,  # Not requested_qty!
        avg_price=fill_event.price,
        side=order.side
    )
```

### 3. Database Schema Updates

New tables in `trades.db`:

```sql
-- Order fills (one row per partial fill)
CREATE TABLE order_fills (
    fill_id TEXT PRIMARY KEY,
    order_id TEXT NOT NULL,
    symbol TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    price REAL NOT NULL,
    timestamp_utc TEXT NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id)
);

-- Enhanced orders table with state tracking
ALTER TABLE orders ADD COLUMN state TEXT DEFAULT 'pending';
ALTER TABLE orders ADD COLUMN filled_qty INTEGER DEFAULT 0;
ALTER TABLE orders ADD COLUMN avg_fill_price REAL;
ALTER TABLE orders ADD COLUMN remaining_qty INTEGER;
```

### 4. Partial Fill Strategies

Implement configurable behavior when partial fills occur:

**Strategy A: Wait for Complete Fill**
- Leave order open until 100% filled or cancelled
- Risk: Order may never complete

**Strategy B: Cancel Remainder After Timeout**
- If not 100% filled within N seconds, cancel remaining
- Update position with actual filled amount

**Strategy C: Immediate Retry**
- Cancel unfilled portion immediately
- Submit new order for remaining quantity
- Track as separate order (audit trail)

**Strategy D: Accept Partial (Recommended)**
- Treat partial fill as complete
- Cancel remaining immediately
- Log warning: "Only 80/100 shares filled"

Default: Strategy D for simplicity, configurable per strategy config.

### 5. Position Tracker Integration

`PositionTracker` must handle partial fills correctly:

```python
async def update_position_from_fill(self, fill: OrderFill, side: OrderSide):
    """Update position with actual filled quantity."""
    current = self.get_position(fill.symbol)
    
    if side == OrderSide.BUY:
        # Blend average price for existing + new
        total_qty = current.qty + fill.quantity
        total_cost = (current.qty * current.avg_price) + (fill.quantity * fill.price)
        current.avg_price = total_cost / total_qty
        current.qty = total_qty
    else:
        current.qty -= fill.quantity
        if current.qty == 0:
            current.avg_price = 0.0
            await self.close_position(fill.symbol)
```

### 6. Reconciliation Checks

Daily reconciliation in `src/reconciliation.py`:
- Compare bot's calculated positions vs Alpaca API positions
- Alert if drift > 0 shares (should be exact match)
- Auto-correct from Alpaca if mismatch detected

### 7. Error Scenarios to Handle

1. **Fill received for unknown order** → Log error, query Alpaca for order details
2. **Fill qty > remaining qty** → Reject, alert (should never happen)
3. **Duplicate fill_id received** → Idempotent (ignore duplicate)
4. **Fill after order cancelled** → Possible race condition, accept if valid
5. **Network error during fill processing** → Persist raw event, retry processing

### 8. Testing Requirements

Create comprehensive tests:

```python
async def test_partial_fill_handling():
    # Submit order for 100 shares
    order = await order_manager.submit_order("AAPL", 100, OrderSide.BUY)
    
    # Simulate 3 partial fills
    await order_manager.on_fill_update(create_fill(order.id, 50, 150.00))
    assert order.filled_qty == 50
    assert order.state == OrderState.PARTIAL
    
    await order_manager.on_fill_update(create_fill(order.id, 30, 150.05))
    assert order.filled_qty == 80
    
    await order_manager.on_fill_update(create_fill(order.id, 20, 150.10))
    assert order.filled_qty == 100
    assert order.state == OrderState.FILLED
    
    # Verify position tracker has correct qty and avg price
    position = position_tracker.get_position("AAPL")
    assert position.qty == 100
    assert position.avg_price == 150.03  # Blended average
```

## Acceptance Criteria

- [ ] All partial fills tracked with unique fill IDs
- [ ] Position tracker always matches Alpaca within 1 share
- [ ] Average price correctly calculated across multiple fills
- [ ] Order state transitions: pending → partial → filled
- [ ] Partial fill strategy configurable (wait/accept/cancel)
- [ ] Database persists all fill events
- [ ] Reconciliation catches any drift
- [ ] 100% unit test coverage for fill scenarios

## Priority
HIGH - Critical for live trading accuracy

## Estimated Effort
4-5 days
