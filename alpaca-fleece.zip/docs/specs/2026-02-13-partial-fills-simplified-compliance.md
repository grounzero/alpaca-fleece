# Simplified Partial Fill Compliance Specification

**Date:** 2026-02-13  
**Branch:** feat/partial-fills  
**Status:** Ready for Implementation  
**Estimate:** 2.5-3.5 days

---

## Executive Summary

This specification defines the **simplified compliance path** for partial fill handling. The current implementation has working fill tracking, but lacks:

1. **PositionTracker integration** - positions are created at order submission instead of on actual fills
2. **OrderState enum** - string-based status comparisons throughout the codebase

This spec addresses these gaps without the overhead of full strategy configurability (which can be deferred until needed).

---

## Section 1: Implementation Specification

### 1.1 PositionTracker Fill Event Wiring

**Current State:**
- `PositionTracker.start_tracking()` creates positions immediately when orders are submitted
- Position qty is set to the requested order qty, not actual filled qty
- PositionTracker does not consume `OrderUpdateEvent` with fill deltas
- Risk of position drift if fills differ from order quantity

**Required Changes:**

#### 1.1.1 New Method: `update_position_from_fill()`

Add to `src/position_tracker.py`:

```python
async def update_position_from_fill(
    self,
    symbol: str,
    delta_qty: float,
    fill_price: float,
    side: str,  # "buy" or "sell"
    timestamp: Optional[datetime] = None,
) -> Optional[PositionData]:
    """Update position based on a fill event.
    
    - Creates new position on first fill (not at order submission)
    - Updates existing position qty and blended avg price on subsequent fills
    - Closes position when qty reaches zero (full exit)
    
    Args:
        symbol: Trading symbol
        delta_qty: Incremental fill quantity (always positive)
        fill_price: Fill price for this incremental quantity
        side: "buy" (increases position) or "sell" (decreases position)
        timestamp: Optional timestamp for the fill
        
    Returns:
        Updated PositionData or None if position closed
    """
```

**Implementation Details:**

1. **First Fill Detection:**
   - Check if position exists for symbol
   - If no position exists and side is "buy": create new position with `start_tracking()`
   - If no position exists and side is "sell": log warning (attempting to sell non-existent position)

2. **Average Price Blending:**
   ```python
   current_qty = position.qty
   current_avg = position.entry_price
   
   if side == "buy":
       # Increase position - blend average price
       new_qty = current_qty + delta_qty
       total_cost = (current_qty * current_avg) + (delta_qty * fill_price)
       new_avg = total_cost / new_qty
   else:  # sell
       # Decrease position - avg price unchanged
       new_qty = current_qty - delta_qty
       new_avg = current_avg
   ```

3. **Position Closure:**
   - If `new_qty <= 0`: call `stop_tracking(symbol)` and return None
   - Otherwise: update position qty/price and persist

#### 1.1.2 Wire PositionTracker to OrderUpdatesHandler

Modify `src/data/order_updates.py`:

```python
class OrderUpdatesHandler:
    def __init__(
        self,
        state_store: StateStore,
        event_bus: EventBus,
        position_tracker: Optional[PositionTracker] = None,  # NEW PARAMETER
    ) -> None:
        self.state_store = state_store
        self.event_bus = event_bus
        self.position_tracker = position_tracker  # NEW
        
    async def on_order_update(self, raw_update: Any) -> None:
        # ... existing processing ...
        
        # After processing fill delta, update position if tracker available
        if (
            self.position_tracker is not None
            and event.delta_qty is not None
            and event.delta_qty > 0
        ):
            await self.position_tracker.update_position_from_fill(
                symbol=event.symbol,
                delta_qty=event.delta_qty,
                fill_price=event.cum_avg_fill_price or 0.0,
                side=event.side,
                timestamp=event.timestamp,
            )
```

#### 1.1.3 Update Orchestrator Wiring

Modify orchestrator to inject PositionTracker into OrderUpdatesHandler:

```python
# In orchestrator initialization
self.order_handler = OrderUpdatesHandler(
    state_store=self.state_store,
    event_bus=self.event_bus,
    position_tracker=self.position_tracker,  # ADD THIS
)
```

#### 1.1.4 Order Submission Changes

**Current behavior:** `OrderManager` calls `position_tracker.start_tracking()` immediately on order submission.

**New behavior:** 
- Remove immediate position creation on order submission
- Positions are created only when first fill arrives via `update_position_from_fill()`
- For exit orders (sell side), the existing position will be reduced/closed by the fill handler

### 1.2 OrderState Enum

**Current State:**
- Status values are strings: "new", "submitted", "accepted", "partially_filled", "filled", "canceled", "expired", "rejected"
- Comparisons scattered throughout: `if event.status == "filled":`
- Prone to typos, no IDE autocomplete

**Required Changes:**

#### 1.2.1 Create OrderState Enum

Create new file `src/models/order_state.py`:

```python
from enum import Enum, auto


class OrderState(Enum):
    """Canonical order states for the trading system.
    
    Maps Alpaca API statuses to internal enum values.
    """
    # Non-terminal states (order is still open)
    PENDING = "pending"                    # Alpaca: new, pending_new
    SUBMITTED = "submitted"                # Alpaca: submitted, accepted
    PARTIAL = "partial"                    # Alpaca: partially_filled
    
    # Terminal states (order is complete/cancelled)
    FILLED = "filled"                      # Alpaca: filled
    CANCELLED = "cancelled"                # Alpaca: canceled, pending_cancel
    EXPIRED = "expired"                    # Alpaca: expired
    REJECTED = "rejected"                  # Alpaca: rejected
    
    @classmethod
    def from_alpaca(cls, alpaca_status: str) -> "OrderState":
        """Convert Alpaca API status string to OrderState."""
        mapping = {
            "new": cls.PENDING,
            "pending_new": cls.PENDING,
            "submitted": cls.SUBMITTED,
            "accepted": cls.SUBMITTED,
            "partially_filled": cls.PARTIAL,
            "filled": cls.FILLED,
            "canceled": cls.CANCELLED,
            "pending_cancel": cls.CANCELLED,
            "expired": cls.EXPIRED,
            "rejected": cls.REJECTED,
        }
        return mapping.get(alpaca_status.lower(), cls.PENDING)
    
    @property
    def is_terminal(self) -> bool:
        """Return True if order is in a terminal state."""
        return self in {
            OrderState.FILLED,
            OrderState.CANCELLED,
            OrderState.EXPIRED,
            OrderState.REJECTED,
        }
    
    @property
    def has_fill_potential(self) -> bool:
        """Return True if order may still receive fills."""
        return self in {
            OrderState.PENDING,
            OrderState.SUBMITTED,
            OrderState.PARTIAL,
        }
```

#### 1.2.2 Update OrderUpdateEvent

Modify `src/event_bus.py`:

```python
from src.models.order_state import OrderState

@dataclass(frozen=True)
class OrderUpdateEvent:
    # ... existing fields ...
    status: str  # Keep for backward compatibility
    state: OrderState  # ADD THIS - canonical enum
    
    # ... rest of fields ...
```

**Backward Compatibility:** Keep `status` as string for existing code, add `state` as the canonical enum.

#### 1.2.3 Update OrderUpdatesHandler

Modify `src/data/order_updates.py`:

```python
def _to_canonical_order_update(self, raw_update: Any) -> OrderUpdateEvent:
    # ... existing extraction code ...
    
    status_value = self._extract_enum_value(status_attr)
    order_state = OrderState.from_alpaca(status_value)  # ADD THIS
    
    return OrderUpdateEvent(
        # ... existing fields ...
        status=status_value,
        state=order_state,  # ADD THIS
        # ...
    )
```

#### 1.2.4 Replace String Comparisons

Update `src/reconciliation.py`:

```python
from src.models.order_state import OrderState

# Replace TERMINAL_STATUSES and NON_TERMINAL_STATUSES constants
# Use OrderState.is_terminal and OrderState.has_fill_potential instead
```

Update all status checks:

| Current | Replacement |
|---------|-------------|
| `if event.status == "filled":` | `if event.state == OrderState.FILLED:` |
| `if status in TERMINAL_STATUSES:` | `if OrderState.from_alpaca(status).is_terminal:` |
| `if status in NON_TERMINAL_STATUSES:` | `if OrderState.from_alpaca(status).has_fill_potential:` |

---

## Section 2: Test Specifications

**Integration Strategy:** All tests must integrate with existing `tests/test_partial_fills.py`. Follow existing naming conventions:
- Test classes: `Test{Component}`
- Test methods: `test_{behavior}_{condition}`
- Use existing fixtures: `db_connection`, `mock_alpaca` patterns

### 2.1 PositionTracker Integration Tests

**Location:** Add to `tests/test_partial_fills.py` (new class at end of file)

```python
class TestPositionTrackerFillIntegration:
    """Test PositionTracker integration with fill events."""
    pass
```

**Test List:**

| Test Name | Description |
|-----------|-------------|
| `test_position_created_on_first_fill_not_submission` | Verify position is created when first fill arrives, not at order submission |
| `test_position_qty_updated_on_partial_fill` | Verify position qty increases correctly on partial fill |
| `test_position_closed_on_full_fill` | Verify position is removed/stopped when sell order fully fills (exit) |
| `test_position_unchanged_on_duplicate_fill_event` | Verify duplicate fill events don't double-count position qty |
| `test_position_handles_multiple_partial_fills` | Verify position correctly accumulates across 3+ partial fills |
| `test_position_reconciliation_with_missed_fills` | Verify reconcile_fills correctly updates positions for missed fills |
| `test_position_no_drift_after_multiple_partials` | Verify position qty matches sum of all fill deltas after sequence |
| `test_position_avg_price_blended_correctly` | Verify average entry price is correctly blended across multiple fills |
| `test_position_sell_without_existing_logs_warning` | Verify warning is logged when sell fill arrives without position |

### 2.2 OrderState Enum Tests

**Location:** Add to `tests/test_partial_fills.py` (new class)

```python
class TestOrderStateEnum:
    """Test OrderState enum functionality."""
    pass
```

**Test List:**

| Test Name | Description |
|-----------|-------------|
| `test_order_state_enum_has_all_required_states` | Verify all 7 states are defined (PENDING, SUBMITTED, PARTIAL, FILLED, CANCELLED, EXPIRED, REJECTED) |
| `test_order_state_from_alpaca_mapping_correct` | Verify all Alpaca status strings map to correct OrderState |
| `test_order_state_is_terminal_identifies_correctly` | Verify terminal states return True, non-terminal return False |
| `test_order_state_has_fill_potential_identifies_correctly` | Verify states that can receive fills return True |
| `test_order_state_transition_from_pending_to_partial` | Verify state progression through order lifecycle |
| `test_order_state_transition_from_partial_to_filled` | Verify terminal transition works correctly |
| `test_order_state_included_in_order_update_event` | Verify OrderUpdateEvent includes state field |

### 2.3 Integration Tests

**Location:** Add to `tests/test_partial_fills.py` (new class)

```python
class TestFillPositionIntegration:
    """End-to-end tests for fill-to-position flow."""
    pass
```

**Test List:**

| Test Name | Description |
|-----------|-------------|
| `test_stream_fill_event_updates_position_correctly` | Full flow: stream event → OrderUpdatesHandler → PositionTracker update |
| `test_reconciliation_syncs_missed_partial_fills` | Reconciliation detects drift and updates both fills table and position |
| `test_no_position_drift_after_fill_sequence` | After 0→10→25→50 fill sequence, position qty equals 50 |
| `test_position_tracker_receives_delta_not_cumulative` | Verify PositionTracker receives delta_qty, not cumulative |
| `test_fill_idempotency_preserves_position_consistency` | Duplicate fill events don't corrupt position state |

---

## Section 3: Database Schema

### 3.1 No Schema Changes Required

The existing schema is sufficient:

- `fills` table: Already tracks individual fills with deduplication
- `order_intents` table: Already has `status` column (string)
- `position_tracking` table: Already exists for PositionTracker persistence

### 3.2 Index Recommendations

For efficient fill-based position lookups, ensure these indexes exist (verify in schema):

```sql
-- Should already exist from existing schema
CREATE INDEX IF NOT EXISTS idx_fills_alpaca_order_id ON fills(alpaca_order_id);
CREATE INDEX IF NOT EXISTS idx_fills_timestamp ON fills(timestamp_utc);
CREATE INDEX IF NOT EXISTS idx_order_intents_alpaca_id ON order_intents(alpaca_order_id);
```

### 3.3 Data Migration

**None required.** The OrderState enum is a runtime concept; database continues to store string status values.

If desired, a future migration could add a `state` column with CHECK constraint:

```sql
-- OPTIONAL future migration (not in this spec)
ALTER TABLE order_intents ADD COLUMN state TEXT 
    CHECK(state IN ('pending', 'submitted', 'partial', 'filled', 'cancelled', 'expired', 'rejected'));
```

---

## Section 4: Implementation Notes

### 4.1 Files to Modify

| File | Changes |
|------|---------|
| `src/position_tracker.py` | Add `update_position_from_fill()` method; modify `start_tracking()` to NOT be called on order submission |
| `src/data/order_updates.py` | Add PositionTracker parameter; call `update_position_from_fill()` after processing fill delta |
| `src/reconciliation.py` | Import OrderState; replace string status checks with enum |
| `src/event_bus.py` | Add `state: OrderState` field to OrderUpdateEvent |
| `src/orchestrator.py` | Wire PositionTracker into OrderUpdatesHandler |
| `src/models/order_state.py` | **NEW FILE** - Create OrderState enum |
| `tests/test_partial_fills.py` | Add new test classes (PositionTrackerFillIntegration, OrderStateEnum, FillPositionIntegration) |

### 4.2 Files NOT to Modify

| File | Reason |
|------|--------|
| `src/state_store.py` | Fill persistence logic already working |
| Fills table schema | Already sophisticated, no changes needed |
| Core fill delta computation | Already working correctly |
| Deduplication logic | `insert_fill_idempotent()` already handles this |
| `src/order_manager.py` | Position creation on submission will be removed, but order lifecycle logic stays |

### 4.3 Key Implementation Sequence

1. **Create OrderState enum** (`src/models/order_state.py`)
2. **Update OrderUpdateEvent** to include state field
3. **Update OrderUpdatesHandler** to populate state and accept PositionTracker
4. **Add PositionTracker.update_position_from_fill()** method
5. **Remove position creation on order submission** (find where `start_tracking()` is called on order submission)
6. **Wire PositionTracker** into OrderUpdatesHandler in orchestrator
7. **Update reconciliation** to use OrderState enum
8. **Write tests** following the test specifications above

### 4.4 Potential Edge Cases

| Edge Case | Handling |
|-----------|----------|
| Sell fill before any buy (orphan exit) | Log warning, do not create position |
| Fill with zero delta_qty | Skip position update (idempotent) |
| Fill with None avg_fill_price | Use last known price or skip blending |
| Multiple fills with same fill_id | Deduplication at fill layer prevents double counting |
| Position qty goes negative | Clamp to zero and close position |
| Partial fill on exit order | Reduce position proportionally, keep tracking if remaining |

---

## Section 5: Acceptance Criteria

- [ ] **Position Creation Timing:** PositionTracker creates positions on first fill event, not at order submission
- [ ] **Position Qty Accuracy:** Position qty accurately tracks cumulative filled amount (sum of all deltas)
- [ ] **OrderState Enum:** OrderState enum is defined and used for all status comparisons
- [ ] **EventBus Integration:** OrderUpdateEvent includes `state: OrderState` field
- [ ] **Handler Integration:** OrderUpdatesHandler calls PositionTracker on each fill delta
- [ ] **Average Price Blending:** Position entry price correctly blends across multiple fills
- [ ] **Position Closure:** Positions are properly closed/removed when sell fills exhaust qty
- [ ] **Test Coverage:** All 22 tests specified in Section 2 pass
- [ ] **No Regressions:** All existing tests in `test_partial_fills.py` still pass
- [ ] **Reconciliation:** Missed fills from reconciliation correctly update positions
- [ ] **Documentation:** Code comments updated to reflect new behavior

---

## Section 6: Effort Estimate

| Phase | Estimate | Notes |
|-------|----------|-------|
| OrderState enum creation | 0.5 day | New file + event bus integration |
| PositionTracker updates | 0.5-1 day | New method + removal of submission-time creation |
| Handler wiring | 0.5 day | Parameter passing + orchestrator integration |
| Reconciliation updates | 0.25 day | Replace string checks with enum |
| Tests | 1 day | 22 new tests following existing patterns |
| Review/fixes | 0.5 day | Code review + bug fixes |
| **Total** | **2.75-3.25 days** | Slightly under original 2.5-3.5 estimate |

---

## Appendix A: Mapping Reference

### Alpaca Status → OrderState

| Alpaca Status | OrderState | Notes |
|---------------|------------|-------|
| new | PENDING | Order created, not yet submitted |
| pending_new | PENDING | Submission in progress |
| submitted | SUBMITTED | With broker, awaiting acceptance |
| accepted | SUBMITTED | Accepted by broker, may fill |
| partially_filled | PARTIAL | Some quantity filled, order open |
| filled | FILLED | Complete fill, terminal |
| canceled | CANCELLED | Cancelled by user/system, terminal |
| pending_cancel | CANCELLED | Cancellation in progress |
| expired | EXPIRED | Order expired, terminal |
| rejected | REJECTED | Order rejected, terminal |

### Status Category Matrix

| OrderState | is_terminal | has_fill_potential |
|------------|-------------|-------------------|
| PENDING | False | True |
| SUBMITTED | False | True |
| PARTIAL | False | True |
| FILLED | True | False |
| CANCELLED | True | False |
| EXPIRED | True | False |
| REJECTED | True | False |

---

## Appendix B: Test Coverage Summary

| Category | Test Count | Focus |
|----------|------------|-------|
| PositionTracker Integration | 9 | Fill-to-position flow, creation, updates, closure |
| OrderState Enum | 7 | Enum behavior, mappings, properties |
| End-to-End Integration | 6 | Full flow across components |
| **Total New Tests** | **22** | |
| **Existing Tests** | **~30** | Delta computation, idempotency, reconciliation |
| **Combined Total** | **~52** | Comprehensive partial fill coverage |

---

*Specification prepared for python-dev implementation*
