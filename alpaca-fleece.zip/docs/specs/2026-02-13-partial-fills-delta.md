# Partial Fills Delta Specification

**Date:** 2026-02-13  
**Branch:** feat/partial-fills  
**Status:** Ready for Implementation  
**Document Type:** Delta (Additional Features Beyond Simplified Spec)  

---

## Overview

This document specifies **additional features** for partial fill handling that extend beyond the [simplified compliance specification](./2026-02-13-partial-fills-simplified-compliance.md). The simplified spec covers core compliance (PositionTracker wiring, OrderState enum, 22 integration tests). This delta covers **configurable strategies**, **typed dataclasses**, and **enhanced database schema**.

---

## Section 1: Additional Dataclasses

### 1.1 OrderFill Dataclass

**File:** `src/models/order_fill.py`

**Purpose:** Replace raw database row access with strongly-typed OrderFill objects throughout the fill processing pipeline.

```python
@dataclass(frozen=True)
class OrderFill:
    """Represents a single partial or complete fill event.
    
    Immutable by design—fills are historical facts that cannot change.
    """
    fill_id: str                          # Unique identifier (Alpaca fill_id)
    order_id: str                         # Alpaca order ID
    client_order_id: Optional[str]        # Internal client order ID (FK to order_intents)
    symbol: str
    delta_qty: Decimal                    # Quantity filled in THIS event (not cumulative)
    cum_qty: Decimal                      # Cumulative filled quantity after this fill
    fill_price: Decimal                   # Execution price for this fill
    price_is_estimate: bool               # True if price interpolated (reconciliation)
    side: str                             # "buy" or "sell"
    timestamp_utc: datetime
    created_at: datetime                  # Local record timestamp
    
    @property
    def fill_value(self) -> Decimal:
        """Total value of this fill (qty * price)."""
        return self.delta_qty * self.fill_price
```

**Key Design Decisions:**
- `frozen=True` — fills are append-only historical records
- `Decimal` for all monetary/qty values (precision-critical)
- `price_is_estimate` flag for reconciliation-synthesized fills
- Links to both Alpaca `order_id` and internal `client_order_id`

---

### 1.2 TrackedOrder Dataclass

**File:** `src/models/tracked_order.py`

**Purpose:** Aggregate wrapper combining an order's intent, current state, and complete fill history for strategy decision-making.

```python
@dataclass
class TrackedOrder:
    """Complete order context for partial fill strategy decisions.
    
    Mutable—state and fills update as order progresses through lifecycle.
    """
    client_order_id: str
    alpaca_order_id: Optional[str]
    symbol: str
    side: str
    requested_qty: Decimal
    state: OrderState
    partial_fill_strategy: str          # "reject", "accept_retry", "scale_down", "accept_partial"
    fills: List[OrderFill] = field(default_factory=list)
    submitted_at: Optional[datetime] = None
    last_updated_at: Optional[datetime] = None
    
    @property
    def filled_qty(self) -> Decimal:
        """Sum of all fill deltas (cumulative filled)."""
        return sum(f.delta_qty for f in self.fills)
    
    @property
    def remaining_qty(self) -> Decimal:
        """Unfilled portion of the order."""
        return self.requested_qty - self.filled_qty
    
    @property
    def avg_fill_price(self) -> Decimal:
        """Volume-weighted average price across all fills."""
        if not self.fills:
            return Decimal("0")
        total_value = sum(f.fill_value for f in self.fills)
        return total_value / self.filled_qty
    
    @property
    def fill_percent(self) -> float:
        """Percentage of order that has filled (0.0-100.0)."""
        if self.requested_qty == 0:
            return 0.0
        return float(self.filled_qty / self.requested_qty * 100)
    
    @property
    def has_partial_fill(self) -> bool:
        """True if order has at least one fill but is not complete."""
        return self.filled_qty > 0 and self.filled_qty < self.requested_qty
    
    def add_fill(self, fill: OrderFill) -> None:
        """Append a new fill to the order history."""
        self.fills.append(fill)
        self.last_updated_at = datetime.now(timezone.utc)
```

**Key Design Decisions:**
- Mutable state tracks order progression
- Computed properties aggregate fill data efficiently
- `partial_fill_strategy` field links to configuration
- Separates `client_order_id` (internal) from `alpaca_order_id` (external)

---

### 1.3 OrderIntent Dataclass

**File:** `src/models/order_intent.py`

**Purpose:** Replace dict-based order intents with a strongly-typed dataclass that carries partial fill strategy preferences.

```python
@dataclass(frozen=True)
class OrderIntent:
    """Intent to submit an order, with configuration for partial fill handling.
    
    Created by strategy logic, consumed by OrderManager.
    """
    symbol: str
    side: str                           # "buy" or "sell"
    qty: Decimal
    order_type: str = "market"          # "market", "limit", etc.
    limit_price: Optional[Decimal] = None
    time_in_force: str = "day"
    partial_fill_strategy: Optional[str] = None  # Override default strategy
    strategy_name: Optional[str] = None  # For strategy-specific overrides
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        # Validation
        if self.side not in ("buy", "sell"):
            raise ValueError(f"Invalid side: {self.side}")
        if self.qty <= 0:
            raise ValueError(f"Quantity must be positive: {self.qty}")
        if self.order_type == "limit" and self.limit_price is None:
            raise ValueError("Limit orders require limit_price")
```

**Key Design Decisions:**
- `frozen=True` — intent is immutable once created
- Optional `partial_fill_strategy` allows per-order overrides
- `strategy_name` enables config-based strategy selection
- Validation in `__post_init__` catches errors early

---

## Section 2: Partial Fill Strategies

### 2.1 Strategy Interface

**File:** `src/strategies/partial_fill_strategy.py`

```python
from abc import ABC, abstractmethod
from enum import Enum, auto


class StrategyDecision(Enum):
    """Possible outcomes from a partial fill strategy."""
    CONTINUE = auto()           # Keep order open, do nothing
    CANCEL_REMAINING = auto()   # Cancel unfilled portion
    SUBMIT_RETRY = auto()       # Cancel + submit new order for remainder
    CLOSE_POSITION = auto()     # Accept partial, reduce position target


class PartialFillStrategy(ABC):
    """Base class for partial fill handling strategies.
    
    Strategies decide what action to take when an order receives
    a partial fill (has fills but is not complete).
    """
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Unique strategy identifier (used in config)."""
        pass
    
    @abstractmethod
    def on_partial_fill(
        self,
        order: TrackedOrder,
        new_fill: OrderFill,
        context: Dict[str, Any]
    ) -> StrategyDecision:
        """Called when an order receives a partial fill.
        
        Args:
            order: The tracked order with complete fill history
            new_fill: The fill that triggered this call
            context: Additional context (market data, position state, etc.)
            
        Returns:
            Decision on how to handle the partial fill
        """
        pass
    
    def on_fill_complete(
        self,
        order: TrackedOrder,
        context: Dict[str, Any]
    ) -> None:
        """Called when order reaches FILLED state (optional hook)."""
        pass
```

---

### 2.2 Strategy Implementations

**Directory:** `src/strategies/strategies/`

#### A. RejectStrategy
**File:** `src/strategies/strategies/reject.py`

```python
class RejectStrategy(PartialFillStrategy):
    """Strategy A: REJECT - Cancel on first partial fill.
    
    Use case: Strategies requiring exact position sizes (e.g., pairs trading).
    Any partial fill is unacceptable—cancel and alert.
    """
    name = "reject"
    
    def on_partial_fill(self, order, new_fill, context):
        logger.warning(
            f"Rejecting order {order.client_order_id}: "
            f"partial fill {order.fill_percent:.1f}% not allowed"
        )
        return StrategyDecision.CANCEL_REMAINING
```

#### B. AcceptAndRetryStrategy
**File:** `src/strategies/strategies/accept_retry.py`

```python
class AcceptAndRetryStrategy(PartialFillStrategy):
    """Strategy B: ACCEPT_AND_RETRY - Accept partial, submit new order.
    
    Use case: Momentum strategies where getting some fill is better than none,
    but target position should still be attempted.
    """
    name = "accept_retry"
    
    def on_partial_fill(self, order, new_fill, context):
        logger.info(
            f"Accepting partial fill {order.fill_percent:.1f}% for "
            f"{order.client_order_id}, will retry remainder"
        )
        return StrategyDecision.SUBMIT_RETRY
```

#### C. ScaleDownStrategy
**File:** `src/strategies/strategies/scale_down.py`

```python
class ScaleDownStrategy(PartialFillStrategy):
    """Strategy C: SCALE_DOWN - Reduce position target to filled amount.
    
    Use case: Risk-adjusted position sizing where partial fill is acceptable
    and position target is reduced to match actual fill.
    """
    name = "scale_down"
    
    def on_partial_fill(self, order, new_fill, context):
        logger.info(
            f"Scaling down position for {order.client_order_id}: "
            f"target reduced from {order.requested_qty} to {order.filled_qty}"
        )
        return StrategyDecision.CLOSE_POSITION
```

#### D. AcceptPartialStrategy
**File:** `src/strategies/strategies/accept_partial.py`

```python
class AcceptPartialStrategy(PartialFillStrategy):
    """Strategy D: ACCEPT_PARTIAL - Current behavior, default.
    
    Leave order open until complete, cancelled, or expired.
    No special action on partial fills.
    """
    name = "accept_partial"
    
    def on_partial_fill(self, order, new_fill, context):
        # Default behavior: do nothing, let order continue
        logger.debug(
            f"Order {order.client_order_id} partial fill: "
            f"{order.filled_qty}/{order.requested_qty}"
        )
        return StrategyDecision.CONTINUE
```

---

### 2.3 Strategy Selector

**File:** `src/strategies/strategy_selector.py`

```python
class StrategySelector:
    """Selects appropriate partial fill strategy based on configuration.
    
    Resolution order:
    1. Order-level override (OrderIntent.partial_fill_strategy)
    2. Strategy-specific override (config.strategy_overrides)
    3. Default strategy (config.default_strategy)
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.default_strategy = config.get("default_strategy", "accept_partial")
        self.overrides = config.get("strategy_overrides", {})
        self._strategies: Dict[str, PartialFillStrategy] = {}
        
    def register(self, strategy: PartialFillStrategy) -> None:
        """Register a strategy implementation."""
        self._strategies[strategy.name] = strategy
        
    def select(
        self,
        intent: Optional[OrderIntent] = None,
        strategy_name: Optional[str] = None
    ) -> PartialFillStrategy:
        """Select strategy based on order intent and config."""
        
        # 1. Order-level override
        if intent and intent.partial_fill_strategy:
            return self._get_strategy(intent.partial_fill_strategy)
            
        # 2. Strategy-specific override
        if strategy_name and strategy_name in self.overrides:
            return self._get_strategy(self.overrides[strategy_name])
            
        # 3. Default
        return self._get_strategy(self.default_strategy)
        
    def _get_strategy(self, name: str) -> PartialFillStrategy:
        if name not in self._strategies:
            raise ValueError(f"Unknown partial fill strategy: {name}")
        return self._strategies[name]
```

---

### 2.4 Configuration Schema

**File:** `config/default.yaml` (addition)

```yaml
partial_fill:
  # Default strategy for all orders
  default_strategy: accept_partial
  
  # Per-trading-strategy overrides
  strategy_overrides:
    # Momentum breakout: retry to hit target position
    momentum_breakout: accept_retry
    
    # Pairs trading: require exact sizing
    pairs_trading: reject
    
    # Risk-adjusted sizing: accept partial as final
    risk_adjusted: scale_down
  
  # Timeout-based strategy switch (optional enhancement)
  timeout_seconds: null  # null = disabled
  timeout_strategy: accept_partial  # Switch to this after timeout
```

---

## Section 3: Database Additions

### 3.1 Table Renames

| Old Name | New Name | Reason |
|----------|----------|--------|
| `fills` | `order_fills` | Consistent naming (matches `order_intents`) |

**Migration:**
```sql
ALTER TABLE fills RENAME TO order_fills;
```

---

### 3.2 Foreign Key Addition

Add FK from `order_fills` to `order_intents`:

```sql
-- Add client_order_id column
ALTER TABLE order_fills ADD COLUMN client_order_id TEXT;

-- Create index for FK lookups
CREATE INDEX idx_order_fills_client_order_id ON order_fills(client_order_id);

-- Add foreign key constraint (SQLite: requires table rebuild)
-- Note: SQLite doesn't support ADD CONSTRAINT; use table rebuild pattern
```

---

### 3.3 Column Addition

Add `partial_fill_strategy` to `order_intents`:

```sql
ALTER TABLE order_intents ADD COLUMN partial_fill_strategy TEXT DEFAULT 'accept_partial';
```

---

### 3.4 Database Views

**View 1: order_fill_summary**
```sql
CREATE VIEW order_fill_summary AS
SELECT 
    oi.client_order_id,
    oi.symbol,
    oi.side,
    oi.requested_qty,
    oi.partial_fill_strategy,
    COUNT(of.fill_id) as fill_count,
    SUM(of.delta_qty) as total_filled,
    AVG(of.fill_price) as avg_fill_price,
    MAX(of.timestamp_utc) as last_fill_time
FROM order_intents oi
LEFT JOIN order_fills of ON oi.client_order_id = of.client_order_id
GROUP BY oi.client_order_id;
```

**View 2: partial_fill_orders**
```sql
CREATE VIEW partial_fill_orders AS
SELECT 
    oi.*,
    COALESCE(SUM(of.delta_qty), 0) as filled_qty,
    oi.requested_qty - COALESCE(SUM(of.delta_qty), 0) as remaining_qty
FROM order_intents oi
LEFT JOIN order_fills of ON oi.client_order_id = of.client_order_id
WHERE oi.state = 'partial'
GROUP BY oi.client_order_id
HAVING filled_qty > 0 AND filled_qty < oi.requested_qty;
```

---

## Section 4: Files to Create

| File | Purpose | Complexity |
|------|---------|------------|
| `src/models/order_fill.py` | OrderFill dataclass | Low |
| `src/models/tracked_order.py` | TrackedOrder dataclass | Low |
| `src/models/order_intent.py` | OrderIntent dataclass | Low |
| `src/strategies/partial_fill_strategy.py` | Strategy ABC interface | Low |
| `src/strategies/strategy_selector.py` | Strategy resolution logic | Medium |
| `src/strategies/strategies/__init__.py` | Strategy exports | Low |
| `src/strategies/strategies/reject.py` | RejectStrategy | Low |
| `src/strategies/strategies/accept_retry.py` | AcceptAndRetryStrategy | Low |
| `src/strategies/strategies/scale_down.py` | ScaleDownStrategy | Low |
| `src/strategies/strategies/accept_partial.py` | AcceptPartialStrategy | Low |
| `src/data/order_updates.py` | Modify to invoke StrategySelector | Medium |
| `migrations/003_partial_fill_strategy.sql` | DB schema changes | Low |

---

## Section 5: Integration Points

### 5.1 OrderFill Usage

**Where:** `PositionTracker.update_position_from_fill()`

**Integration:**
- Currently receives raw parameters (`symbol`, `delta_qty`, etc.)
- **Enhancement:** Accept `OrderFill` dataclass directly
- Simplified spec provides base method; delta adds typed overload

```python
# Simplified spec (base)
async def update_position_from_fill(
    self, symbol: str, delta_qty: Decimal, ...
) -> Optional[PositionData]:
    ...

# Delta addition (typed overload)
async def update_position_from_fill(
    self, fill: OrderFill
) -> Optional[PositionData]:
    return await self.update_position_from_fill(
        symbol=fill.symbol,
        delta_qty=fill.delta_qty,
        fill_price=fill.fill_price,
        side=fill.side,
        timestamp=fill.timestamp_utc,
    )
```

---

### 5.2 TrackedOrder Usage

**Where:** `OrderUpdatesHandler.on_order_update()`

**Integration:**
- Build `TrackedOrder` from DB query (order + fills)
- Pass to strategy for decision on partial fills
- Update order_intents.state based on decision

```python
async def on_order_update(self, raw_update: Any) -> None:
    # ... simplified spec: parse event, persist fill ...
    
    # Delta addition: strategy decision
    if event.state == OrderState.PARTIAL:
        tracked = self._build_tracked_order(event.client_order_id)
        strategy = self.strategy_selector.select(
            intent=tracked.to_intent(),
            strategy_name=tracked.strategy_name
        )
        decision = strategy.on_partial_fill(tracked, fill, context={})
        await self._execute_decision(decision, tracked)
```

---

### 5.3 StrategySelector Usage

**Where:** `OrderUpdatesHandler.__init__()` and `on_order_update()`

**Integration:**
- Initialize with config in handler constructor
- Register all 4 strategy implementations
- Call `select()` when partial fill detected

---

### 5.4 OrderIntent Usage

**Where:** `OrderManager.submit_order()`

**Integration:**
- Replace dict-based intent with `OrderIntent` dataclass
- Store `partial_fill_strategy` in `order_intents` table
- Pass intent to downstream components

```python
# Before (simplified)
async def submit_order(self, symbol: str, qty: Decimal, side: str) -> str:
    intent = {"symbol": symbol, "qty": qty, "side": side}
    
# After (delta)
async def submit_order(self, intent: OrderIntent) -> str:
    # intent carries partial_fill_strategy
    # persisted to DB with order record
```

---

## Section 6: Effort Estimate

| Phase | Estimate | Notes |
|-------|----------|-------|
| **Dataclasses** | 0.5 day | OrderFill, TrackedOrder, OrderIntent—straightforward |
| **Strategy Interface** | 0.25 day | ABC base class, StrategyDecision enum |
| **4 Strategy Implementations** | 0.5 day | Reject, AcceptRetry, ScaleDown, AcceptPartial |
| **StrategySelector** | 0.5 day | Config resolution, registration, selection logic |
| **Database Migrations** | 0.5 day | Rename, FK, column, views |
| **Integration** | 1 day | Wire into OrderUpdatesHandler, OrderManager |
| **Tests** | 1 day | Unit tests for strategies, selector, dataclasses |
| **Review/Fixes** | 0.5 day | Code review, edge cases, bug fixes |
| **Total** | **4.75 days** | Delta work only (simplified spec already covers base) |

---

## Section 7: Dependencies on Simplified Spec

This delta **requires** the simplified spec to be implemented first:

| Simplified Component | Delta Dependency |
|---------------------|------------------|
| `OrderState` enum | Strategy logic uses `order.state` |
| `PositionTracker.update_position_from_fill()` | OrderFill integrates with position updates |
| `OrderUpdatesHandler` structure | Strategy invocation hooks into update flow |
| `order_intents` table | `partial_fill_strategy` column added to it |
| Fill delta computation | Strategy decisions need accurate delta values |

**Implementation Order:**
1. Complete simplified spec (PositionTracker wiring, OrderState, 22 tests)
2. Implement this delta (dataclasses, strategies, DB additions)
3. Integration testing across both specs

---

## Appendix A: Strategy Decision Matrix

| Strategy | Partial Fill Behavior | Complete Fill Behavior | Use Case |
|----------|----------------------|------------------------|----------|
| **reject** | Cancel immediately | Normal completion | Pairs trading, exact sizing required |
| **accept_retry** | Accept, submit new order | Normal completion | Momentum, want full target position |
| **scale_down** | Accept, reduce position target | Normal completion | Risk-adjusted, partial acceptable |
| **accept_partial** | Continue waiting | Normal completion | Default, backward compatible |

---

## Appendix B: Configuration Examples

```yaml
# Conservative: never accept partials
partial_fill:
  default_strategy: reject

# Aggressive momentum: always retry
partial_fill:
  default_strategy: accept_retry

# Mixed by strategy type
partial_fill:
  default_strategy: accept_partial
  strategy_overrides:
    mean_reversion: scale_down
    breakout: accept_retry
    arbitrage: reject
```

---

*Delta specification for features beyond simplified compliance baseline.*
