# Enhancement Specs Review

**Date:** 2026-02-11  
**Branch:** fix/filled-qty  
**Reviewer:** Subagent Analysis  
**Context:** Bot experiencing P&L drift (-$1,809, -1.81%) with excessive churn (71 trades), tight stops being hit, and short lookback period catching noise.

---

## Enhancement Specs Review

### Relevant to Current Issues:

#### 1. **Portfolio-Level Risk Management** (`03-portfolio-risk-management.md`)
- **Relevance:** HIGH - Addresses churn by implementing correlation-aware position sizing. Prevents over-concentration in correlated assets (e.g., buying AAPL and MSFT simultaneously = one tech bet). Includes sector exposure limits and portfolio volatility forecasting.
- **Impact on Issues:** 
  - Reduces false signals by limiting correlated positions
  - Position sizing adjustments could reduce overall trade frequency
  - Correlation-adjusted risk helps avoid crowded trades
- **Priority:** HIGH
- **Status:** Draft/Ready for implementation
- **Estimated Effort:** 5-7 days

#### 2. **Multi-Strategy Framework** (`06-multi-strategy-framework.md`)
- **Relevance:** HIGH - Provides alternative strategies (mean reversion, momentum) that could filter out SMA crossover noise. Includes regime-based allocation (trending vs ranging markets).
- **Impact on Issues:**
  - **Mean reversion strategy:** Better for ranging markets (catches reversals instead of chasing)
  - **Momentum strategy:** Requires volume confirmation (filters weak signals)
  - **Regime detection:** Could reduce churn by not trading SMA crossovers in ranging markets
  - Different timeframes (1Min, 5Min) reduce noise sensitivity
- **Priority:** HIGH
- **Status:** Draft/Ready for implementation
- **Estimated Effort:** 7-10 days

#### 3. **Backtesting Engine** (`05-backtesting-engine.md`)
- **Relevance:** MEDIUM-HIGH - Essential for validating parameter changes (longer lookback periods, wider stops) before deploying to live trading.
- **Impact on Issues:**
  - Test longer SMA periods (20/50 instead of 10/30) on historical data
  - Validate wider stop losses (-3% vs -1.5%) 
  - Walk-forward optimization to find better parameters
  - Monte Carlo simulation for confidence intervals
- **Priority:** MEDIUM-HIGH
- **Status:** Draft/Ready for implementation
- **Estimated Effort:** 10-14 days (largest feature)

#### 4. **Performance Analytics** (`01-performance-analytics.md`)
- **Relevance:** MEDIUM - Provides visibility into risk-adjusted metrics (Sharpe, Sortino, drawdown) to diagnose problems, though doesn't directly fix them.
- **Impact on Issues:**
  - Identifies if high churn is hurting risk-adjusted returns
  - Tracks win rate and expectancy to validate strategy health
  - Alerts when metrics deteriorate
- **Priority:** MEDIUM
- **Status:** Draft/Ready for implementation
- **Estimated Effort:** 3-4 days

#### 5. **Partial Fill Handling** (`02-partial-fill-handling.md`)
- **Relevance:** LOW - Critical for live trading accuracy but doesn't address trading performance issues.
- **Priority:** HIGH (for live trading safety) / LOW (for P&L fix)
- **Status:** Draft/Ready for implementation
- **Estimated Effort:** 4-5 days

### Not Relevant to Trading Performance:

| Spec | File | Reason |
|------|------|--------|
| Performance Reporting | `04-performance-reporting.md` | Operational visibility, tax reporting - doesn't fix trading issues |
| API Key Security | `07-api-key-security.md` | Security infrastructure, not trading logic |
| Live Trading Lock | `08-live-trading-lock.md` | Safety feature, prevents accidental live trading |
| Network Security | `09-network-security.md` | Infrastructure hardening, not strategy |
| Database Schema Migration | `10-database-schema-migration.md` | Infrastructure/DevOps feature |

### Missing Specs (Critical Gaps):

The following are **NOT addressed** by existing specs but are needed to fix the current P&L issues:

#### 1. **Trend Filtering / Longer Lookback Periods**
- **Gap:** No spec for increasing SMA periods or adding trend confirmation
- **What's needed:** 
  - Configurable SMA periods (currently hardcoded to 10/30)
  - Add longer trend filter (e.g., 50/200 SMA) to confirm direction
  - Only trade when short SMA and long trend align
  - This directly addresses the "short lookback catching noise" issue

#### 2. **Stop Loss Optimization**
- **Gap:** No spec for adjusting stop loss logic
- **What's needed:**
  - ATR-based stops (2x ATR instead of fixed percentage)
  - Wider initial stops to avoid noise (-2.5% to -3% vs current -1.5% to -2%)
  - Trailing stop activation threshold (don't trail immediately)
  - Time-based stops (exit if position doesn't move in N bars)

#### 3. **Signal Quality Filters**
- **Gap:** No spec for filtering weak SMA crossover signals
- **What's needed:**
  - Minimum volume threshold for signals
  - Volatility filter (don't trade in low-volatility periods)
  - Confirmation indicators (RSI, MACD) to validate crossovers
  - Cooldown period between trades on same symbol

#### 4. **Trade Frequency Limits**
- **Gap:** No spec for limiting excessive churn
- **What's needed:**
  - Daily/weekly max trade limits per symbol
  - Minimum holding period (don't flip-flop)
  - Correlation-based position limits (already partially in #03)

---

## Recommendation

### Immediate Priority (Address P&L Drift):

1. **First: Multi-Strategy Framework (#06)** - Add mean reversion strategy for ranging markets
   - Fastest path to reduce churn
   - Provides alternative to SMA crossover in choppy markets
   - Can run in parallel without disrupting current SMA strategy

2. **Second: Create NEW spec for Trend Filtering**
   - Add configurable SMA periods to trading.yaml
   - Implement longer-term trend filter (50/200 SMA)
   - Only trade when short SMA aligns with long trend
   - **This directly fixes the "short lookback catching noise" issue**

3. **Third: Create NEW spec for Stop Loss Optimization**
   - ATR-based position sizing
   - Wider initial stops (-2.5% to -3%)
   - Delayed trailing stop activation

4. **Fourth: Portfolio Risk Management (#03)**
   - Prevents over-concentration
   - Reduces correlated position churn

5. **Fifth: Backtesting Engine (#05)**
   - Validate all parameter changes before deployment
   - Essential for testing new specs

### Acceptance Criteria for Missing Specs:

**Trend Filtering Spec should:**
- Make SMA periods configurable in `trading.yaml`
- Add optional long-term trend filter (50/200 SMA)
- Only generate buy signals when price > 200 SMA (or both SMAs aligned)
- Reduce false signals in choppy markets

**Stop Loss Optimization Spec should:**
- Calculate position size based on ATR (risk-based sizing)
- Implement wider initial stops (configurable, default 2.5-3%)
- Add `trailing_activation_pct` (e.g., activate trailing only after +1% profit)
- Add minimum holding period to prevent flip-flopping

---

## Summary

| Spec | Relevance | Priority | Status |
|------|-----------|----------|--------|
| 03 Portfolio Risk Management | HIGH | HIGH | Ready |
| 06 Multi-Strategy Framework | HIGH | HIGH | Ready |
| 05 Backtesting Engine | MEDIUM-HIGH | MEDIUM-HIGH | Ready |
| 01 Performance Analytics | MEDIUM | MEDIUM | Ready |
| 02 Partial Fill Handling | LOW | HIGH* | Ready |
| **Trend Filtering (NEW)** | **CRITICAL** | **HIGHEST** | **Needed** |
| **Stop Loss Optimization (NEW)** | **HIGH** | **HIGH** | **Needed** |

\* High for live trading safety, not P&L issues

**Bottom Line:** The existing specs provide good infrastructure, but a spec specifically for **trend filtering with configurable lookback periods** is critically missing and would have the most immediate impact on reducing churn and noise-driven trades.
