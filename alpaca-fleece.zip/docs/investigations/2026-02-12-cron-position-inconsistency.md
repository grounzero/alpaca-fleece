# Investigation: Cron Job Position Count Inconsistency

**Date:** 2026-02-12  
**Investigator:** Subagent  
**Issue:** Cron job reports showing inconsistent position counts (4 vs 15 positions)

---

## Executive Summary

The position count inconsistency is caused by **multiple sources of truth** for position data that are not synchronized. The bot uses three different methods to query positions, each returning potentially different results depending on timing and state.

---

## Findings

### 1. Multiple Position Data Sources

The system has **three distinct sources** for position data:

| Source | Update Mechanism | Used By |
|--------|-----------------|---------|
| `position_tracking` table | Updated on order fills by PositionTracker | ExitManager, OrderManager |
| `positions_snapshot` table | Updated during reconciliation or manual sync | Reconciliation (startup check) |
| Alpaca API (`broker.get_positions()`) | Real-time external API | Metrics writer, some status checks |

### 2. Current Database State

```
position_tracking:     4 positions (QQQ, TLT, AMZN, NVDA)
positions_snapshot:    4 positions (latest)
Alpaca API:            4 positions (confirmed via metrics.json)
```

### 3. Historical Evidence of Inconsistency

The `positions_snapshot` table shows the flip-flopping pattern:

```
2026-02-12T14:16:05 → 4 positions  ← Current
2026-02-11T18:41:16 → 5 positions
2026-02-11T17:23:11 → 6 positions
2026-02-11T14:40:00 → 9 positions
2026-02-10T18:37:25 → 10 positions
2026-02-09T21:01:09 → 11 positions  ← Maximum (AAPL, AMZN, ARKK, FCX, GOOGL, IWM, META, NFLX, NVDA, SPY, UBER)
```

### 4. Reconciliation Error Evidence

The file `data/reconciliation_error.json` (timestamp: 2026-02-11T18:58:25) shows a discrepancy where:
- SQLite (`positions_snapshot`): SPY = -14 qty
- Alpaca API: SPY = 0 qty

This indicates the snapshot table can contain stale data.

---

## Root Cause Analysis

### The Problem

1. **positions_snapshot is not the authoritative source** - It's only used for startup reconciliation
2. **position_tracking is the runtime authority** - Used by ExitManager and OrderManager
3. **Metrics writer bypasses both** - Calls Alpaca API directly via `broker.get_positions()`

### Why the Flip-Flopping Occurs

1. **Scenario A (4 positions reported):**
   - Metrics writer calls `broker.get_positions()` → gets 4 live positions from Alpaca
   - OR: position_tracking has 4 positions after recent trades

2. **Scenario B (15 positions reported):**
   - A report queries `positions_snapshot` which has stale data from earlier trading activity
   - The snapshot table was not updated after positions were closed
   - OR: A report queries `position_tracking` before reconciliation has completed

### Data Flow Diagram

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────────┐
│   Alpaca API    │────▶│ positions_snapshot│────▶│  Reconciliation │
│  (External)     │     │  (Startup check)  │     │   (On startup)  │
└────────┬────────┘     └──────────────────┘     └─────────────────┘
         │
         │              ┌──────────────────┐     ┌─────────────────┐
         └─────────────▶│ position_tracking │────▶│  ExitManager    │
                        │  (Runtime state)  │     │  OrderManager   │
                        └──────────────────┘     └─────────────────┘
         │
         │              ┌──────────────────┐
         └─────────────▶│   metrics.json    │
                        │  (60s interval)   │
                        └──────────────────┘
```

---

## Which Data Source is "Correct"?

### For Runtime Trading Logic: `position_tracking`
- This is what ExitManager and OrderManager use
- Updated immediately on order fills
- Contains trailing stop metadata

### For External Reporting: Alpaca API
- This is the ground truth from the broker
- Reflects actual account state
- Not affected by local database inconsistencies

### `positions_snapshot` is Auxiliary
- Only used for startup reconciliation
- Can be stale if not updated regularly
- Should NOT be used for operational reporting

---

## Recommended Fixes

### Option 1: Standardize on Alpaca API for All Position Queries (Recommended)

**Change:** Make all position queries go through `broker.get_positions()`

**Pros:**
- Single source of truth
- Always reflects actual account state
- No stale data issues

**Cons:**
- Additional API calls (rate limit consideration)
- Slightly slower than local database queries

**Implementation:**
```python
# In position_tracker.py or a new position_service.py
def get_current_positions():
    """Get positions from authoritative source (Alpaca API)."""
    return broker.get_positions()
```

### Option 2: Synchronize All Tables on Position Changes

**Change:** Update both `position_tracking` and `positions_snapshot` simultaneously

**Implementation:**
- Modify `PositionTracker.start_tracking()` to also update `positions_snapshot`
- Modify `PositionTracker.stop_tracking()` to also remove from `positions_snapshot`

**Pros:**
- Local queries remain fast
- All tables stay in sync

**Cons:**
- More complex write operations
- Risk of write failures causing inconsistency

### Option 3: Add Timestamp Validation

**Change:** Include "last updated" timestamps in position reports

**Implementation:**
```python
def get_positions_with_metadata():
    positions = position_tracking.get_all()
    return {
        "positions": positions,
        "source": "position_tracking",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "count": len(positions)
    }
```

**Pros:**
- Makes staleness visible
- Easier to debug issues

**Cons:**
- Doesn't fix the underlying issue
- Just makes it more observable

### Option 4: Remove positions_snapshot (Simplest)

**Change:** Use `position_tracking` for reconciliation instead of `positions_snapshot`

**Implementation:**
- Modify `reconciliation.py` to query `position_tracking` instead of `positions_snapshot`
- Remove the `positions_snapshot` table entirely

**Pros:**
- Eliminates one source of inconsistency
- Simpler architecture
- `position_tracking` is already updated on fills

**Cons:**
- Requires schema migration
- Need to verify position_tracking is always up to date

---

## Immediate Actions

1. **Identify the cron job** generating the reports and determine which data source it uses
2. **Update the cron job** to use `broker.get_positions()` (Alpaca API) for position counts
3. **Monitor metrics.json** which already uses the correct source (shows 4 positions consistently)

---

## Verification

Current state verification:
```bash
# Check metrics.json (uses Alpaca API)
cat data/metrics.json | jq '.gauges.open_positions'
# Output: 4

# Check position_tracking (runtime state)
sqlite3 data/trades.db "SELECT COUNT(*) FROM position_tracking"
# Output: 4

# Check positions_snapshot (can be stale)
sqlite3 data/trades.db "SELECT COUNT(*) FROM positions_snapshot WHERE timestamp_utc = (SELECT MAX(timestamp_utc) FROM positions_snapshot)"
# Output: 4 (currently, but was 9-11 historically)
```

---

## Conclusion

The position count inconsistency is an **architectural issue** where multiple data sources exist without clear ownership. The `position_tracking` table should be the authoritative source for runtime operations, but the metrics writer correctly uses the Alpaca API for external reporting.

**Recommended solution:** Standardize the cron job to use the same data source as the metrics writer (Alpaca API via `broker.get_positions()`) to ensure consistent position counts in all reports.
