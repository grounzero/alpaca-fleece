# Investigation Report: 8 Stuck Orders (2026-02-10)

## Summary
**Date:** 2026-02-10  
**Investigator:** Subagent  
**Severity:** High - SQLite/Alpaca state mismatch causing phantom positions

## Problem Statement
8 orders were reported stuck in pending states for 3+ hours:
- SLV buy 133 shares (status: `new`, age: 2.9h)
- SLV sell 133 shares (status: `pending_new`, age: 3.1h)
- QQQ sell 16 shares (status: `pending_new`, age: 3.3h)
- UBER buy 133 shares (status: `pending_new`, age: 3.3h)
- GOOGL buy 30 shares (status: `pending_new`, age: 3.6h)
- NFLX buy 244 shares (status: `pending_new`, age: 3.6h)
- META sell 14 shares (status: `pending_new`, age: 3.6h)
- FCX buy 157 shares (status: `new`, age: 3.6h)

## Investigation Findings

### 1. SQLite Status Check

All 8 orders found in `data/trades.db` with the reported pending statuses:

```sql
SELECT client_order_id, symbol, side, status, alpaca_order_id, created_at_utc 
FROM order_intents 
WHERE status IN ('new', 'pending_new', 'pending', 'submitted')
```

### 2. Alpaca API Status Check

| Symbol | Side | SQLite Status | Alpaca Status | Alpaca Order ID |
|--------|------|---------------|---------------|-----------------|
| FCX | buy | `new` | **NO ORDER** | `None` |
| META | sell | `pending_new` | **FILLED** | `7d8e053b-8884-4ed1-9d2b-3ec904505905` |
| NFLX | buy | `pending_new` | **FILLED** | `c9c0f61f-8828-4267-922d-dcddee9bf0ab` |
| GOOGL | buy | `pending_new` | **FILLED** | `5fa19417-f8e7-4ec7-9d93-8ec76bfa5a0e` |
| UBER | buy | `pending_new` | **FILLED** | `a1d9808b-89d8-4106-8321-690cee0312bd` |
| QQQ | sell | `pending_new` | **FILLED** | `b739ff1d-c87e-4f87-8995-4cf1276288a8` |
| SLV | sell | `pending_new` | **FILLED** | `f79f753b-c527-4dc8-bef5-acfdf3ace8e3` |
| SLV | buy | `new` | **NO ORDER** | `None` |

### 3. Duplicate Orders Analysis

SLV has multiple orders. Checking for duplicates:

```sql
SELECT symbol, side, status, COUNT(*) 
FROM order_intents 
WHERE symbol = 'SLV' 
GROUP BY symbol, side, status
```

Results:
- SLV buy, `filled`: 2 orders
- SLV buy, `new`: 1 order (stuck)
- SLV sell, `filled`: 2 orders
- SLV sell, `pending_new`: 1 order (stuck, but actually filled in Alpaca)

### 4. Log Analysis

Found critical error pattern in `logs/alpaca_bot.log`:

```
2026-02-10T17:02:14.672623 ERROR src.stream_polling: Failed to check order 5a4bdfbe95b6b40c: order_id must be a UUID or a UUID str
2026-02-10T17:02:16.674734 ERROR src.stream_polling: Failed to check order 51057fad52fa6ca2: order_id must be a UUID or a UUID str
```

These errors repeat continuously for 2 orders:
- `5a4bdfbe95b6b40c` = SLV buy (no alpaca_order_id)
- `51057fad52fa6ca2` = FCX buy (no alpaca_order_id)

The polling system was trying to check these orders but failed because `alpaca_order_id` was `None`, which is invalid for the Alpaca API.

## Root Cause Analysis

### Issue 1: UUID Validation Bug (Primary)

The order polling mechanism in `src/stream_polling.py` attempts to check all orders with `pending_new` status. However, it doesn't handle the case where `alpaca_order_id` is `None`, causing a UUID validation error that:
1. Crashes the polling attempt for that order
2. Prevents status updates from propagating back to SQLite
3. Leaves orders in `pending_new` state indefinitely, even when filled in Alpaca

### Issue 2: Orders Never Submitted

Two orders have `alpaca_order_id = None`, meaning they were created in SQLite but never actually submitted to Alpaca:
- FCX buy 157 shares (`51057fad52fa6ca2`)
- SLV buy 133 shares (`5a4bdfbe95b6b40c`)

These appear to be orphaned records from a submission failure that wasn't handled properly.

### Issue 3: State Synchronization Failure

For the 6 orders that WERE submitted and filled in Alpaca:
- The SQLite status remains `pending_new`
- The actual Alpaca status is `FILLED`
- This creates a phantom position problem - the bot thinks orders are pending when they've actually executed

## Impact Assessment

1. **Position Tracking:** SQLite shows positions as "pending" when they may actually be filled
2. **Duplicate Risk:** If the bot retries based on "pending" status, it could create duplicate orders
3. **PNL Calculation:** Trades table may be missing these filled orders
4. **Cash Management:** Buying power may be incorrectly calculated based on stale order states

## Recommended Actions

### Immediate Fix (Safe - Read-Only Verification)

Run this script to verify current Alpaca status:

```python
#!/usr/bin/env python3
"""Verify order status mismatch between SQLite and Alpaca."""
import sqlite3
from alpaca.trading.client import TradingClient

# Connect to DB
conn = sqlite3.connect('data/trades.db')
cursor = conn.cursor()

# Get all pending orders
cursor.execute("""
    SELECT client_order_id, symbol, side, status, alpaca_order_id 
    FROM order_intents 
    WHERE status IN ('new', 'pending_new', 'pending', 'submitted')
""")
orders = cursor.fetchall()

print(f"Found {len(orders)} orders in pending states:")
for cid, symbol, side, status, alpaca_id in orders:
    print(f"  {symbol} {side}: {status} (alpaca_id: {alpaca_id or 'NONE'})")

conn.close()
```

### Data Reconciliation Script (Requires Approval)

```python
#!/usr/bin/env python3
"""Reconcile SQLite order status with Alpaca.
   DANGER: This modifies the database. Review before running!"""
import sqlite3
from alpaca.trading.client import TradingClient

# Configuration
DB_PATH = 'data/trades.db'

def reconcile_orders():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Initialize Alpaca client
    client = TradingClient(api_key, secret_key, paper=True)
    
    # Get stuck orders
    cursor.execute("""
        SELECT client_order_id, symbol, side, status, alpaca_order_id 
        FROM order_intents 
        WHERE status IN ('new', 'pending_new', 'pending', 'submitted')
    """)
    orders = cursor.fetchall()
    
    updates = []
    cancels = []
    
    for cid, symbol, side, status, alpaca_id in orders:
        if alpaca_id is None:
            # Never submitted - mark as cancelled/error
            print(f"{symbol} {side}: No alpaca_id, marking as error")
            cancels.append(cid)
        else:
            # Check Alpaca status
            try:
                order = client.get_order_by_id(alpaca_id)
                if order.status.value == 'filled':
                    print(f"{symbol} {side}: SQLite={status} -> Alpaca=filled")
                    updates.append((cid, 'filled', order.filled_qty))
                elif order.status.value in ['canceled', 'expired', 'rejected']:
                    print(f"{symbol} {side}: SQLite={status} -> Alpaca={order.status.value}")
                    cancels.append(cid)
            except Exception as e:
                print(f"{symbol} {side}: Error checking - {e}")
    
    # Preview changes
    print(f"\nWill update {len(updates)} orders to 'filled'")
    print(f"Will mark {len(cancels)} orders as cancelled/error")
    
    # Uncomment to apply changes:
    # for cid, new_status, filled_qty in updates:
    #     cursor.execute("""
    #         UPDATE order_intents 
    #         SET status = ?, filled_qty = ?, updated_at_utc = datetime('now') 
    #         WHERE client_order_id = ?
    #     """, (new_status, filled_qty, cid))
    # 
    # for cid in cancels:
    #     cursor.execute("""
    #         UPDATE order_intents 
    #         SET status = 'error', error_message = 'Never submitted or orphaned', 
    #             updated_at_utc = datetime('now') 
    #         WHERE client_order_id = ?
    #     """, (cid,))
    # 
    # conn.commit()
    conn.close()

if __name__ == '__main__':
    reconcile_orders()
```

### Code Fix (Long-term)

Fix `src/stream_polling.py` to handle `None` alpaca_order_id:

```python
def check_order_status(order):
    """Check order status in Alpaca."""
    if not order.alpaca_order_id:
        # Order was never submitted - skip or mark as error
        logger.warning(f"Order {order.client_order_id} has no alpaca_order_id")
        return None
    
    try:
        alpaca_order = client.get_order_by_id(order.alpaca_order_id)
        return alpaca_order.status
    except Exception as e:
        logger.error(f"Failed to check order {order.client_order_id}: {e}")
        raise
```

## Verification Steps After Fix

1. Run reconciliation script in dry-run mode
2. Verify all filled orders have correct status in SQLite
3. Check that trades table is populated correctly
4. Verify position tracking matches Alpaca
5. Confirm no duplicate active orders exist

## Prevention Measures

1. Add validation: Orders with `status='pending_new'` MUST have `alpaca_order_id`
2. Implement atomic transaction: Update SQLite status only after successful Alpaca submission
3. Add monitoring alert: Orders stuck in pending > 30 minutes
4. Implement order reconciliation job: Run daily to sync SQLite with Alpaca

## Appendix: Order Details

### Orders with Alpaca ID (filled in Alpaca, pending in SQLite)

| Client Order ID | Symbol | Side | Filled Qty | Alpaca Order ID |
|-----------------|--------|------|------------|-----------------|
| 06cda8e30ecce373 | META | sell | 14 | 7d8e053b-8884-4ed1-9d2b-3ec904505905 |
| fac66d411e68c483 | NFLX | buy | 244 | c9c0f61f-8828-4267-922d-dcddee9bf0ab |
| 00daedac5a9f7ab9 | GOOGL | buy | 30 | 5fa19417-f8e7-4ec7-9d93-8ec76bfa5a0e |
| 101e1271b7e930e6 | UBER | buy | 133 | a1d9808b-89d8-4106-8321-690cee0312bd |
| c009a27c3e629cf7 | QQQ | sell | 16 | b739ff1d-c87e-4f87-8995-4cf1276288a8 |
| 77aafc6c5c7e29f6 | SLV | sell | 133 | f79f753b-c527-4dc8-bef5-acfdf3ace8e3 |

### Orders without Alpaca ID (never submitted)

| Client Order ID | Symbol | Side | Qty | Issue |
|-----------------|--------|------|-----|-------|
| 5a4bdfbe95b6b40c | SLV | buy | 133 | Orphaned - never submitted |
| 51057fad52fa6ca2 | FCX | buy | 157 | Orphaned - never submitted |

## Conclusion

The stuck orders are caused by a UUID validation bug in the order polling system that prevents status updates when `alpaca_order_id` is `None`. This caused 6 filled orders to appear pending in SQLite and left 2 orders orphaned without ever being submitted to Alpaca.

**Immediate action required:** Run reconciliation script to sync SQLite with Alpaca.  
**Long-term fix:** Update polling code to handle `None` alpaca_order_id gracefully.
