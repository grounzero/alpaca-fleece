# Database Dataclass Analysis Report

**Date:** 2026-02-13  
**Branch:** feat/partial-fills  
**Scope:** Raw DB row usage vs typed dataclasses

---

## 1. Database Tables Overview

The system uses SQLite with **11 tables** defined in `schema_manager.py`:

| Table | Purpose | Row Access Pattern |
|-------|---------|-------------------|
| `schema_meta` | Schema version tracking | Raw tuple indexing |
| `order_intents` | Active/pending orders | TypedDict conversion |
| `trades` | Completed trade records | Raw insert only |
| `equity_curve` | P&L tracking | Raw insert/select |
| `bot_state` | Key-value state store | Raw tuple indexing |
| `bars` | Market data bars | Raw insert/select |
| `positions_snapshot` | Position snapshots | Raw tuple indexing |
| `signal_gates` | Signal throttling | Raw tuple indexing |
| `fills` | Individual fill records | Raw insert/select |
| `position_tracking` | Active position state | **Dataclass conversion** |

---

## 2. Raw Row Usage Analysis

### 2.1 Files Using Raw Row Access (tuple indexing)

| File | Lines | Pattern | Risk Level |
|------|-------|---------|------------|
| `state_store.py` | 78-79, 170-171, 266, 347-360, 388-400 | `row[0]`, `row[1]`... | **High** |
| `reconciliation.py` | 131-135 | `row[0]`, `row[1]`, `row[2]` | Medium |
| `position_tracker.py` | 333-349 | `row[0]` through `row[10]` | Low (converts to dataclass) |
| `schema_manager.py` | 250, 256, 262, 342, 425-434 | `row[0]`, `row[1]` | Low (schema introspection) |
| `stream_polling.py` | 616 | `cursor.fetchall()` | Unknown |

### 2.2 Specific Raw Access Patterns

**state_store.py - Order Intent Queries:**
```python
# 3 separate methods manually map row indices to dict keys:
# get_order_intent(): row[0] through row[9]
# get_all_order_intents(): Same pattern in loop
# get_order_intent_by_alpaca_id(): Same pattern

return {
    "client_order_id": row[0],
    "strategy": row[1],
    "symbol": row[2],
    "side": row[3],
    "qty": float(row[4]),
    "atr": parse_optional_float(row[5]),
    "status": row[6],
    "filled_qty": parse_optional_float(row[7]),
    "filled_avg_price": parse_optional_float(row[8]),
    "alpaca_order_id": row[9],
}
```

**position_tracker.py - Position Loading:**
```python
# Loads from DB and converts to PositionData dataclass
PositionData(
    symbol=row[0],
    side=row[1],
    qty=float(row[2]),
    entry_price=float(row[3]),
    ...
)
```

**reconciliation.py - Position Snapshot:**
```python
# Raw tuple unpacking without type safety
row[0]: {"qty": row[1], "avg_entry_price": row[2]}
```

---

## 3. Current Dataclass Usage

### 3.1 Existing Dataclasses

| Dataclass | Location | Purpose | DB Mapped? |
|-----------|----------|---------|------------|
| `PositionData` | `position_tracker.py:26` | Position tracking | **Yes** |
| `BarEvent` | `event_bus.py:23` | Market data event | No (event only) |
| `SignalEvent` | `event_bus.py:38` | Strategy signal | No (event only) |
| `OrderIntentEvent` | `event_bus.py:48` | Order intent | No (event only) |
| `OrderUpdateEvent` | `event_bus.py:59` | Order update | No (event only) |
| `ExitSignalEvent` | `event_bus.py:91` | Exit signal | No (event only) |
| `Config` | `config.py:33` | App configuration | No |
| `TradeRecord` | `metrics.py:17` | Trade metrics | No |

### 3.2 TypedDict Definitions (Partial Type Safety)

| TypedDict | Location | Purpose |
|-----------|----------|---------|
| `OrderIntentRow` | `state_store.py:21` | Order intent query result |
| `AccountInfo` | `broker.py:31` | Broker account data |
| `PositionInfo` | `broker.py:40` | Broker position data |
| `OrderInfo` | `broker.py:49` | Broker order data |
| `ClockInfo` | `broker.py:63` | Market clock data |
| `EnvConfig` | `config.py:18` | Environment config |

---

## 4. Type Safety Assessment

### 4.1 `Dict[str, Any]` Usage (High Risk)

Found **17 occurrences** in 5 files:

| File | Count | Usage Context |
|------|-------|---------------|
| `async_broker_adapter.py` | 11 | Broker interface returns |
| `reconciliation.py` | 4 | Broker data handling |
| `health_check.py` | 1 | Status return |
| `stream_polling.py` | 1 | Order lookup |

**Key locations:**
- `async_broker_adapter.py:46-54` - All broker methods return `Dict[str, Any]` or `List[Dict[str, Any]]`
- `reconciliation.py:56-57` - Alpaca API responses cast to `Dict[str, Any]`

### 4.2 Specific Type Safety Gaps

1. **order_intents table queries** - Return `dict` manually constructed from row tuples
2. **signal_gates table** - Returns `dict` with datetime parsing
3. **fills table** - Raw inserts, no structured return type
4. **positions_snapshot** - Raw tuple access
5. **bot_state** - String-only key-value, minimal risk

---

## 5. Gap Analysis: DB Tables → Types

| Table | Current Return Type | Ideal Type | Coverage |
|-------|---------------------|------------|----------|
| `order_intents` | `OrderIntentRow` (TypedDict) | `OrderIntent` dataclass | 60% |
| `trades` | None (insert only) | `Trade` dataclass | 0% |
| `fills` | None (insert only) | `Fill` dataclass | 0% |
| `position_tracking` | `PositionData` dataclass | `PositionData` dataclass | **100%** |
| `signal_gates` | `dict` | `SignalGate` dataclass | 30% |
| `bot_state` | `Optional[str]` | `Optional[str]` | 100% (simple) |
| `bars` | `Bar` (implicit via pandas) | `Bar` dataclass | 50% |
| `equity_curve` | None (insert only) | `EquityPoint` dataclass | 0% |
| `positions_snapshot` | `dict` | `PositionSnapshot` dataclass | 20% |

---

## 6. Recommendations

### 6.1 Is Full Dataclass Coverage Worth It?

**Verdict: YES, but prioritize high-impact areas first**

**Benefits:**
- Type safety catches column name/index errors at compile time
- IDE autocomplete and refactoring support
- Self-documenting code (field names vs row[5])
- Easier testing with concrete types
- Prevents silent bugs from column order changes

**Costs:**
- Initial development time (~2-4 hours)
- Ongoing maintenance when schema changes
- Slight runtime overhead (minimal)

### 6.2 Priority Tiers

#### 🔴 HIGH PRIORITY (Do First)

1. **`order_intents` table** (3 methods affected)
   - Most queried table in the system
   - Currently uses manual dict construction in 3 places
   - Risk of index misalignment on schema changes
   
2. **`fills` table** (new in partial-fills branch)
   - Core to new functionality
   - Used in reconciliation and order processing
   - High churn table, type safety critical

3. **Broker adapter returns** (`Dict[str, Any]`)
   - Interface boundary with external API
   - 11 occurrences, high blast radius
   - Replace with proper dataclasses for Alpaca responses

#### 🟡 MEDIUM PRIORITY (Do Next)

4. **`trades` table**
   - Used in metrics and reporting
   - Lower query frequency than order_intents

5. **`signal_gates` table**
   - Used in signal throttling
   - Simple structure, lower risk

#### 🟢 LOW PRIORITY (Nice to Have)

6. **`bars` table** - Already using pandas DataFrames effectively
7. **`equity_curve`** - Simple inserts, minimal querying
8. **`positions_snapshot`** - Used only in reconciliation

---

## 7. Effort Estimate

### Phase 1: Core Tables (High Priority)
- Create `OrderIntent`, `Fill`, `AlpacaOrder` dataclasses
- Update `state_store.py` methods to return dataclasses
- Update `order_updates.py` to use typed objects
- Update `reconciliation.py` to use typed objects
- **Estimated effort: 3-4 hours**

### Phase 2: Broker Interface (High Priority)
- Create `OrderInfo`, `PositionInfo`, `AccountInfo` dataclasses (replace TypedDicts)
- Update `async_broker_adapter.py` return types
- Update all call sites to use typed attributes
- **Estimated effort: 2-3 hours**

### Phase 3: Remaining Tables (Medium/Low Priority)
- Create `Trade`, `SignalGate`, `PositionSnapshot` dataclasses
- Update remaining raw row access patterns
- **Estimated effort: 2 hours**

**Total estimated effort: 7-9 hours**

---

## 8. Key Areas That Would Benefit Most

1. **`state_store.py:get_order_intent*()` methods**
   - 3 methods with identical row mapping logic
   - Central to order lifecycle
   - High risk of bugs on schema changes

2. **`order_updates.py:OrderUpdatesHandler`**
   - Processes all order updates
   - Interface between raw broker data and events
   - Type safety would prevent many edge case bugs

3. **`reconciliation.py`**
   - Startup-critical code
   - Compares DB state with broker state
   - Type mismatches could cause reconciliation failures

4. **`stream_polling.py:_get_submitted_orders()`**
   - Returns `List[Dict[str, Any]]`
   - Used in order submission flow
   - Type safety would catch field access errors

---

## 9. Summary

| Metric | Count |
|--------|-------|
| Total DB tables | 11 |
| Tables with dataclass coverage | 1 (position_tracking) |
| Tables with TypedDict coverage | 1 (order_intents) |
| Raw row access locations | 15+ |
| `Dict[str, Any]` occurrences | 17 |
| Estimated effort to full coverage | 7-9 hours |

**Recommendation:** Proceed with Phase 1 (core tables) immediately as part of the partial-fills branch work. The `order_intents` and `fills` tables are central to the new functionality and would benefit significantly from type safety. Phase 2 (broker interface) should follow soon after to prevent type-related bugs at the API boundary.
