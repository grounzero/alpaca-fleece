# Signal-Level Deduplication Analysis

**Date:** 2026-02-11  
**Branch:** fix/trades-dedupe-pr  
**Issue:** Duplicate buy signals for same symbol within minutes

---

## Executive Summary

The bot is generating **duplicate buy signals** for the same symbol (TSLA) within hours:

| Time | Symbol | Side | Qty | Price | Order ID | Client Order ID |
|------|--------|------|-----|-------|----------|-----------------|
| 14:40 | TSLA | buy | 23 | $433.72 | 4bfb6d45... | 0434d107... |
| 17:24 | TSLA | buy | 23 | $423.85 | 966fd182... | 48ae73fa... |

**Database-level deduplication IS working** (different order/client IDs prove this), but **signal-level deduplication is NOT happening**, allowing the strategy to generate duplicate signals on subsequent bars.

---

## 1. Root Cause Analysis

### 1.1 Current Signal Generation Logic

The `SMACrossover.on_bar()` method (lines 58-104 in `src/strategy/sma_crossover.py`):

```python
async def on_bar(self, symbol: str, df: pd.DataFrame) -> list[SignalEvent]:
    """Process bar and emit all valid signals with confidence."""
    if len(df) < self.get_required_history():
        return []

    signals: list[SignalEvent] = []
    regime = self._detect_regime(df)
    
    # Compute ATR once and pass into signals for downstream use
    # ... (ATR calculation)
    
    # Check all SMA pairs - CAN emit 0-3 signals per bar
    for fast_period, slow_period in self.periods:
        signal = self._check_crossover(symbol, df, fast_period, slow_period, atr)
        if signal:
            # Score confidence based on regime and SMA period
            confidence = self._score_confidence(fast_period, slow_period, regime)
            signal.metadata["confidence"] = confidence
            # ... metadata setup
            signals.append(signal)

    return signals
```

The strategy:
1. Processes every bar independently
2. Has **no memory of previous signals** for that symbol
3. Emits signals for **all 3 SMA pairs** independently (fast, medium, slow)
4. Has **no cooldown period** between signals
5. Has **no position state awareness** - it doesn't check if already in a position

### 1.2 Why Duplicates Occur

The `_check_crossover()` method (lines 106-158) detects crossovers purely on price action:

```python
def _check_crossover(self, symbol, df, fast, slow, atr):
    fast_sma = ta.sma(df["close"], length=fast)
    slow_sma = ta.sma(df["close"], length=slow)
    
    # Detect crossover
    upward_cross = fast_prev <= slow_prev and fast_now > slow_now
    downward_cross = fast_prev >= slow_prev and fast_now < slow_now
    
    if not (upward_cross or downward_cross):
        return None
    
    signal_type = "BUY" if upward_cross else "SELL"
    
    # NOTE: Deduplication moved to OrderManager.submit_signal()
    # Strategy returns ALL crossover signals
    return SignalEvent(...)
```

**The Problem:**
- If TSLA has an upward SMA crossover at 14:40 → BUY signal generated → Order submitted
- If TSLA continues to trend upward and has another valid crossover (or the same SMA pair stays crossed) at 17:24 → **ANOTHER BUY signal generated**
- The strategy has no concept of "already in position" or "signal cooldown"

### 1.3 Why Database Deduplication Doesn't Prevent This

The `OrderManager.submit_order()` method (lines 71-163 in `src/order_manager.py`) has deduplication:

```python
def _generate_client_order_id(self, symbol, signal_ts, side):
    """SHA-256(strategy, symbol, timeframe, signal_ts, side)[:16]"""
    data = f"{self.strategy_name}:{symbol}:{self.timeframe}:{signal_ts.isoformat()}:{converted_side}"
    return hashlib.sha256(data.encode()).hexdigest()[:16]

async def submit_order(self, signal, qty):
    client_order_id = self._generate_client_order_id(
        symbol=symbol, signal_ts=signal.timestamp, side=side
    )
    
    # Check for duplicate
    existing = self.state_store.get_order_intent(client_order_id)
    if existing:
        logger.info(f"Duplicate order prevented: {client_order_id}")
        return False
```

**The deduplication key includes `signal_ts`** (the bar timestamp). This means:
- 14:40 signal → unique client_order_id → new order
- 17:24 signal → **different timestamp** → different client_order_id → **treated as new order**

This is working as designed - it prevents re-submitting the **same signal** (e.g., crash recovery), but it does NOT prevent the strategy from generating **new signals** for the same symbol/side on subsequent bars.

---

## 2. Current State Tracking

### 2.1 What IS Tracked

The system has several state tracking mechanisms:

1. **Order intents** (`state_store.save_order_intent()`) - tracks submitted orders by client_order_id
2. **Positions** (`position_tracker.start_tracking()`) - tracks open positions after fills
3. **Last signal per SMA period** (`state_store.save_last_signal()`) - exists but NOT used by strategy

### 2.2 What is NOT Tracked/Used

1. **No signal cooldown** - strategy doesn't track when it last emitted a signal for a symbol
2. **No position-aware filtering** - strategy doesn't check if already long before emitting BUY
3. **No pending order tracking** - doesn't check if a buy order is already in flight

---

## 3. Recommended Solution

### 3.1 Preferred Approach: Signal Cooldown with Position Awareness

Add signal-level deduplication at the **strategy level** (before signal emission) that combines:

1. **Cooldown period**: Don't emit same-side signal within X minutes (configurable, default 60 min)
2. **Position awareness**: Don't emit BUY if already have long position, don't emit SELL if already short
3. **Pending order awareness**: Don't emit signal if order already in flight for that symbol/side

### 3.2 Implementation Location

**File:** `src/strategy/sma_crossover.py`  
**Method:** `on_bar()` before signal emission, or new helper method

### 3.3 Required Changes

#### 3.3.1 Add State Tracking to Strategy

```python
def __init__(self, ...):
    # ... existing code ...
    
    # Signal cooldown tracking: symbol -> {last_signal_time, last_signal_type}
    self._signal_history: dict[str, dict] = {}
    
    # Cooldown period in minutes (configurable)
    self.signal_cooldown_minutes = 60

async def on_bar(self, symbol: str, df: pd.DataFrame) -> list[SignalEvent]:
    # ... existing validation ...
    
    signals = []
    
    for fast_period, slow_period in self.periods:
        signal = self._check_crossover(symbol, df, fast_period, slow_period, atr)
        
        if signal and self._should_emit_signal(symbol, signal, df):
            # ... add metadata ...
            signals.append(signal)
            self._record_signal(symbol, signal)
    
    return signals
```

#### 3.3.2 Add Signal Validation Method

```python
def _should_emit_signal(
    self, 
    symbol: str, 
    signal: SignalEvent, 
    df: pd.DataFrame,
    position_tracker: Optional['PositionTracker'] = None
) -> bool:
    """Check if signal should be emitted based on cooldown and position state.
    
    Args:
        symbol: Stock symbol
        signal: Proposed signal
        df: DataFrame for current price
        position_tracker: Optional position tracker to check current positions
    
    Returns:
        True if signal should be emitted
    """
    now = df.index[-1]
    signal_type = signal.signal_type  # "BUY" or "SELL"
    
    # Check 1: Cooldown - don't emit same-side signal within cooldown window
    last_signal = self._signal_history.get(symbol)
    if last_signal:
        time_since_last = (now - last_signal['time']).total_seconds() / 60
        if last_signal['type'] == signal_type and time_since_last < self.signal_cooldown_minutes:
            logger.debug(f"Signal cooldown active for {symbol} {signal_type}: "
                        f"{time_since_last:.1f}min < {self.signal_cooldown_minutes}min")
            return False
    
    # Check 2: Position awareness (requires position_tracker)
    if position_tracker:
        position = position_tracker.get_position(symbol)
        if position:
            # Don't BUY if already long, don't SELL if already short
            if signal_type == "BUY" and position.side == "long":
                logger.debug(f"Skipping BUY for {symbol}: already long")
                return False
            if signal_type == "SELL" and position.side == "short":
                logger.debug(f"Skipping SELL for {symbol}: already short")
                return False
    
    return True

def _record_signal(self, symbol: str, signal: SignalEvent) -> None:
    """Record signal emission for cooldown tracking."""
    self._signal_history[symbol] = {
        'time': signal.timestamp,
        'type': signal.signal_type,
    }
```

#### 3.3.3 Pass Position Tracker to Strategy

In `orchestrator.py` (around line 564 where `on_bar` is called):

```python
# Check 1: Cooldown - don't emit same-side signal within cooldown window
last_signal = self._signal_history.get(symbol)
if last_signal:
    time_since_last = (now - last_signal['time']).total_seconds() / 60
    if last_signal['type'] == signal_type and time_since_last < self.signal_cooldown_minutes:
        logger.debug(f"Signal cooldown active for {symbol} {signal_type}: "
                    f"{time_since_last:.1f}min < {self.signal_cooldown_minutes}min")
        return False

# Check 2: Position awareness (requires position_tracker)
if position_tracker:
    position = position_tracker.get_position(symbol)
    if position:
        # Don't BUY if already long, don't SELL if already short
        if signal_type == "BUY" and position.side == "long":
            logger.debug(f"Skipping BUY for {symbol}: already long")
            return False
        if signal_type == "SELL" and position.side == "short":
            logger.debug(f"Skipping SELL for {symbol}: already short")
            return False

return True

def _record_signal(self, symbol: str, signal: SignalEvent) -> None:
    """Record signal emission for cooldown tracking."""
    self._signal_history[symbol] = {
        'time': signal.timestamp,
        'type': signal.signal_type,
    }
```

#### 3.3.3 Pass Position Tracker to Strategy

In `orchestrator.py` (around line 564 where `on_bar` is called):

```python
# Current:
signals = await self.strategy.on_bar(event.symbol, df)

# Proposed:
signals = await self.strategy.on_bar(
    event.symbol, 
    df, 
    position_tracker=self.position_tracker  # Add this parameter
)
```

---

## 4. Alternative Approaches Considered

### 4.1 Approach A: OrderManager-Level Deduplication (Rejected)

Add symbol+side dedupe window in OrderManager.

**Cons:**
- Mixes concerns - OrderManager shouldn't know about strategy logic
- Doesn't prevent signal spam to downstream consumers
- Harder to configure per-strategy

### 4.2 Approach B: Event Bus Filtering (Rejected)

Filter duplicate signals at event bus level.

**Cons:**
- Event bus is dumb pipe by design
- Would require complex state tracking in bus
- Breaks separation of concerns

### 4.3 Approach C: Strategy-Level Cooldown Only (Selected as base)

Add cooldown tracking within strategy.

**Pros:**
- Strategy controls its own signal emission
- Can be configured per-strategy
- Clean separation of concerns
- Can incorporate position awareness

---

## 5. Test Scenarios

### 5.1 Unit Tests Required

1. **Cooldown Test**: Emit BUY at T=0, try to emit BUY at T=30min → should be blocked
2. **Cooldown Reset Test**: Emit BUY at T=0, try to emit BUY at T=90min → should be allowed
3. **Different Side Test**: Emit BUY at T=0, try to emit SELL at T=30min → should be allowed
4. **Position Awareness Test**: Have long position, try to emit BUY → should be blocked
5. **Crossover Continuation Test**: SMA stays crossed for multiple bars → only one signal

### 5.2 Integration Tests Required

1. **End-to-end duplicate prevention**: Bar with crossover → signal → order → next bar with same crossover → no new signal
2. **Recovery after exit**: Enter position → exit → re-enter after cooldown → should work
3. **Multiple SMA pairs**: Fast and slow both cross on same bar → both signals emitted (different SMA periods)

---

## 6. Configuration

Add to `config.yaml` under strategy section:

```yaml
strategy:
  name: sma_crossover
  params:
    signal_cooldown_minutes: 60  # Minimum time between same-side signals
    check_positions: true        # Whether to check position state before emitting
```

---

## 7. Files to Modify

| File | Changes |
|------|---------|
| `src/strategy/sma_crossover.py` | Add cooldown tracking, position awareness checks |
| `src/strategy/base.py` | Update `on_bar` signature to accept optional `position_tracker` |
| `orchestrator.py` | Pass `position_tracker` to strategy `on_bar` calls |
| `config.yaml` | Add cooldown configuration options |

---

## 8. Migration Notes

- This is a **behavioral change** - strategies will emit fewer signals
- Existing positions won't be affected (only new signal generation)
- Consider reducing `signal_cooldown_minutes` for initial rollout if trade frequency drops too much
- Monitor logs for "Skipping BUY/SELL" messages to verify working

---

## 9. Related Code References

- `src/strategy/sma_crossover.py:58-104` - `on_bar()` method
- `src/strategy/sma_crossover.py:106-158` - `_check_crossover()` method
- `src/order_manager.py:40-60` - `client_order_id` generation (existing dedupe)
- `src/order_manager.py:95-100` - duplicate check (order-level)
- `src/position_tracker.py:39-60` - position tracking
- `orchestrator.py:550-600` - event processor calling strategy

---

## Appendix: Current vs Proposed Flow

### Current Flow (Duplicate Signals Possible)

```
Bar at 14:40 (crossover detected)
    ↓
Strategy.on_bar() → SignalEvent(BUY)
    ↓
OrderManager.submit_order() → Order submitted (client_order_id: hash of 14:40)
    ↓
Bar at 17:24 (still crossed, or re-crossed)
    ↓
Strategy.on_bar() → SignalEvent(BUY)  ← DUPLICATE!
    ↓
OrderManager.submit_order() → Order submitted (client_order_id: hash of 17:24)
    ↓
TWO BUY ORDERS for same symbol!
```

### Proposed Flow (Duplicates Blocked)

```
Bar at 14:40 (crossover detected)
    ↓
Strategy.on_bar() → _should_emit_signal()? → YES (no recent signal)
    ↓
SignalEvent(BUY) emitted, recorded in _signal_history
    ↓
OrderManager.submit_order() → Order submitted
    ↓
Bar at 17:24 (crossover still valid)
    ↓
Strategy.on_bar() → _should_emit_signal()? → NO (cooldown active, already long)
    ↓
Signal suppressed, no order submitted
```
