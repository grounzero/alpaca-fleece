# Investigation: Blocking Synchronous Alpaca REST Calls

**Date:** 2026-02-12  
**Branch:** feat/schema-migration  
**Investigator:** Subagent  

## Executive Summary

**Are REST calls blocking?** **YES - PARTIAL**

Several critical components are making blocking synchronous Alpaca REST API calls from async functions without using `asyncio.to_thread()`, causing event loop blockage.

---

## Findings Overview

### Blocking Patterns Found: **12+ locations**
### Non-Blocking Patterns: **4+ locations (correctly implemented)**

---

## Blocking Calls (PROBLEMATIC) ⚠️

These calls block the asyncio event loop because they invoke the synchronous Alpaca SDK directly from async functions without `await asyncio.to_thread()`:

### 1. Exit Manager (`src/exit_manager.py`)

| Line | Function | Code | Impact |
|------|----------|------|--------|
| 228 | `check_positions()` | `clock = self.broker.get_clock()` | **HIGH** - Called every check interval (30s default) during position monitoring |

**Context:**
```python
# src/exit_manager.py:214-230
async def check_positions(self) -> list[ExitSignalEvent]:
    ...
    # Check if market is open first (fresh clock call)
    try:
        clock = self.broker.get_clock()  # <-- BLOCKING
        if not clock["is_open"]:
            return signals
```

---

### 2. Risk Manager (`src/risk_manager.py`)

| Line | Function | Code | Impact |
|------|----------|------|--------|
| 204 | `_check_safety_tier()` | `clock = self.broker.get_clock()` | **HIGH** - Called on every signal check |
| 219 | `_check_risk_tier()` | `account = self.broker.get_account()` | **HIGH** - Called on every signal check |
| 236 | `_check_risk_tier()` | `positions = self.broker.get_positions()` | **HIGH** - Called on every signal check |
| 355 | `check_exit_order()` | `clock = self.broker.get_clock()` | **MEDIUM** - Called on exit orders |

**Context:**
```python
# src/risk_manager.py:202-206
async def _check_safety_tier(self) -> None:
    ...
    try:
        clock = self.broker.get_clock()  # <-- BLOCKING
        if not clock["is_open"]:
            raise RiskManagerError("Market not open")

# src/risk_manager.py:217-237
async def _check_risk_tier(self, symbol: str, side: str) -> None:
    ...
    account = self.broker.get_account()  # <-- BLOCKING
    ...
    positions = self.broker.get_positions()  # <-- BLOCKING
```

---

### 3. Housekeeping (`src/housekeeping.py`)

| Line | Function | Code | Impact |
|------|----------|------|--------|
| 87 | `graceful_shutdown()` | `orders = self.broker.get_open_orders()` | **MEDIUM** - Called during shutdown |
| 91 | `graceful_shutdown()` | `self.broker.cancel_order(order_id)` | **MEDIUM** - Called during shutdown |
| 99 | `graceful_shutdown()` | `positions = self.broker.get_positions()` | **MEDIUM** - Called during shutdown |
| 108 | `graceful_shutdown()` | `self.broker.submit_order(...)` | **MEDIUM** - Called during shutdown |
| 121 | `_equity_snapshots()` | `account = self.broker.get_account()` | **HIGH** - Called every 60 seconds |
| 155 | `graceful_shutdown()` | `account = self.broker.get_account()` | **MEDIUM** - Called during shutdown |

**Context:**
```python
# src/housekeeping.py:85-122
async def graceful_shutdown(self) -> None:
    ...
    orders = self.broker.get_open_orders()  # <-- BLOCKING
    ...
    self.broker.cancel_order(order_id)  # <-- BLOCKING
    ...
    positions = self.broker.get_positions()  # <-- BLOCKING
    ...
    self.broker.submit_order(...)  # <-- BLOCKING

# src/housekeeping.py:145-156
async def _equity_snapshots(self) -> None:
    while self.running:
        account = self.broker.get_account()  # <-- BLOCKING (every 60s)
```

---

### 4. Order Manager (`src/order_manager.py`)

| Line | Function | Code | Impact |
|------|----------|------|--------|
| 321 | `submit_order()` | `order = self.broker.submit_order(...)` | **CRITICAL** - Called on every order submission |

**Context:**
```python
# src/order_manager.py:319-351
async def submit_order(self, signal: SignalEvent, qty: float) -> bool:
    ...
    # Submit order
    try:
        order = self.broker.submit_order(  # <-- BLOCKING
            symbol=symbol,
            side=side,
            qty=float(qty),
            ...
        )
```

**Note:** The order manager CORRECTLY uses `asyncio.to_thread()` for `get_positions()` at lines 140, 160, 168, 182, 185, but NOT for the critical `submit_order()` call.

---

### 5. Reconciliation (`src/reconciliation.py`)

| Line | Function | Code | Impact |
|------|----------|------|--------|
| 57 | `reconcile()` | `alpaca_orders = broker.get_open_orders()` | **LOW** - Called once at startup |
| 58 | `reconcile()` | `alpaca_positions = broker.get_positions()` | **LOW** - Called once at startup |

**Context:**
```python
# src/reconciliation.py:55-60
def reconcile(broker: Broker, state_store: StateStore) -> None:
    ...
    alpaca_orders = broker.get_open_orders()  # <-- BLOCKING (but sync function)
    alpaca_positions = broker.get_positions()  # <-- BLOCKING (but sync function)
```

**Note:** This is a synchronous function called at startup, so it's less critical but still blocks during initialization.

---

## Correctly Non-Blocking Patterns ✅

These locations correctly use `await asyncio.to_thread()` or `await loop.run_in_executor()`:

### 1. Position Tracker (`src/position_tracker.py`)
```python
# Line 200 - CORRECT
broker_positions = await asyncio.to_thread(self.broker.get_positions)
```

### 2. Order Manager (`src/order_manager.py`)
```python
# Lines 140, 160, 168, 182, 185 - CORRECT
positions = await asyncio.to_thread(self.broker.get_positions)
```

### 3. Stream Polling (`src/stream_polling.py`)
```python
# Lines 311, 440, 456, 512, 710 - CORRECT
await asyncio.to_thread(self.client.get_stock_bars, request)
await asyncio.to_thread(self._get_submitted_orders)
await asyncio.to_thread(self.client.get_order_by_id, order_id)
```

### 4. Notifier (`src/notifier.py`)
```python
# Lines 110-118 - CORRECT (in async send_alert_async)
ok = await loop.run_in_executor(None, self._send_whatsapp_alert, ...)
ok = await loop.run_in_executor(None, self._send_slack_alert, ...)
ok = await loop.run_in_executor(None, self._send_email_alert, ...)
```

---

## Minor Issue: Notifier Sync Sleep

**File:** `src/notifier.py:83`

The synchronous `send_alert()` method uses `time.sleep()` for backoff:

```python
if attempt < self.retries - 1:
    import time
    delay = self.backoff * (2**attempt)
    time.sleep(delay)  # <-- BLOCKING if called from async code
```

**Impact:** LOW - The async wrapper `send_alert_async()` is available and should be used from async contexts. However, if someone accidentally calls `send_alert()` from an async function, it will block.

---

## Impact Assessment

| Component | Severity | Frequency | Effect |
|-----------|----------|-----------|--------|
| Order Manager (`submit_order`) | **CRITICAL** | Every trade | Blocks event loop during order submission (~100-500ms) |
| Risk Manager (`check_signal`) | **HIGH** | Every signal | Blocks on every trading signal (~100-300ms) |
| Exit Manager (`check_positions`) | **HIGH** | Every 30s | Blocks during position checks (~50-200ms) |
| Housekeeping (`_equity_snapshots`) | **HIGH** | Every 60s | Blocks during equity snapshots (~50-150ms) |
| Housekeeping (`graceful_shutdown`) | **MEDIUM** | On shutdown | Blocks during shutdown (multiple calls) |
| Reconciliation | **LOW** | Once at startup | Blocks during initialization |

### Cumulative Effect

During active trading:
- Risk checks happen on every signal (could be multiple per bar)
- Position checks happen every 30 seconds
- Equity snapshots every 60 seconds
- Order submissions during entry/exit

**Estimated blocking time:** 100-500ms per operation, potentially multiple operations per second during active trading.

### Consequences

1. **Delayed market data processing** - Bars/signals may be processed late
2. **Order submission delays** - Entry/exit orders may be delayed
3. **Missed signals** - If blocking exceeds bar intervals
4. **Cascading delays** - Multiple blocking calls compound

---

## Root Cause

The `Broker` class (`src/broker.py`) provides a **synchronous API** that wraps the Alpaca SDK:

```python
# src/broker.py - All methods are synchronous
def get_account(self) -> AccountInfo: ...
def get_positions(self) -> list[PositionInfo]: ...
def get_open_orders(self) -> list[OrderInfo]: ...
def get_clock(self) -> ClockInfo: ...
def submit_order(self, ...) -> OrderInfo: ...
def cancel_order(self, order_id: str) -> None: ...
```

These methods internally use `ThreadPoolExecutor` for timeout protection, but the methods themselves are synchronous and block when called directly.

**The fix:** All async callers must wrap these calls with `await asyncio.to_thread(self.broker.xxx)`.

---

## Recommended Fixes

### Fix 1: Risk Manager (`src/risk_manager.py`)

Change all direct broker calls to use `asyncio.to_thread()`:

```python
# Line 204
clock = await asyncio.to_thread(self.broker.get_clock)

# Line 219
account = await asyncio.to_thread(self.broker.get_account)

# Line 236
positions = await asyncio.to_thread(self.broker.get_positions)

# Line 355
clock = await asyncio.to_thread(self.broker.get_clock)
```

### Fix 2: Exit Manager (`src/exit_manager.py`)

```python
# Line 228
clock = await asyncio.to_thread(self.broker.get_clock)
```

### Fix 3: Housekeeping (`src/housekeeping.py`)

```python
# Line 87
orders = await asyncio.to_thread(self.broker.get_open_orders)

# Line 91
await asyncio.to_thread(self.broker.cancel_order, order_id)

# Line 99
positions = await asyncio.to_thread(self.broker.get_positions)

# Line 108
await asyncio.to_thread(self.broker.submit_order, ...)

# Line 121
account = await asyncio.to_thread(self.broker.get_account)

# Line 155
account = await asyncio.to_thread(self.broker.get_account)
```

### Fix 4: Order Manager (`src/order_manager.py`)

```python
# Line 321
order = await asyncio.to_thread(
    self.broker.submit_order,
    symbol=symbol,
    side=side,
    qty=float(qty),
    client_order_id=client_order_id,
    order_type=self.order_type,
    time_in_force=self.time_in_force,
)
```

### Alternative: Create Async Broker Wrapper

Consider creating an async wrapper class for `Broker`:

```python
class AsyncBroker:
    def __init__(self, broker: Broker):
        self._broker = broker
    
    async def get_account(self) -> AccountInfo:
        return await asyncio.to_thread(self._broker.get_account)
    
    async def get_positions(self) -> list[PositionInfo]:
        return await asyncio.to_thread(self._broker.get_positions)
    
    async def submit_order(self, **kwargs) -> OrderInfo:
        return await asyncio.to_thread(self._broker.submit_order, **kwargs)
    
    # ... etc
```

This would make the async nature explicit in the API.

---

## Summary

| Metric | Count |
|--------|-------|
| Total blocking calls found | 12+ |
| Critical (order submission) | 1 |
| High (frequent operations) | 8 |
| Medium (shutdown/startup) | 4 |
| Already correctly wrapped | 10+ |

**Verdict:** The codebase has a **partial blocking problem**. Some components (PositionTracker, StreamPolling) correctly use `asyncio.to_thread()`, but critical paths (RiskManager, ExitManager, Housekeeping, OrderManager) are making blocking calls that will freeze the event loop.

**Priority:** Fix the OrderManager's `submit_order()` and RiskManager's signal checks first, as these are on the hot path for trading.
