# Partial Fill Spec Gap Analysis

**Date:** 2026-02-13  
**Branch:** feat/partial-fills  
**Analyst:** Sub-agent Analysis  

---

## Executive Summary

The current partial fill implementation is **functional but incomplete** relative to the spec. The core mechanisms (fill tracking, delta computation, idempotent persistence, reconciliation) are implemented, but the architecture lacks the formal data structures and strategic flexibility specified.

**Verdict:** The current implementation covers ~60% of the spec's requirements. It is production-ready for basic partial fill handling but lacks the configurability and formal structure specified for advanced use cases.

---

## Current vs Spec Comparison Table

| Component | Spec Requirement | Current Implementation | Gap Status |
|-----------|-----------------|----------------------|------------|
| **OrderState Enum** | Formal enum with PENDING, PARTIAL, FILLED, CANCELLED, REJECTED, EXPIRED | String-based status comparison ("new", "submitted", "filled", etc.) | ❌ MISSING |
| **OrderFill Dataclass** | Typed dataclass with fill_id, timestamp, quantity, price | Raw values in `fills` table, no formal type | ❌ MISSING |
| **TrackedOrder Dataclass** | Wrapper combining order + fills with computed properties | Separate `order_intents` + `fills` tables, no unified object | ❌ MISSING |
| **Partial Fill Strategies** | Configurable strategies A/B/C/D | Hardcoded approach (Strategy D-like behavior) | ❌ MISSING |
| **order_fills Table** | Separate table with FK to orders, proper schema | `fills` table exists but uses `alpaca_order_id` not FK to `order_intents` | ⚠️ PARTIAL |
| **orders.state Column** | State enum column | `order_intents.status` string column exists | ⚠️ PARTIAL |
| **Fill Event Processing** | `on_fill_update()` handler with state transitions | `OrderUpdatesHandler.on_order_update()` with delta computation | ✅ IMPLEMENTED |
| **Delta Fill Computation** | Compute incremental fills from cumulative | `_process_fill_delta()` implements this | ✅ IMPLEMENTED |
| **Idempotent Persistence** | Duplicate fill detection | `insert_fill_idempotent()` with `fill_dedupe_key` | ✅ IMPLEMENTED |
| **Monotonic Updates** | Never decrease filled_qty | `update_order_intent_cumulative()` enforces monotonicity | ✅ IMPLEMENTED |
| **Position Tracker Integration** | Update position with actual filled qty | PositionTracker exists but doesn't directly consume fills | ⚠️ PARTIAL |
| **Reconciliation** | Daily drift detection and correction | `reconciliation.py` with `reconcile_fills()` | ✅ IMPLEMENTED |
| **Error Scenarios** | Handle unknown orders, duplicates, race conditions | Partial handling in `OrderUpdatesHandler` | ⚠️ PARTIAL |
| **Blended Average Price** | Calculate across multiple fills | Stored in `filled_avg_price` but not computed locally | ⚠️ PARTIAL |

---

## Detailed Gap Analysis

### 1. OrderState Enum ❌ MISSING

**Spec Wants:**
```python
class OrderState(Enum):
    PENDING = "pending"           # Submitted, no fills
    PARTIAL = "partial"           # Some fills, still open
    FILLED = "filled"             # Complete
    CANCELLED = "cancelled"       # Cancelled, may have partial fills
    EXPIRED = "expired"           # Expired, may have partial fills
    REJECTED = "rejected"         # Never filled
```

**Current State:**
- Uses string status values: "new", "submitted", "accepted", "partially_filled", "filled", "canceled", "expired", "rejected"
- Status checks are string comparisons scattered throughout codebase
- No centralized state machine logic

**Work Needed:**
- Create `OrderState` enum in `src/order_manager.py` or new `src/types.py`
- Replace all string status comparisons with enum comparisons
- Update database to store enum values (or keep strings but compare via enum)
- Update `OrderUpdateEvent` to use enum type

**Files Affected:**
- `src/order_manager.py` - Add enum definition
- `src/event_bus.py` - Update `OrderUpdateEvent.status` type
- `src/data/order_updates.py` - Update status handling
- `src/reconciliation.py` - Update TERMINAL_STATUSES/NON_TERMINAL_STATUSES
- `src/state_store.py` - Potentially update status storage

**Estimated Effort:** 
- Lines of code: ~100-150
- Complexity: Medium (requires careful find/replace)
- Tests needed: Unit tests for state transitions
- Risk: Medium (could break existing status logic)

---

### 2. OrderFill Dataclass ❌ MISSING

**Spec Wants:**
```python
@dataclass
class OrderFill:
    fill_id: str
    timestamp: datetime
    quantity: int
    price: float
```

**Current State:**
- Fill data stored as raw values in `fills` table rows
- No formal type definition for fill objects
- Access via dictionary keys or row indices

**Work Needed:**
- Create `OrderFill` dataclass
- Update `insert_fill_idempotent()` to accept/return OrderFill
- Update `OrderUpdatesHandler` to work with OrderFill objects
- Add serialization/deserialization methods

**Files Affected:**
- `src/types.py` (new file) or `src/order_manager.py` - Add dataclass
- `src/state_store.py` - Update fill methods
- `src/data/order_updates.py` - Use OrderFill in processing

**Estimated Effort:**
- Lines of code: ~50-80
- Complexity: Low
- Tests needed: Serialization round-trip tests
- Risk: Low

---

### 3. TrackedOrder Dataclass ❌ MISSING

**Spec Wants:**
```python
@dataclass
class TrackedOrder:
    order_id: str
    symbol: str
    side: OrderSide
    requested_qty: int
    fills: List[OrderFill]
    state: OrderState
    
    @property
    def filled_qty(self) -> int: ...
    @property
    def remaining_qty(self) -> int: ...
    @property
    def avg_fill_price(self) -> float: ...
```

**Current State:**
- Order data in `order_intents` table
- Fill data in `fills` table
- No unified object combining both
- Computed properties calculated on-the-fly in various places

**Work Needed:**
- Create `TrackedOrder` dataclass
- Add `OrderSide` enum if not exists
- Implement computed properties
- Create factory method to build from DB rows
- Update `OrderManager` to work with TrackedOrder

**Files Affected:**
- `src/types.py` (new file) - Add dataclass
- `src/order_manager.py` - Integrate TrackedOrder
- `src/state_store.py` - Add method to fetch complete TrackedOrder
- `src/data/order_updates.py` - Use TrackedOrder

**Estimated Effort:**
- Lines of code: ~150-200
- Complexity: Medium
- Tests needed: Property calculation tests, factory tests
- Risk: Medium (architectural change)

---

### 4. Partial Fill Strategies ❌ MISSING

**Spec Wants:**
- **Strategy A:** Wait for Complete Fill
- **Strategy B:** Cancel Remainder After Timeout
- **Strategy C:** Immediate Retry
- **Strategy D:** Accept Partial (Recommended)
- Configurable per strategy config

**Current State:**
- No strategy framework exists
- Current behavior resembles Strategy D (accept partial) but without explicit cancellation
- No timeout handling for partial fills
- No retry mechanism

**Work Needed:**
- Create `PartialFillStrategy` enum
- Create strategy interface/base class
- Implement each strategy (A, B, C, D)
- Add configuration to strategy config
- Integrate with `OrderManager`
- Add timeout handling infrastructure

**Files Affected:**
- `src/strategy/partial_fill_strategies.py` (new file)
- `src/order_manager.py` - Add strategy selection and execution
- `src/config.py` or strategy configs - Add strategy configuration
- `src/orchestrator.py` - Wire up strategy selection

**Estimated Effort:**
- Lines of code: ~300-400
- Complexity: High (requires async timeout handling, retry logic)
- Tests needed: Comprehensive tests for each strategy
- Risk: High (affects core order lifecycle)

---

### 5. order_fills Table Schema ⚠️ PARTIAL

**Spec Wants:**
```sql
CREATE TABLE order_fills (
    fill_id TEXT PRIMARY KEY,
    order_id TEXT NOT NULL,
    symbol TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    price REAL NOT NULL,
    timestamp_utc TEXT NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id)
);
```

**Current State:**
```sql
CREATE TABLE fills (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    alpaca_order_id TEXT NOT NULL,
    client_order_id TEXT NOT NULL,
    symbol TEXT NOT NULL,
    side TEXT NOT NULL,
    delta_qty NUMERIC(10, 4) NOT NULL,
    cum_qty NUMERIC(10, 4) NOT NULL,
    cum_avg_price NUMERIC(10, 4),
    timestamp_utc TEXT NOT NULL,
    fill_id TEXT,
    price_is_estimate INTEGER NOT NULL DEFAULT 1,
    fill_dedupe_key TEXT NOT NULL,
    UNIQUE(alpaca_order_id, fill_dedupe_key)
);
```

**Comparison:**
| Aspect | Spec | Current | Notes |
|--------|------|---------|-------|
| Primary Key | fill_id (TEXT) | id (INTEGER) + fill_id | Current has surrogate key |
| FK to orders | order_id | alpaca_order_id | No formal FK constraint |
| Side stored | No | Yes | Current stores side per fill |
| Delta vs Cumulative | Just qty/price | Both delta AND cum | Current tracks both |
| Dedupe | fill_id | fill_dedupe_key | Current more sophisticated |
| Price estimate flag | No | Yes | Current tracks estimate flag |

**Work Needed:**
- Minimal - current table is actually more sophisticated than spec
- Could add formal FK constraint (but requires order_id to be stable)
- Could rename to `order_fills` for clarity

**Decision:** Current implementation is **acceptable** and arguably better than spec.

---

### 6. orders.state Column ⚠️ PARTIAL

**Spec Wants:**
```sql
ALTER TABLE orders ADD COLUMN state TEXT DEFAULT 'pending';
-- State enum: pending, partial, filled, cancelled, expired, rejected
```

**Current State:**
```sql
CREATE TABLE order_intents (
    client_order_id TEXT PRIMARY KEY,
    ...
    status TEXT NOT NULL,  -- 'new', 'submitted', 'partially_filled', etc.
    ...
);
```

**Gap:**
- Column exists but named `status` not `state`
- Type is string not enum
- Values differ slightly from spec mapping

**Work Needed:**
- Rename column (migration required) OR keep as-is
- Map current status values to OrderState enum

**Decision:** Column exists; renaming is cosmetic. Acceptable as-is with enum overlay.

---

### 7. Position Tracker Integration ⚠️ PARTIAL

**Spec Wants:**
```python
async def update_position_from_fill(self, fill: OrderFill, side: OrderSide):
    # Blend average price for existing + new
    total_qty = current.qty + fill.quantity
    total_cost = (current.qty * current.avg_price) + (fill.quantity * fill.price)
    current.avg_price = total_cost / total_qty
```

**Current State:**
- `PositionTracker` tracks positions in memory and persists to `position_tracking` table
- `start_tracking()` creates new position with initial fill
- No explicit method to update position from individual fills
- Average price blending not explicitly implemented

**Work Needed:**
- Add `update_position_from_fill()` method to PositionTracker
- Implement average price blending
- Call from OrderUpdatesHandler when delta_qty > 0

**Files Affected:**
- `src/position_tracker.py` - Add method
- `src/data/order_updates.py` - Call position tracker on fill

**Estimated Effort:**
- Lines of code: ~50-80
- Complexity: Low-Medium
- Tests needed: Position update tests, average price blending tests
- Risk: Medium (affects position accuracy)

---

### 8. Reconciliation ✅ IMPLEMENTED

**Spec Wants:**
- Daily reconciliation comparing bot positions vs Alpaca API
- Alert if drift > 0 shares
- Auto-correct from Alpaca if mismatch

**Current State:**
- `reconciliation.py` exists with `reconcile()` and `reconcile_fills()`
- Startup reconciliation compares SQLite vs Alpaca
- Fill reconciliation synthesizes missed updates
- Position mismatches logged and reported

**Status:** Spec met. Current implementation is comprehensive.

---

## Implementation Effort Summary

| Component | Files | LOC | Complexity | Tests | Risk |
|-----------|-------|-----|------------|-------|------|
| OrderState Enum | 4-5 | 100-150 | Medium | 10-15 | Medium |
| OrderFill Dataclass | 3-4 | 50-80 | Low | 5-10 | Low |
| TrackedOrder Dataclass | 4-5 | 150-200 | Medium | 15-20 | Medium |
| Partial Fill Strategies | 3-4 | 300-400 | High | 20-30 | High |
| Position Tracker Integration | 2 | 50-80 | Low-Med | 10-15 | Medium |
| **TOTAL** | **~18** | **~650-900** | **High** | **60-90** | **High** |

**Estimated Duration:** 4-5 days (matches spec estimate)

---

## Recommended Approach

### Option 1: Full Spec Compliance (4-5 days)
Implement all missing components exactly as specified.

**Pros:**
- Complete feature set
- Configurable strategies
- Type-safe code
- Maximum flexibility

**Cons:**
- Significant development time
- Higher risk of introducing bugs
- Partial fill strategies may be overkill for current needs

### Option 2: Simplified Compliance (1-2 days) ⭐ RECOMMENDED
Implement only the critical gaps:
1. OrderState enum (type safety)
2. OrderFill dataclass (type safety)
3. Position Tracker integration (correctness)
4. Skip: TrackedOrder wrapper (current DB approach works)
5. Skip: Partial fill strategies (current Strategy D behavior is fine)

**Pros:**
- Much faster to implement
- Lower risk
- Addresses type safety issues
- Maintains current stability

**Cons:**
- Less configurable than spec
- No formal TrackedOrder abstraction

### Option 3: Current State (0 days)
Keep current implementation as-is.

**Pros:**
- No risk
- Already functional

**Cons:**
- No type safety on states
- No formal fill types
- Position tracking may drift (not wired to fills)

---

## Critical Issues to Address

1. **Position Tracker Not Wired to Fills** ⚠️ HIGH PRIORITY
   - Currently positions are created at order submission, not on fill
   - Could lead to position drift if fills differ from order quantity
   - **Fix:** Call `position_tracker.update_position_from_fill()` from `OrderUpdatesHandler`

2. **String-Based Status Comparisons** ⚠️ MEDIUM PRIORITY
   - Prone to typos and inconsistencies
   - No IDE autocomplete support
   - **Fix:** Introduce OrderState enum

3. **No Partial Fill Strategy Configuration** ⚠️ LOW PRIORITY
   - Current Strategy D behavior (accept partial) is appropriate for most use cases
   - Can be added later if needed

---

## Conclusion

The current partial fill implementation is **operationally sound** but **architecturally incomplete** relative to the spec. The core mechanisms work (delta computation, idempotent persistence, reconciliation), but the code lacks the formal structure and configurability specified.

**Recommendation:** Implement **Option 2 (Simplified Compliance)** to gain type safety and correct position tracking without the overhead of full strategy configurability.

**Priority Order:**
1. Wire PositionTracker to fills (critical for correctness)
2. Add OrderState enum (type safety)
3. Add OrderFill dataclass (type safety)
4. Defer TrackedOrder and strategies until needed

---

*Analysis completed: 2026-02-13*
