"""Data normalisation, persistence, and event publishing."""
